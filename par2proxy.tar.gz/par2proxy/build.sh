#!/bin/bash
# Build and deploy par2proxy
# Works around docker-compose v1.29.2 ContainerConfig bug by
# building with BuildKit disabled then using the pre-built image.

set -e

echo "Building par2proxy image (BuildKit disabled for docker-compose v1 compatibility)..."
DOCKER_BUILDKIT=0 docker build -t par2proxy:latest .

echo "Stopping existing container if running..."
docker-compose down 2>/dev/null || true

echo "Starting par2proxy..."
docker-compose up -d

echo ""
echo "Done. par2proxy is running at http://localhost:8383"
echo "Go to Settings to configure connections."
