module github.com/par2proxy

go 1.22.2
