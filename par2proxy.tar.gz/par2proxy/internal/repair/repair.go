// Package repair fetches par2 data for an NZB, checks which media segments
// are missing/corrupt, and rewrites the NZB so that Decypharr receives a
// version pointing at recovery slices instead of bad segments.
//
// Crucially: we never download the media files. Only par2 data is fetched.
package repair

import (
	"bytes"
	"fmt"
	"log"
	"sync"

	"github.com/par2proxy/internal/nntp"
	"github.com/par2proxy/internal/nzb"
	"github.com/par2proxy/internal/par2"
)

// Result is what the repair engine produces.
type Result struct {
	OriginalNZB   *nzb.NZB
	RepairedNZB   *nzb.NZB // nil if no repair was needed or possible
	BadSegments   int      // how many segments were absent from Usenet
	RepairedCount int      // how many were substituted with recovery blocks
	Par2Fetched   int64    // bytes of par2 data downloaded
	Repaired      bool     // true if NZB was modified
	Warnings      []string
}

// Engine performs NZB repair.
type Engine struct {
	pool        *nntp.Pool
	maxPar2MB   int
	verbose     bool

	// cache: par2 blobs keyed by NZB identity (par2 total bytes as proxy)
	mu    sync.Mutex
	cache map[string]*par2.Set
}

// New creates a repair Engine.
func New(pool *nntp.Pool, maxPar2MB int, verbose bool) *Engine {
	return &Engine{
		pool:      pool,
		maxPar2MB: maxPar2MB,
		verbose:   verbose,
		cache:     make(map[string]*par2.Set),
	}
}

// Repair takes an NZB, fetches par2 data, checks which segments are
// missing on Usenet, and returns a (possibly rewritten) NZB.
func (e *Engine) Repair(n *nzb.NZB) (*Result, error) {
	result := &Result{OriginalNZB: n}

	par2Files := n.Par2Files()
	if len(par2Files) == 0 {
		result.Warnings = append(result.Warnings, "no par2 files in NZB, skipping repair")
		return result, nil
	}

	// --- Step 1: fetch par2 data via NNTP ---
	set, fetched, err := e.fetchPar2Set(n)
	if err != nil {
		result.Warnings = append(result.Warnings, fmt.Sprintf("par2 fetch failed: %v", err))
		return result, nil
	}
	result.Par2Fetched = fetched

	if e.verbose {
		log.Printf("repair: par2 set loaded — sliceSize=%d filDescs=%d recovery=%d",
			set.SliceSize, len(set.FileDescs), set.RecoveryCount())
	}

	// --- Step 2: STAT each media segment to find missing ones ---
	// We use STAT (not BODY) so we never download media bytes.
	missing := e.findMissingSegments(n)
	result.BadSegments = len(missing)

	if len(missing) == 0 {
		if e.verbose {
			log.Printf("repair: all segments present, no repair needed")
		}
		return result, nil
	}

	log.Printf("repair: %d missing segments found, have %d recovery blocks",
		len(missing), set.RecoveryCount())

	if !set.HasRecovery() {
		result.Warnings = append(result.Warnings, "missing segments but no recovery blocks available")
		return result, nil
	}

	if set.RecoveryCount() < len(missing) {
		result.Warnings = append(result.Warnings,
			fmt.Sprintf("need %d recovery blocks, only have %d — partial repair",
				len(missing), set.RecoveryCount()))
	}

	// --- Step 3: build a rewritten NZB ---
	// Each missing media segment is replaced with the message-ID of a
	// recovery block from the par2 set. Decypharr will stream the recovery
	// data instead of the missing segment; the PAR2 reconstruction happens
	// implicitly because Decypharr already has skip_repair:false.
	//
	// More precisely: we substitute missing segments with available recovery
	// article IDs so Decypharr can at least get data for those positions.
	// The real correction is that Decypharr's own repair layer (skip_repair=false)
	// will then have the recovery data it needs co-located with the stream.
	rewritten, repaired := e.rewriteNZB(n, missing, set, n.Par2Files())
	result.RepairedNZB = rewritten
	result.RepairedCount = repaired
	result.Repaired = repaired > 0

	log.Printf("repair: rewrote NZB — substituted %d/%d missing segments", repaired, len(missing))
	return result, nil
}

// fetchPar2Set fetches all par2 files for the NZB and parses them into a Set.
func (e *Engine) fetchPar2Set(n *nzb.NZB) (*par2.Set, int64, error) {
	cacheKey := fmt.Sprintf("%d_%d", n.Par2TotalBytes(), len(n.Par2Files()))
	e.mu.Lock()
	if cached, ok := e.cache[cacheKey]; ok {
		e.mu.Unlock()
		return cached, 0, nil
	}
	e.mu.Unlock()

	par2Files := n.Par2Files()
	maxBytes := int64(e.maxPar2MB) * 1024 * 1024

	var blobs [][]byte
	var totalFetched int64

	for _, pf := range par2Files {
		if maxBytes > 0 && totalFetched >= maxBytes {
			if e.verbose {
				log.Printf("repair: reached par2 byte limit (%d MB), stopping", e.maxPar2MB)
			}
			break
		}

		data, err := e.fetchFile(pf)
		if err != nil {
			if e.verbose {
				log.Printf("repair: failed to fetch par2 file %q: %v", pf.Subject, err)
			}
			continue
		}
		blobs = append(blobs, data)
		totalFetched += int64(len(data))
	}

	if len(blobs) == 0 {
		return nil, 0, fmt.Errorf("could not fetch any par2 data")
	}

	set, err := par2.ParseAll(blobs)
	if err != nil {
		return nil, totalFetched, fmt.Errorf("par2 parse: %w", err)
	}

	e.mu.Lock()
	e.cache[cacheKey] = set
	e.mu.Unlock()

	return set, totalFetched, nil
}

// fetchFile downloads all segments of an NZB file entry and concatenates them.
func (e *Engine) fetchFile(f *nzb.File) ([]byte, error) {
	segments := f.SortedSegments()
	mids := make([]string, len(segments))
	for i, s := range segments {
		mids[i] = s.MID()
	}

	articles, errs := e.pool.FetchArticles(mids)
	if len(errs) > 0 && e.verbose {
		for _, err := range errs {
			log.Printf("repair: segment fetch error: %v", err)
		}
	}

	var buf bytes.Buffer
	for _, seg := range segments {
		data, ok := articles[seg.MID()]
		if !ok {
			return nil, fmt.Errorf("segment %d (%s) not available", seg.Number, seg.MID())
		}
		buf.Write(data)
	}
	return buf.Bytes(), nil
}

type missingSegment struct {
	file    *nzb.File
	segment nzb.Segment
}

// findMissingSegments STATs each media segment and returns those not found.
func (e *Engine) findMissingSegments(n *nzb.NZB) []missingSegment {
	type work struct {
		file *nzb.File
		seg  nzb.Segment
	}
	type result struct {
		w       work
		present bool
	}

	mediaFiles := n.MediaFiles()
	var jobs []work
	for _, f := range mediaFiles {
		for _, seg := range f.Segments {
			jobs = append(jobs, work{file: f, seg: seg})
		}
	}

	if e.verbose {
		log.Printf("repair: checking %d media segments via STAT...", len(jobs))
	}

	// Fan out STAT checks concurrently
	resultCh := make(chan result, len(jobs))
	// Limit goroutines to avoid thundering herd
	sem := make(chan struct{}, 32)
	var wg sync.WaitGroup
	for _, j := range jobs {
		j := j
		wg.Add(1)
		sem <- struct{}{}
		go func() {
			defer wg.Done()
			defer func() { <-sem }()
			present := e.pool.CheckArticle(j.seg.MID())
			resultCh <- result{w: j, present: present}
		}()
	}
	go func() {
		wg.Wait()
		close(resultCh)
	}()

	var missing []missingSegment
	for r := range resultCh {
		if !r.present {
			missing = append(missing, missingSegment{
				file:    r.w.file,
				segment: r.w.seg,
			})
		}
	}
	return missing
}

// rewriteNZB produces a modified NZB where missing media segments are
// replaced by recovery block article IDs from the par2 files.
// Returns the rewritten NZB and the count of substitutions made.
func (e *Engine) rewriteNZB(
	original *nzb.NZB,
	missing []missingSegment,
	set *par2.Set,
	par2Files []*nzb.File,
) (*nzb.NZB, int) {
	// Build a flat list of recovery article IDs in order
	// Each par2 recovery file's segments are individual recovery blocks
	var recoveryIDs []string
	for _, pf := range par2Files {
		if pf.IsPar2Index() {
			continue // index has no recovery data
		}
		for _, seg := range pf.SortedSegments() {
			recoveryIDs = append(recoveryIDs, seg.MID())
		}
	}

	if len(recoveryIDs) == 0 {
		return original, 0
	}

	// Deep-copy the NZB so we don't mutate the original
	rewritten := deepCopyNZB(original)

	repaired := 0
	for i, ms := range missing {
		if i >= len(recoveryIDs) {
			break // ran out of recovery blocks
		}
		if rewritten.ReplaceSegment(ms.file.Subject, ms.segment.Number, recoveryIDs[i]) {
			repaired++
		}
	}

	return rewritten, repaired
}

// deepCopyNZB makes a shallow-enough copy that we can safely mutate Segments.
func deepCopyNZB(original *nzb.NZB) *nzb.NZB {
	out := &nzb.NZB{
		XMLName: original.XMLName,
		Meta:    original.Meta,
	}
	for _, f := range original.Files {
		newFile := &nzb.File{
			Subject:  f.Subject,
			Poster:   f.Poster,
			Date:     f.Date,
			Groups:   f.Groups,
			Segments: make([]nzb.Segment, len(f.Segments)),
		}
		for i, s := range f.Segments {
			newFile.Segments[i] = s
		}
		out.Files = append(out.Files, newFile)
	}
	return out
}
