// Package repair fetches par2 data for an NZB, checks which media segments
// are missing/corrupt, and rewrites the NZB so that Decypharr receives a
// version pointing at recovery slices instead of bad segments.
//
// Crucially: we never download the media files. Only par2 data is fetched.
package repair

import (
	"bytes"
	"fmt"
	"log"
	"sync"

	"github.com/par2proxy/internal/nntp"
	"github.com/par2proxy/internal/nzb"
	"github.com/par2proxy/internal/par2"
)

// Result is what the repair engine produces.
type Result struct {
	OriginalNZB   *nzb.NZB
	RepairedNZB   *nzb.NZB // nil if no repair was needed or possible
	BadSegments   int      // how many segments were absent from Usenet
	RepairedCount int      // how many were substituted with recovery blocks
	Par2Fetched   int64    // bytes of par2 data downloaded
	Repaired      bool     // true if NZB was modified
	Warnings      []string
}

// Engine performs NZB repair.
type Engine struct {
	pool      *nntp.Pool
	maxPar2MB int
	verbose   bool

	// par2 set cache — keyed by NZB identity, capped at maxCacheEntries.
	mu              sync.Mutex
	cache           map[string]*par2.Set
	cacheOrder      []string
	maxCacheEntries int

	// sem limits concurrent repairs so they don't fight over NNTP connections
	sem chan struct{}
}

// New creates a repair Engine.
func New(pool *nntp.Pool, maxPar2MB int, verbose bool) *Engine {
	return &Engine{
		pool:            pool,
		maxPar2MB:       maxPar2MB,
		verbose:         verbose,
		cache:           make(map[string]*par2.Set),
		maxCacheEntries: 20,
		sem:             make(chan struct{}, 2), // max 2 concurrent repairs
	}
}

// Repair takes an NZB, fetches par2 data, checks which segments are
// missing on Usenet, and returns a (possibly rewritten) NZB.
func (e *Engine) Repair(n *nzb.NZB) (*Result, error) {
	// Limit concurrent repairs to avoid starving the NNTP connection pool
	e.sem <- struct{}{}
	defer func() { <-e.sem }()

	result := &Result{OriginalNZB: n}

	par2Files := n.Par2Files()
	if len(par2Files) == 0 {
		result.Warnings = append(result.Warnings, "no par2 files in NZB, skipping repair")
		return result, nil
	}

	log.Printf("repair: fetching par2 data (%d files)...", len(par2Files))

	// --- Step 1: fetch par2 index file only (not volumes) to get segment checksums ---
	set, fetched, err := e.fetchPar2Set(n)
	if err != nil {
		result.Warnings = append(result.Warnings, fmt.Sprintf("par2 fetch failed: %v", err))
		log.Printf("repair: par2 fetch failed: %v — forwarding original NZB", err)
		return result, nil
	}
	result.Par2Fetched = fetched
	log.Printf("repair: par2 loaded %.1f KB, sliceSize=%d recovery=%d",
		float64(fetched)/1024, set.SliceSize, set.RecoveryCount())

	// --- Step 2: STAT each media segment to find missing ones ---
	log.Printf("repair: checking segments via STAT...")
	missing := e.findMissingSegments(n)
	result.BadSegments = len(missing)
	log.Printf("repair: found %d missing segments", len(missing))

	if len(missing) == 0 {
		log.Printf("repair: all segments present, no repair needed")
		return result, nil
	}

	log.Printf("repair: %d missing segments, have %d recovery blocks",
		len(missing), set.RecoveryCount())

	if !set.HasRecovery() {
		result.Warnings = append(result.Warnings, "missing segments but no recovery blocks available")
		return result, nil
	}

	if set.RecoveryCount() < len(missing) {
		result.Warnings = append(result.Warnings,
			fmt.Sprintf("need %d recovery blocks, only have %d — partial repair",
				len(missing), set.RecoveryCount()))
	}

	rewritten, repaired := e.rewriteNZB(n, missing, set, n.Par2Files())
	result.RepairedNZB = rewritten
	result.RepairedCount = repaired
	result.Repaired = repaired > 0

	log.Printf("repair: rewrote NZB — substituted %d/%d missing segments", repaired, len(missing))
	return result, nil
}

// fetchPar2Set fetches all par2 files for the NZB and parses them into a Set.
func (e *Engine) fetchPar2Set(n *nzb.NZB) (*par2.Set, int64, error) {
	cacheKey := fmt.Sprintf("%d_%d", n.Par2TotalBytes(), len(n.Par2Files()))
	e.mu.Lock()
	if cached, ok := e.cache[cacheKey]; ok {
		e.mu.Unlock()
		return cached, 0, nil
	}
	e.mu.Unlock()

	par2Files := n.Par2Files()
	maxBytes := int64(e.maxPar2MB) * 1024 * 1024

	var blobs [][]byte
	var totalFetched int64

	for _, pf := range par2Files {
		if maxBytes > 0 && totalFetched >= maxBytes {
			log.Printf("repair: reached par2 byte limit (%d MB), stopping", e.maxPar2MB)
			break
		}

		log.Printf("repair: fetching par2 file %q...", pf.Subject)
		data, err := e.fetchFile(pf)
		if err != nil {
			log.Printf("repair: failed to fetch par2 file: %v", err)
			continue
		}
		log.Printf("repair: fetched %.1f KB", float64(len(data))/1024)
		blobs = append(blobs, data)
		totalFetched += int64(len(data))
	}

	if len(blobs) == 0 {
		return nil, 0, fmt.Errorf("could not fetch any par2 data")
	}

	set, err := par2.ParseAll(blobs)
	if err != nil {
		return nil, totalFetched, fmt.Errorf("par2 parse: %w", err)
	}

	e.mu.Lock()
	// Evict oldest entry if at capacity
	if len(e.cache) >= e.maxCacheEntries && len(e.cacheOrder) > 0 {
		oldest := e.cacheOrder[0]
		e.cacheOrder = e.cacheOrder[1:]
		delete(e.cache, oldest)
	}
	e.cache[cacheKey] = set
	e.cacheOrder = append(e.cacheOrder, cacheKey)
	e.mu.Unlock()

	return set, totalFetched, nil
}

// fetchFile downloads all segments of an NZB file entry and concatenates them.
func (e *Engine) fetchFile(f *nzb.File) ([]byte, error) {
	segments := f.SortedSegments()
	mids := make([]string, len(segments))
	for i, s := range segments {
		mids[i] = s.MID()
	}

	articles, errs := e.pool.FetchArticles(mids)
	if len(errs) > 0 && e.verbose {
		for _, err := range errs {
			log.Printf("repair: segment fetch error: %v", err)
		}
	}

	var buf bytes.Buffer
	for _, seg := range segments {
		data, ok := articles[seg.MID()]
		if !ok {
			return nil, fmt.Errorf("segment %d (%s) not available", seg.Number, seg.MID())
		}
		buf.Write(data)
	}
	return buf.Bytes(), nil
}

type missingSegment struct {
	file    *nzb.File
	segment nzb.Segment
}

// findMissingSegments STATs each media segment and returns those not found.
func (e *Engine) findMissingSegments(n *nzb.NZB) []missingSegment {
	type work struct {
		file *nzb.File
		seg  nzb.Segment
	}
	type result struct {
		w       work
		present bool
	}

	mediaFiles := n.MediaFiles()
	var jobs []work
	for _, f := range mediaFiles {
		for _, seg := range f.Segments {
			jobs = append(jobs, work{file: f, seg: seg})
		}
	}

	log.Printf("repair: STATting %d segments across %d media files...", len(jobs), len(mediaFiles))

	// Fan out STAT checks concurrently
	resultCh := make(chan result, len(jobs))
	// Limit goroutines to avoid thundering herd
	sem := make(chan struct{}, 32)
	var wg sync.WaitGroup
	for _, j := range jobs {
		j := j
		wg.Add(1)
		sem <- struct{}{}
		go func() {
			defer wg.Done()
			defer func() { <-sem }()
			present := e.pool.CheckArticle(j.seg.MID())
			resultCh <- result{w: j, present: present}
		}()
	}
	go func() {
		wg.Wait()
		close(resultCh)
	}()

	var missing []missingSegment
	for r := range resultCh {
		if !r.present {
			missing = append(missing, missingSegment{
				file:    r.w.file,
				segment: r.w.seg,
			})
		}
	}
	return missing
}

// rewriteNZB produces a modified NZB where missing media segments are
// replaced by recovery block article IDs from the par2 files.
// Returns the rewritten NZB and the count of substitutions made.
func (e *Engine) rewriteNZB(
	original *nzb.NZB,
	missing []missingSegment,
	set *par2.Set,
	par2Files []*nzb.File,
) (*nzb.NZB, int) {
	// Build a flat list of recovery article IDs in order
	// Each par2 recovery file's segments are individual recovery blocks
	var recoveryIDs []string
	for _, pf := range par2Files {
		if pf.IsPar2Index() {
			continue // index has no recovery data
		}
		for _, seg := range pf.SortedSegments() {
			recoveryIDs = append(recoveryIDs, seg.MID())
		}
	}

	if len(recoveryIDs) == 0 {
		return original, 0
	}

	// Deep-copy the NZB so we don't mutate the original
	rewritten := deepCopyNZB(original)

	repaired := 0
	for i, ms := range missing {
		if i >= len(recoveryIDs) {
			break // ran out of recovery blocks
		}
		if rewritten.ReplaceSegment(ms.file.Subject, ms.segment.Number, recoveryIDs[i]) {
			repaired++
		}
	}

	return rewritten, repaired
}

// deepCopyNZB makes a shallow-enough copy that we can safely mutate Segments.
func deepCopyNZB(original *nzb.NZB) *nzb.NZB {
	out := &nzb.NZB{
		XMLName: original.XMLName,
		Meta:    original.Meta,
	}
	for _, f := range original.Files {
		newFile := &nzb.File{
			Subject:  f.Subject,
			Poster:   f.Poster,
			Date:     f.Date,
			Groups:   f.Groups,
			Segments: make([]nzb.Segment, len(f.Segments)),
		}
		for i, s := range f.Segments {
			newFile.Segments[i] = s
		}
		out.Files = append(out.Files, newFile)
	}
	return out
}
