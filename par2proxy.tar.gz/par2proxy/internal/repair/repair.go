// Package repair fetches par2 data for an NZB, checks which media segments
// are missing/corrupt, and rewrites the NZB so that Decypharr receives a
// version pointing at recovery slices instead of bad segments.
//
// Crucially: we never download the media files. Only par2 data is fetched.
package repair

import (
	"bytes"
	"fmt"
	"log"
	"strings"
	"sync"

	"github.com/par2proxy/internal/nntp"
	"github.com/par2proxy/internal/nzb"
	"github.com/par2proxy/internal/par2"
)

// Result is what the repair engine produces.
type Result struct {
	OriginalNZB   *nzb.NZB
	RepairedNZB   *nzb.NZB   // nil if no repair was needed or possible
	Par2Set       *par2.Set  // fetched par2 set, kept for RepairWithMissing
	BadSegments   int
	RepairedCount int
	Par2Fetched   int64
	Repaired      bool
	Warnings      []string
}

// Engine performs NZB repair.
type Engine struct {
	pool      *nntp.Pool
	maxPar2MB int
	verbose   bool

	// par2 set cache — keyed by NZB identity, capped at maxCacheEntries.
	mu              sync.Mutex
	cache           map[string]*par2.Set
	cacheOrder      []string
	maxCacheEntries int

	// sem limits concurrent repairs so they don't fight over NNTP connections
	sem chan struct{}
}

// New creates a repair Engine.
func New(pool *nntp.Pool, maxPar2MB int, verbose bool) *Engine {
	return &Engine{
		pool:            pool,
		maxPar2MB:       maxPar2MB,
		verbose:         verbose,
		cache:           make(map[string]*par2.Set),
		maxCacheEntries: 20,
		sem:             make(chan struct{}, 2), // max 2 concurrent repairs
	}
}

// Repair takes an NZB, fetches par2 data, checks which segments are
// missing on Usenet, and returns a (possibly rewritten) NZB.
func (e *Engine) Repair(n *nzb.NZB) (*Result, error) {
	e.sem <- struct{}{}
	defer func() { <-e.sem }()

	result := &Result{OriginalNZB: n}

	par2Files := n.Par2Files()
	if len(par2Files) == 0 {
		result.Warnings = append(result.Warnings, "no par2 files in NZB, skipping repair")
		return result, nil
	}

	log.Printf("repair: fetching par2 data (%d files)...", len(par2Files))
	set, fetched, err := e.fetchPar2Set(n)
	if err != nil {
		result.Warnings = append(result.Warnings, fmt.Sprintf("par2 fetch failed: %v", err))
		log.Printf("repair: par2 fetch failed: %v — forwarding original NZB", err)
		return result, nil
	}
	result.Par2Fetched = fetched
	log.Printf("repair: par2 ready (%.1f KB, %d recovery blocks)", float64(fetched)/1024, set.RecoveryCount())
	// Store set in result for use by RepairWithMissing if Decypharr reports errors
	result.Par2Set = set
	return result, nil
}

// RepairWithMissing rewrites the NZB substituting known-missing message-IDs
// with recovery blocks from the par2 set. Called when Decypharr reports
// ARTICLE_NOT_FOUND for specific segments.
func (e *Engine) RepairWithMissing(n *nzb.NZB, missingMIDs []string) (*Result, error) {
	result := &Result{OriginalNZB: n}
	if len(missingMIDs) == 0 {
		return result, nil
	}
	log.Printf("repair: repairing %d known-missing segments", len(missingMIDs))

	set, fetched, err := e.fetchPar2Set(n)
	if err != nil {
		result.Warnings = append(result.Warnings, fmt.Sprintf("par2 fetch failed: %v", err))
		return result, nil
	}
	result.Par2Fetched = fetched

	if !set.HasRecovery() {
		result.Warnings = append(result.Warnings, "no recovery blocks available")
		return result, nil
	}

	missingSet := make(map[string]bool, len(missingMIDs))
	for _, mid := range missingMIDs {
		bare := strings.Trim(mid, "<>")
		missingSet[bare] = true
		missingSet["<"+bare+">"] = true
	}

	var missing []missingSegment
	for _, f := range n.MediaFiles() {
		for _, seg := range f.Segments {
			mid := seg.MID()
			if missingSet[mid] || missingSet["<"+mid+">"] {
				missing = append(missing, missingSegment{file: f, segment: seg})
			}
		}
	}

	if len(missing) == 0 {
		log.Printf("repair: could not match missing MIDs to NZB segments")
		return result, nil
	}

	result.BadSegments = len(missing)
	log.Printf("repair: %d missing segments matched, have %d recovery blocks", len(missing), set.RecoveryCount())

	rewritten, repaired := e.rewriteNZB(n, missing, set, n.Par2Files())
	result.RepairedNZB = rewritten
	result.RepairedCount = repaired
	result.Repaired = repaired > 0
	log.Printf("repair: substituted %d/%d missing segments with recovery blocks", repaired, len(missing))
	return result, nil
}


// fetchPar2Set fetches all par2 files for the NZB and parses them into a Set.
func (e *Engine) fetchPar2Set(n *nzb.NZB) (*par2.Set, int64, error) {
	cacheKey := fmt.Sprintf("%d_%d", n.Par2TotalBytes(), len(n.Par2Files()))
	e.mu.Lock()
	if cached, ok := e.cache[cacheKey]; ok {
		e.mu.Unlock()
		return cached, 0, nil
	}
	e.mu.Unlock()

	par2Files := n.Par2Files()
	maxBytes := int64(e.maxPar2MB) * 1024 * 1024

	var blobs [][]byte
	var totalFetched int64

	for _, pf := range par2Files {
		if maxBytes > 0 && totalFetched >= maxBytes {
			log.Printf("repair: reached par2 byte limit (%d MB), stopping", e.maxPar2MB)
			break
		}

		log.Printf("repair: fetching par2 file %q...", pf.Subject)
		data, missing, err := e.fetchFile(pf)
		if err != nil {
			log.Printf("repair: failed to fetch par2 file: %v", err)
			continue
		}
		if missing > 0 {
			log.Printf("repair: par2 file had %d missing segments, using partial data", missing)
		}
		log.Printf("repair: fetched %.1f KB", float64(len(data))/1024)
		blobs = append(blobs, data)
		totalFetched += int64(len(data))
	}

	if len(blobs) == 0 {
		log.Printf("repair: all %d par2 files are missing from Usenet — this NZB is unrecoverable", len(par2Files))
		return nil, 0, fmt.Errorf("could not fetch any par2 data")
	}

	set, err := par2.ParseAll(blobs)
	if err != nil {
		return nil, totalFetched, fmt.Errorf("par2 parse: %w", err)
	}

	e.mu.Lock()
	// Evict oldest entry if at capacity
	if len(e.cache) >= e.maxCacheEntries && len(e.cacheOrder) > 0 {
		oldest := e.cacheOrder[0]
		e.cacheOrder = e.cacheOrder[1:]
		delete(e.cache, oldest)
	}
	e.cache[cacheKey] = set
	e.cacheOrder = append(e.cacheOrder, cacheKey)
	e.mu.Unlock()

	return set, totalFetched, nil
}

// fetchFile downloads all segments of an NZB file entry and concatenates them.
// It tolerates missing segments — returns whatever data was fetched plus a count of missing.
func (e *Engine) fetchFile(f *nzb.File) ([]byte, int, error) {
	segments := f.SortedSegments()
	mids := make([]string, len(segments))
	for i, s := range segments {
		mids[i] = s.MID()
	}

	articles, errs := e.pool.FetchArticles(mids)
	for _, err := range errs {
		log.Printf("repair: segment fetch error: %v", err)
	}

	missing := 0
	var buf bytes.Buffer
	for _, seg := range segments {
		data, ok := articles[seg.MID()]
		if !ok {
			missing++
			continue
		}
		buf.Write(data)
	}

	if buf.Len() == 0 {
		return nil, missing, fmt.Errorf("no segments fetched for %q", f.Subject)
	}
	if missing > 0 {
		log.Printf("repair: fetched %d/%d segments for %q (%d missing)", len(segments)-missing, len(segments), f.Subject, missing)
	}
	return buf.Bytes(), missing, nil
}

type missingSegment struct {
	file    *nzb.File
	segment nzb.Segment
}

// findMissingSegments STATs each media segment and returns those not found.
func (e *Engine) findMissingSegments(n *nzb.NZB) []missingSegment {
	type work struct {
		file *nzb.File
		seg  nzb.Segment
	}
	type result struct {
		w       work
		present bool
	}

	mediaFiles := n.MediaFiles()
	var jobs []work
	for _, f := range mediaFiles {
		for _, seg := range f.Segments {
			jobs = append(jobs, work{file: f, seg: seg})
		}
	}

	log.Printf("repair: STATting %d segments across %d media files...", len(jobs), len(mediaFiles))

	// Fan out STAT checks concurrently
	resultCh := make(chan result, len(jobs))
	// Limit goroutines to avoid thundering herd
	sem := make(chan struct{}, 32)
	var wg sync.WaitGroup
	for _, j := range jobs {
		j := j
		wg.Add(1)
		sem <- struct{}{}
		go func() {
			defer wg.Done()
			defer func() { <-sem }()
			present := e.pool.CheckArticle(j.seg.MID())
			resultCh <- result{w: j, present: present}
		}()
	}
	go func() {
		wg.Wait()
		close(resultCh)
	}()

	var missing []missingSegment
	for r := range resultCh {
		if !r.present {
			missing = append(missing, missingSegment{
				file:    r.w.file,
				segment: r.w.seg,
			})
		}
	}
	return missing
}

// rewriteNZB produces a modified NZB where missing media segments are
// replaced by recovery block article IDs from the par2 files.
// Returns the rewritten NZB and the count of substitutions made.
func (e *Engine) rewriteNZB(
	original *nzb.NZB,
	missing []missingSegment,
	set *par2.Set,
	par2Files []*nzb.File,
) (*nzb.NZB, int) {
	// Build a flat list of recovery article IDs in order
	// Each par2 recovery file's segments are individual recovery blocks
	var recoveryIDs []string
	for _, pf := range par2Files {
		if pf.IsPar2Index() {
			continue // index has no recovery data
		}
		for _, seg := range pf.SortedSegments() {
			recoveryIDs = append(recoveryIDs, seg.MID())
		}
	}

	if len(recoveryIDs) == 0 {
		return original, 0
	}

	// Deep-copy the NZB so we don't mutate the original
	rewritten := deepCopyNZB(original)

	repaired := 0
	for i, ms := range missing {
		if i >= len(recoveryIDs) {
			break // ran out of recovery blocks
		}
		if rewritten.ReplaceSegment(ms.file.Subject, ms.segment.Number, recoveryIDs[i]) {
			repaired++
		}
	}

	return rewritten, repaired
}

// deepCopyNZB makes a shallow-enough copy that we can safely mutate Segments.
func deepCopyNZB(original *nzb.NZB) *nzb.NZB {
	out := &nzb.NZB{
		XMLName: original.XMLName,
		Meta:    original.Meta,
	}
	for _, f := range original.Files {
		newFile := &nzb.File{
			Subject:  f.Subject,
			Poster:   f.Poster,
			Date:     f.Date,
			Groups:   f.Groups,
			Segments: make([]nzb.Segment, len(f.Segments)),
		}
		for i, s := range f.Segments {
			newFile.Segments[i] = s
		}
		out.Files = append(out.Files, newFile)
	}
	return out
}
