package config

import (
	"encoding/json"
	"os"
	"strconv"
	"strings"
)

type NNTPProvider struct {
	Host           string `json:"host"`
	Port           int    `json:"port"`
	Username       string `json:"username"`
	Password       string `json:"password"`
	TLS            bool   `json:"tls"`
	MaxConnections int    `json:"max_connections"`
}

// ArrConfig holds credentials and category for one Sonarr/Radarr/etc instance.
type ArrConfig struct {
	Name     string `json:"name"`     // display name e.g. "Sonarr"
	URL      string `json:"url"`      // e.g. http://sonarr:8989
	APIKey   string `json:"api_key"`  // Arr API key
	Category string `json:"category"` // e.g. "sonarr" — subfolder and job matcher
}

type Config struct {
	ListenAddr      string `json:"listen_addr"`
	APIKey          string `json:"api_key"`
	DecypharrURL    string `json:"decypharr_url"`
	DecypharrAPIKey string `json:"decypharr_api_key"` // Bearer token for Decypharr REST API

	Arrs          []ArrConfig    `json:"arrs"`
	NNTPProviders []NNTPProvider `json:"nntp_providers"`

	MaxPar2MB int  `json:"max_par2_mb"`
	Verbose   bool `json:"verbose"`
}

// ArrForCategory returns the ArrConfig whose Category matches cat (case-insensitive).
// Falls back to the first arr if no match, or empty ArrConfig if none configured.
func (c *Config) ArrForCategory(cat string) ArrConfig {
	cat = strings.ToLower(strings.TrimSpace(cat))
	for _, a := range c.Arrs {
		if strings.ToLower(a.Category) == cat {
			return a
		}
	}
	if len(c.Arrs) > 0 {
		return c.Arrs[0]
	}
	return ArrConfig{}
}

func Load(path string) (*Config, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	cfg := defaults()
	if err := json.NewDecoder(f).Decode(cfg); err != nil {
		return nil, err
	}
	return cfg, nil
}

func FromEnv() *Config {
	cfg := defaults()

	if v := os.Getenv("LISTEN_ADDR"); v != "" {
		cfg.ListenAddr = v
	}
	if v := os.Getenv("API_KEY"); v != "" {
		cfg.APIKey = v
	}
	if v := os.Getenv("DECYPHARR_URL"); v != "" {
		cfg.DecypharrURL = v
	}
	if v := os.Getenv("DECYPHARR_API_KEY"); v != "" {
		cfg.DecypharrAPIKey = v
	}
	if v := os.Getenv("MAX_PAR2_MB"); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			cfg.MaxPar2MB = n
		}
	}
	if v := os.Getenv("VERBOSE"); v == "true" || v == "1" {
		cfg.Verbose = true
	}

	// Legacy single-arr env vars
	arrURL := os.Getenv("ARR_URL")
	arrKey := os.Getenv("ARR_API_KEY")
	arrCat := os.Getenv("ARR_CATEGORY")
	if arrURL != "" {
		if arrCat == "" {
			arrCat = "sonarr"
		}
		cfg.Arrs = []ArrConfig{{Name: "Arr", URL: arrURL, APIKey: arrKey, Category: arrCat}}
	}

	// Single NNTP provider
	if host := os.Getenv("NNTP_HOST"); host != "" {
		cfg.NNTPProviders = []NNTPProvider{providerFromEnvPrefix("NNTP_")}
	}

	// Multi-provider: NNTP_HOST_0, NNTP_HOST_1, ...
	for i := 0; ; i++ {
		prefix := "NNTP_" + strconv.Itoa(i) + "_"
		if os.Getenv(prefix+"HOST") == "" {
			break
		}
		cfg.NNTPProviders = append(cfg.NNTPProviders, providerFromEnvPrefix(prefix))
	}

	return cfg
}

func providerFromEnvPrefix(prefix string) NNTPProvider {
	p := NNTPProvider{
		Host:           os.Getenv(prefix + "HOST"),
		Username:       os.Getenv(prefix + "USER"),
		Password:       os.Getenv(prefix + "PASS"),
		TLS:            true,
		Port:           563,
		MaxConnections: 8,
	}
	if v := os.Getenv(prefix + "PORT"); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			p.Port = n
		}
	}
	tls := strings.ToLower(os.Getenv(prefix + "TLS"))
	if tls == "false" || tls == "0" {
		p.TLS = false
		if p.Port == 563 {
			p.Port = 119
		}
	}
	if v := os.Getenv(prefix + "CONNECTIONS"); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			p.MaxConnections = n
		}
	}
	return p
}

func defaults() *Config {
	return &Config{
		ListenAddr:   ":8383",
		APIKey:       "par2proxy",
		DecypharrURL: "http://decypharr:8282",
		MaxPar2MB:    100,
	}
}
