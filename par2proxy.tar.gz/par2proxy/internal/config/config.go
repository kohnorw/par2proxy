package config

import (
	"encoding/json"
	"os"
	"strconv"
	"strings"
)

type NNTPProvider struct {
	Host           string `json:"host"`
	Port           int    `json:"port"`
	Username       string `json:"username"`
	Password       string `json:"password"`
	TLS            bool   `json:"tls"`
	MaxConnections int    `json:"max_connections"`
}

type Config struct {
	// This service
	ListenAddr string `json:"listen_addr"` // :8383
	APIKey     string `json:"api_key"`     // what Sonarr uses to auth to us

	// Downstream Decypharr SABnzbd endpoint
	DecypharrURL      string `json:"decypharr_url"`      // http://decypharr:8282
	DecypharrAPIKey   string `json:"decypharr_api_key"`  // Decypharr Bearer token (REST API)
	DecypharrUsername string `json:"decypharr_username"` // Arr host URL — used as SABnzbd username in Decypharr
	DecypharrPassword string `json:"decypharr_password"` // Arr API token — used as SABnzbd password in Decypharr

	// Sonarr / Radarr (stored so test button and display work; maps to DecypharrUsername/Password)
	ArrURL    string `json:"arr_url"`     // e.g. http://sonarr:8989
	ArrAPIKey string `json:"arr_api_key"` // Sonarr/Radarr API key

	// NNTP providers (same as Decypharr's usenet config)
	NNTPProviders []NNTPProvider `json:"nntp_providers"`

	// Behaviour
	MaxPar2MB int  `json:"max_par2_mb"` // how much par2 data to fetch, default 100
	Verbose   bool `json:"verbose"`
}

func Load(path string) (*Config, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	cfg := defaults()
	if err := json.NewDecoder(f).Decode(cfg); err != nil {
		return nil, err
	}
	return cfg, nil
}

// FromEnv builds config entirely from environment variables.
// Supports multiple NNTP providers via NNTP_HOST_0, NNTP_HOST_1 etc,
// or a single provider via NNTP_HOST.
func FromEnv() *Config {
	cfg := defaults()

	if v := os.Getenv("LISTEN_ADDR"); v != "" {
		cfg.ListenAddr = v
	}
	if v := os.Getenv("API_KEY"); v != "" {
		cfg.APIKey = v
	}
	if v := os.Getenv("DECYPHARR_URL"); v != "" {
		cfg.DecypharrURL = v
	}
	if v := os.Getenv("DECYPHARR_API_KEY"); v != "" {
		cfg.DecypharrAPIKey = v
	}
	if v := os.Getenv("DECYPHARR_USERNAME"); v != "" {
		cfg.DecypharrUsername = v
	}
	if v := os.Getenv("DECYPHARR_PASSWORD"); v != "" {
		cfg.DecypharrPassword = v
	}
	if v := os.Getenv("ARR_URL"); v != "" {
		cfg.ArrURL = v
	}
	if v := os.Getenv("ARR_API_KEY"); v != "" {
		cfg.ArrAPIKey = v
	}
	if v := os.Getenv("MAX_PAR2_MB"); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			cfg.MaxPar2MB = n
		}
	}
	if v := os.Getenv("VERBOSE"); v == "true" || v == "1" {
		cfg.Verbose = true
	}

	// Single-provider shorthand
	if host := os.Getenv("NNTP_HOST"); host != "" {
		p := providerFromEnvPrefix("NNTP_")
		cfg.NNTPProviders = []NNTPProvider{p}
	}

	// Multi-provider: NNTP_HOST_0, NNTP_HOST_1, ...
	for i := 0; ; i++ {
		prefix := "NNTP_" + strconv.Itoa(i) + "_"
		if os.Getenv(prefix+"HOST") == "" {
			break
		}
		cfg.NNTPProviders = append(cfg.NNTPProviders, providerFromEnvPrefix(prefix))
	}

	return cfg
}

func providerFromEnvPrefix(prefix string) NNTPProvider {
	p := NNTPProvider{
		Host:           os.Getenv(prefix + "HOST"),
		Username:       os.Getenv(prefix + "USER"),
		Password:       os.Getenv(prefix + "PASS"),
		TLS:            true,
		Port:           563,
		MaxConnections: 8,
	}
	if v := os.Getenv(prefix + "PORT"); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			p.Port = n
		}
	}
	tls := strings.ToLower(os.Getenv(prefix + "TLS"))
	if tls == "false" || tls == "0" {
		p.TLS = false
		if p.Port == 563 {
			p.Port = 119
		}
	}
	if v := os.Getenv(prefix + "CONNECTIONS"); v != "" {
		if n, err := strconv.Atoi(v); err == nil {
			p.MaxConnections = n
		}
	}
	return p
}

func defaults() *Config {
	return &Config{
		ListenAddr:   ":8383",
		APIKey:       "par2proxy",
		DecypharrURL: "http://decypharr:8282",
		MaxPar2MB:    100,
	}
}
