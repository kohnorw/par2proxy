package sweeper

import (
	"encoding/json"
	"net/http"
	"strings"
)

// RegisterRoutes mounts sweep API routes on mux.
//
//   POST /api/sweep/start        — start a new sweep
//   POST /api/sweep/stop         — cancel running sweep
//   GET  /api/sweep/status       — current sweep status + broken entry list
//   GET  /api/sweep/history      — past sweep runs
//   POST /api/sweep/decypharr    — trigger Decypharr's own built-in repair sweep
//   GET  /api/sweep/broken       — list broken entries from Decypharr
func (s *Sweeper) RegisterRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/api/sweep/start", s.handleStart)
	mux.HandleFunc("/api/sweep/stop", s.handleStop)
	mux.HandleFunc("/api/sweep/status", s.handleStatus)
	mux.HandleFunc("/api/sweep/history", s.handleHistory)
	mux.HandleFunc("/api/sweep/decypharr", s.handleDecypharrRepair)
	mux.HandleFunc("/api/sweep/broken", s.handleBroken)
}

func (s *Sweeper) handleStart(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}
	run, err := s.Start()
	if err != nil {
		jsonResp(w, map[string]interface{}{"error": err.Error()}, http.StatusConflict)
		return
	}
	jsonResp(w, map[string]interface{}{"run_id": run.ID, "status": "started"}, http.StatusOK)
}

func (s *Sweeper) handleStop(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}
	s.Stop()
	jsonResp(w, map[string]interface{}{"status": "stopped"}, http.StatusOK)
}

func (s *Sweeper) handleStatus(w http.ResponseWriter, r *http.Request) {
	s.mu.RLock()
	run := s.current
	s.mu.RUnlock()

	if run == nil {
		jsonResp(w, map[string]interface{}{"running": false, "run": nil}, http.StatusOK)
		return
	}
	snap := run.Snapshot()
	jsonResp(w, map[string]interface{}{"running": snap.Running, "run": snap}, http.StatusOK)
}

func (s *Sweeper) handleHistory(w http.ResponseWriter, r *http.Request) {
	hist := s.History()
	snaps := make([]SweepRunSnapshot, len(hist))
	for i, h := range hist {
		snaps[i] = h.Snapshot()
	}
	jsonResp(w, snaps, http.StatusOK)
}

func (s *Sweeper) handleDecypharrRepair(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}
	if err := s.TriggerDecypharrRepair(); err != nil {
		code := http.StatusInternalServerError
		if strings.Contains(err.Error(), "already running") {
			code = http.StatusConflict
		}
		jsonResp(w, map[string]interface{}{"error": err.Error()}, code)
		return
	}
	// Also fetch Decypharr's live status
	status, _ := s.DecypharrRepairStatus()
	jsonResp(w, map[string]interface{}{"status": "triggered", "decypharr_status": status}, http.StatusOK)
}

func (s *Sweeper) handleBroken(w http.ResponseWriter, r *http.Request) {
	entries, err := s.BrokenEntries()
	if err != nil {
		jsonResp(w, map[string]interface{}{"error": err.Error()}, http.StatusBadGateway)
		return
	}
	jsonResp(w, map[string]interface{}{"count": len(entries), "entries": entries}, http.StatusOK)
}

func jsonResp(w http.ResponseWriter, v interface{}, code int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(v)
}

// RouteHTTP dispatches a request to the appropriate sweep handler.
// Used by main.go to delegate from a middleware that checks configuration.
func (s *Sweeper) RouteHTTP(w http.ResponseWriter, r *http.Request) {
	path := r.URL.Path
	switch {
	case path == "/api/sweep/start":
		s.handleStart(w, r)
	case path == "/api/sweep/stop":
		s.handleStop(w, r)
	case path == "/api/sweep/status":
		s.handleStatus(w, r)
	case path == "/api/sweep/history":
		s.handleHistory(w, r)
	case path == "/api/sweep/decypharr":
		s.handleDecypharrRepair(w, r)
	case path == "/api/sweep/broken":
		s.handleBroken(w, r)
	default:
		http.NotFound(w, r)
	}
}
