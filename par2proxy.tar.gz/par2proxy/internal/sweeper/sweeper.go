// Package sweeper walks Decypharr's usenet library via its REST API,
// finds broken/missing entries, runs par2 repair on their NZBs, and
// resubmits the repaired NZBs back through the SABnzbd endpoint.
package sweeper

import (
	"bytes"
	"encoding/json"
	"context"
	"fmt"
	"io"
	"log"
	"mime/multipart"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/par2proxy/internal/nzb"
	"github.com/par2proxy/internal/repair"
)

// EntryStatus mirrors Decypharr's health entry.
type EntryStatus string

const (
	StatusHealthy EntryStatus = "healthy"
	StatusBroken  EntryStatus = "broken"
	StatusUnknown EntryStatus = "unknown"
)

// HealthEntry is one item from Decypharr's /api/repair/health.
type HealthEntry struct {
	Name        string      `json:"name"`
	Status      EntryStatus `json:"status"`
	Category    string      `json:"category"`
	BrokenFiles []string    `json:"broken_files"`
	CheckedAt   time.Time   `json:"checked_at"`
}

// SweepEntry tracks one entry through our repair sweep.
type SweepEntry struct {
	Name        string
	Category    string
	Status      string // "pending" | "checking" | "repairing" | "done" | "failed" | "skipped"
	BrokenFiles int
	BadSegs     int
	FixedSegs   int
	Par2Bytes   int64
	Error       string
	StartedAt   time.Time
	DoneAt      time.Time
}

// SweepRun is one full repair sweep.
type SweepRun struct {
	mu      sync.RWMutex
	ID        string
	StartedAt time.Time
	DoneAt    time.Time
	Running   bool
	Total     int
	Done      int
	Repaired  int
	Failed    int
	Skipped   int
	Entries   []*SweepEntry

	cancelCh chan struct{}
}

// Sweeper orchestrates bulk repair of Decypharr's usenet library.
type Sweeper struct {
	decypharrURL     string
	decypharrToken   string
	sabnzbdURL       string // par2proxy's own SABnzbd endpoint (for resubmission)
	sabnzbdAPIKey    string
	engine           *repair.Engine
	verbose          bool

	mu      sync.RWMutex
	current *SweepRun
	history []*SweepRun
}

// New creates a Sweeper.
// sabnzbdURL should point back at par2proxy itself (e.g. http://localhost:8383/sabnzbd/api)
// so repaired NZBs go through the full par2proxy → Decypharr pipeline.
func New(decypharrURL, decypharrToken, sabnzbdURL, sabnzbdAPIKey string, engine *repair.Engine, verbose bool) *Sweeper {
	return &Sweeper{
		decypharrURL:   strings.TrimRight(decypharrURL, "/"),
		decypharrToken: decypharrToken,
		sabnzbdURL:     sabnzbdURL,
		sabnzbdAPIKey:  sabnzbdAPIKey,
		engine:         engine,
		verbose:        verbose,
	}
}

// Start launches a sweep in the background. Returns error if one is already running.
func (s *Sweeper) Start() (*SweepRun, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	if s.current != nil && s.current.Running {
		return nil, fmt.Errorf("sweep already running")
	}

	run := &SweepRun{
		ID:        fmt.Sprintf("sweep-%d", time.Now().UnixNano()),
		StartedAt: time.Now(),
		Running:   true,
		cancelCh:  make(chan struct{}),
	}
	s.current = run
	go s.runSweep(run)
	return run, nil
}

// Stop cancels the running sweep.
func (s *Sweeper) Stop() {
	s.mu.RLock()
	run := s.current
	s.mu.RUnlock()
	if run != nil && run.Running {
		close(run.cancelCh)
	}
}

// Current returns the active sweep (nil if none).
func (s *Sweeper) Current() *SweepRun {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return s.current
}

// History returns past completed sweeps.
func (s *Sweeper) History() []*SweepRun {
	s.mu.RLock()
	defer s.mu.RUnlock()
	out := make([]*SweepRun, len(s.history))
	copy(out, s.history)
	return out
}

// TriggerDecypharrRepair asks Decypharr to run its own built-in repair sweep too.
func (s *Sweeper) TriggerDecypharrRepair() error {
	url := s.decypharrURL + "/api/repair/run"
	req, err := http.NewRequest("POST", url, nil)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+s.decypharrToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return fmt.Errorf("POST /api/repair/run: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode == 409 {
		return fmt.Errorf("Decypharr repair already running")
	}
	if resp.StatusCode >= 300 {
		body, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("Decypharr returned %d: %s", resp.StatusCode, body)
	}
	return nil
}

// DecypharrRepairStatus returns Decypharr's current repair sweep status.
func (s *Sweeper) DecypharrRepairStatus() (map[string]interface{}, error) {
	url := s.decypharrURL + "/api/repair/status"
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+s.decypharrToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var out map[string]interface{}
	json.NewDecoder(resp.Body).Decode(&out)
	return out, nil
}

// BrokenEntries fetches entries Decypharr knows are broken.
func (s *Sweeper) BrokenEntries() ([]HealthEntry, error) {
	return s.fetchHealth("broken")
}

// AllEntries fetches all health entries regardless of status.
func (s *Sweeper) AllEntries() ([]HealthEntry, error) {
	return s.fetchHealth("")
}

func (s *Sweeper) fetchHealth(status string) ([]HealthEntry, error) {
	url := s.decypharrURL + "/api/repair/health"
	if status != "" {
		url += "?status=" + status
	}
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return nil, err
	}
	req.Header.Set("Authorization", "Bearer "+s.decypharrToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, fmt.Errorf("GET /api/repair/health: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		body, _ := io.ReadAll(resp.Body)
		return nil, fmt.Errorf("Decypharr returned %d: %s", resp.StatusCode, body)
	}
	var entries []HealthEntry
	if err := json.NewDecoder(resp.Body).Decode(&entries); err != nil {
		return nil, fmt.Errorf("parse health response: %w", err)
	}
	return entries, nil
}

// runSweep is the main sweep goroutine.
func (s *Sweeper) runSweep(run *SweepRun) {
	defer func() {
		run.DoneAt = time.Now()
		run.Running = false
		s.mu.Lock()
		s.history = append([]*SweepRun{run}, s.history...)
		if len(s.history) > 50 {
			s.history = s.history[:50]
		}
		s.mu.Unlock()
		log.Printf("sweeper: run %s complete — %d repaired, %d failed, %d skipped",
			run.ID, run.Repaired, run.Failed, run.Skipped)
	}()

	log.Printf("sweeper: starting run %s", run.ID)

	// Step 1: fetch all broken entries from Decypharr
	entries, err := s.BrokenEntries()
	if err != nil {
		log.Printf("sweeper: failed to fetch broken entries: %v", err)
		run.Running = false
		return
	}

	if len(entries) == 0 {
		log.Printf("sweeper: no broken entries found in Decypharr")
		return
	}

	log.Printf("sweeper: found %d broken entries", len(entries))
	run.Total = len(entries)

	// Build sweep entries
	for _, e := range entries {
		se := &SweepEntry{
			Name:        e.Name,
			Category:    e.Category,
			Status:      "pending",
			BrokenFiles: len(e.BrokenFiles),
			StartedAt:   time.Now(),
		}
		run.mu.Lock()
		run.Entries = append(run.Entries, se)
		run.mu.Unlock()
	}

	// Step 2: process each entry
	for i, entry := range entries {
		select {
		case <-run.cancelCh:
			log.Printf("sweeper: run %s cancelled after %d entries", run.ID, i)
			return
		default:
		}

		se := run.Entries[i]
		s.processEntry(run, se, entry)
	}
}

func (s *Sweeper) processEntry(run *SweepRun, se *SweepEntry, entry HealthEntry) {
	se.Status = "checking"
	log.Printf("sweeper: checking %q (%d broken files)", entry.Name, len(entry.BrokenFiles))

	// Step 1: ask Decypharr for this entry's NZB via the browse API
	nzbData, category, err := s.fetchEntryNZB(entry.Name)
	if err != nil {
		log.Printf("sweeper: [%s] could not fetch NZB: %v", entry.Name, err)
		se.Status = "skipped"
		se.Error = "could not fetch NZB from Decypharr: " + err.Error()
		run.mu.Lock()
		run.Skipped++
		run.Done++
		run.mu.Unlock()
		return
	}

	if category == "" {
		category = entry.Category
	}

	// Step 2: parse and repair
	se.Status = "repairing"
	n, err := nzb.Parse(bytes.NewReader(nzbData))
	if err != nil {
		se.Status = "failed"
		se.Error = "NZB parse: " + err.Error()
		run.mu.Lock()
		run.Failed++
		run.Done++
		run.mu.Unlock()
		return
	}

	if len(n.Par2Files()) == 0 {
		se.Status = "skipped"
		se.Error = "no par2 files in NZB"
		run.mu.Lock()
		run.Skipped++
		run.Done++
		run.mu.Unlock()
		return
	}

	result, err := s.engine.Repair(context.Background(), n)
	if err != nil {
		se.Status = "failed"
		se.Error = "repair engine: " + err.Error()
		run.mu.Lock()
		run.Failed++
		run.Done++
		run.mu.Unlock()
		return
	}

	se.BadSegs = result.BadSegments
	se.FixedSegs = result.RepairedCount
	se.Par2Bytes = result.Par2Fetched

	if !result.Repaired {
		// Decypharr thinks it's broken but par2 says segments are fine — trigger Decypharr's own recheck
		log.Printf("sweeper: [%s] no segments missing per par2, triggering Decypharr recheck", entry.Name)
		s.triggerDecypharrRecheck(entry.Name)
		se.Status = "done"
		se.Error = "no missing segments found; triggered Decypharr recheck"
		run.mu.Lock()
		run.Skipped++
		run.Done++
		run.mu.Unlock()
		return
	}

	// Step 3: marshal repaired NZB and resubmit through par2proxy's own SABnzbd endpoint
	nzbToSubmit := nzbData
	if result.RepairedNZB != nil {
		if rewritten, err := nzb.Marshal(result.RepairedNZB); err == nil {
			nzbToSubmit = rewritten
		}
	}

	if err := s.resubmitNZB(entry.Name, category, nzbToSubmit); err != nil {
		se.Status = "failed"
		se.Error = "resubmit: " + err.Error()
		run.mu.Lock()
		run.Failed++
		run.Done++
		run.mu.Unlock()
		return
	}

	se.Status = "done"
	se.DoneAt = time.Now()
	run.mu.Lock()
	run.Repaired++
	run.Done++
	run.mu.Unlock()

	log.Printf("sweeper: [%s] repaired and resubmitted (%d bad → %d fixed)",
		entry.Name, result.BadSegments, result.RepairedCount)
}

// fetchEntryNZB retrieves the NZB for a named entry via Decypharr's browse API.
// Returns the raw NZB bytes and the detected category.
func (s *Sweeper) fetchEntryNZB(name string) ([]byte, string, error) {
	// Walk browse groups to find which group this entry belongs to
	groups, err := s.browseGroups()
	if err != nil {
		return nil, "", err
	}

	for _, group := range groups {
		if strings.HasPrefix(group, "__") {
			continue // skip __all__, __bad__ meta-groups
		}
		items, err := s.browseGroup(group)
		if err != nil {
			continue
		}
		for _, item := range items {
			if item == name {
				// Found it — fetch its NZB via download endpoint
				nzbData, err := s.downloadEntryNZB(group, name)
				return nzbData, group, err
			}
		}
	}

	// Also try __all__ group as fallback
	items, err := s.browseGroup("__all__")
	if err == nil {
		for _, item := range items {
			if item == name {
				nzbData, err := s.downloadEntryNZB("__all__", name)
				return nzbData, "", err
			}
		}
	}

	return nil, "", fmt.Errorf("entry %q not found in any browse group", name)
}

func (s *Sweeper) browseGroups() ([]string, error) {
	url := s.decypharrURL + "/api/browse/"
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Authorization", "Bearer "+s.decypharrToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	var groups []string
	json.NewDecoder(resp.Body).Decode(&groups)
	return groups, nil
}

func (s *Sweeper) browseGroup(group string) ([]string, error) {
	url := s.decypharrURL + "/api/browse/" + group
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Authorization", "Bearer "+s.decypharrToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	// Response may be []string or [{name:...}] — handle both
	body, _ := io.ReadAll(resp.Body)
	var names []string
	if err := json.Unmarshal(body, &names); err == nil {
		return names, nil
	}
	var objects []struct {
		Name string `json:"name"`
	}
	if err := json.Unmarshal(body, &objects); err == nil {
		for _, o := range objects {
			names = append(names, o.Name)
		}
		return names, nil
	}
	return nil, fmt.Errorf("unexpected browse response shape")
}

// downloadEntryNZB fetches the NZB for a specific entry.
// Decypharr's browse/download endpoint serves the NZB file directly.
func (s *Sweeper) downloadEntryNZB(group, entryName string) ([]byte, error) {
	// Try to get the NZB file from the entry's file list first
	filesURL := s.decypharrURL + "/api/browse/" + group + "/" + entryName
	req, _ := http.NewRequest("GET", filesURL, nil)
	req.Header.Set("Authorization", "Bearer "+s.decypharrToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	// Look for an .nzb file in the listing
	var files []struct {
		Name string `json:"name"`
		Path string `json:"path"`
	}
	if json.Unmarshal(body, &files) == nil {
		for _, f := range files {
			if strings.HasSuffix(strings.ToLower(f.Name), ".nzb") {
				dlURL := s.decypharrURL + "/api/browse/download/" + entryName + "/" + f.Name
				return s.downloadFile(dlURL)
			}
		}
	}

	// Fallback: treat the browse response body as the NZB itself
	if bytes.Contains(body, []byte("<nzb")) {
		return body, nil
	}

	return nil, fmt.Errorf("no NZB file found for %q in group %q", entryName, group)
}

func (s *Sweeper) downloadFile(url string) ([]byte, error) {
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Authorization", "Bearer "+s.decypharrToken)
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		return nil, fmt.Errorf("HTTP %d from %s", resp.StatusCode, url)
	}
	return io.ReadAll(resp.Body)
}

// resubmitNZB POSTs an NZB back through par2proxy's own SABnzbd API.
// Because par2proxy is the destination, this NZB will be forwarded to Decypharr again —
// but this time with repaired segment IDs.
func (s *Sweeper) resubmitNZB(name, category string, nzbData []byte) error {
	var body bytes.Buffer
	mw := multipart.NewWriter(&body)

	fw, err := mw.CreateFormFile("nzbfile", name+".nzb")
	if err != nil {
		return err
	}
	fw.Write(nzbData)
	mw.WriteField("cat", category)
	mw.WriteField("nzbname", name)
	mw.WriteField("apikey", s.sabnzbdAPIKey)
	mw.Close()

	url := strings.TrimRight(s.sabnzbdURL, "/") + "?mode=addfile&output=json"
	req, err := http.NewRequest("POST", url, &body)
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", mw.FormDataContentType())

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return fmt.Errorf("resubmit POST: %w", err)
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		b, _ := io.ReadAll(resp.Body)
		return fmt.Errorf("par2proxy returned %d: %s", resp.StatusCode, b)
	}
	return nil
}

// triggerDecypharrRecheck asks Decypharr to force-recheck a single entry.
func (s *Sweeper) triggerDecypharrRecheck(name string) {
	url := s.decypharrURL + "/api/repair/health/" + name + "/check?fix=true"
	req, _ := http.NewRequest("POST", url, nil)
	req.Header.Set("Authorization", "Bearer "+s.decypharrToken)
	http.DefaultClient.Do(req)
}

// SweepRunSnapshot is a JSON-safe copy of a SweepRun.
type SweepRunSnapshot struct {
	ID        string          `json:"id"`
	StartedAt time.Time       `json:"started_at"`
	DoneAt    time.Time       `json:"done_at"`
	Running   bool            `json:"running"`
	Total     int             `json:"total"`
	Done      int             `json:"done"`
	Repaired  int             `json:"repaired"`
	Failed    int             `json:"failed"`
	Skipped   int             `json:"skipped"`
	Entries   []*SweepEntry   `json:"entries"`
}

func (run *SweepRun) Snapshot() SweepRunSnapshot {
	run.mu.RLock()
	defer run.mu.RUnlock()
	entries := make([]*SweepEntry, len(run.Entries))
	copy(entries, run.Entries)
	return SweepRunSnapshot{
		ID:        run.ID,
		StartedAt: run.StartedAt,
		DoneAt:    run.DoneAt,
		Running:   run.Running,
		Total:     run.Total,
		Done:      run.Done,
		Repaired:  run.Repaired,
		Failed:    run.Failed,
		Skipped:   run.Skipped,
		Entries:   entries,
	}
}

// mu on SweepRun for safe concurrent reads of Entries/counters
func (run *SweepRun) init() {
	// mu is a zero-value sync.RWMutex, always ready
}
