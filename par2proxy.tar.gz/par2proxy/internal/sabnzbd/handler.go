// Package sabnzbd implements a SABnzbd-compatible HTTP API.
// Sonarr/Radarr POST NZBs here; we repair them and forward to Decypharr.
// Status is proxied FROM Decypharr back to Sonarr so completion is accurate.
package sabnzbd

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"mime"
	"mime/multipart"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/par2proxy/internal/nzb"
	"github.com/par2proxy/internal/repair"
)

type jobStatus string

const (
	statusQueued      jobStatus = "Queued"
	statusRepairing   jobStatus = "Repairing"
	statusForwarded   jobStatus = "Downloading" // SABnzbd name Sonarr understands
	statusCompleted   jobStatus = "Completed"
	statusFailed      jobStatus = "Failed"
)

// Job tracks one NZB submission through its full lifecycle.
type Job struct {
	ID            string
	Name          string
	Category      string
	Status        jobStatus
	NZBData       []byte
	RepairedNZB   []byte
	AddedAt       time.Time
	DoneAt        time.Time
	ErrMsg        string
	Par2Bytes     int64
	BadSegs       int
	FixedSegs     int

	// DecypharrJobID is the nzo_id Decypharr assigned when we forwarded the NZB.
	// We poll Decypharr using this ID and mirror its status back to Sonarr.
	DecypharrJobID string

	// StoragePath is the final directory Decypharr reports in its history.
	// We surface this in our own history so Sonarr can find the files.
	StoragePath string
}

// Handler is the SABnzbd API handler.
type Handler struct {
	apiKey      string
	engine      *repair.Engine
	forwardURL  string
	forwardUser string
	forwardPass string
	verbose     bool

	mu          sync.RWMutex
	jobs        map[string]*Job

	// Fetched from Decypharr at Connect() time.
	completeDir string // e.g. /mnt/decypharr  — base for category subdirs
	connected   bool
}

// ConnectResult holds what we learned from Decypharr at startup.
type ConnectResult struct {
	CompleteDir string
	Version     string
	Err         error
}

func New(apiKey, forwardURL, forwardUser, forwardPass string, engine *repair.Engine, verbose bool) *Handler {
	return &Handler{
		apiKey:      apiKey,
		engine:      engine,
		forwardURL:  forwardURL,
		forwardUser: forwardUser,
		forwardPass: forwardPass,
		verbose:     verbose,
		jobs:        make(map[string]*Job),
	}
}

// Connect fetches Decypharr's config (complete_dir, version) so we have the
// real storage path before any jobs are processed.
// It retries up to maxAttempts times with retryDelay between each.
func (h *Handler) Connect(maxAttempts int, retryDelay time.Duration) ConnectResult {
	if maxAttempts <= 0 {
		maxAttempts = 1
	}
	// Try both mode variants — Decypharr may respond to get_config or config
	urls := []string{
		strings.TrimRight(h.forwardURL, "/") + "?mode=get_config&output=json&apikey=" + h.forwardPass,
		strings.TrimRight(h.forwardURL, "/") + "?mode=config&output=json&apikey=" + h.forwardPass,
	}

	var lastErr error
	for attempt := 1; attempt <= maxAttempts; attempt++ {
		for _, url := range urls {
			result, err := h.fetchConfig(url)
			if err == nil {
				h.mu.Lock()
				h.completeDir = result.CompleteDir
				h.connected = true
				h.mu.Unlock()
				return result
			}
			lastErr = err
		}
		if attempt < maxAttempts && retryDelay > 0 {
			log.Printf("sabnzbd: connect attempt %d/%d failed: %v", attempt, maxAttempts, lastErr)
			time.Sleep(retryDelay)
		}
	}
	return ConnectResult{Err: lastErr}
}

// SetCompleteDir pre-seeds the complete_dir so the UI can show it
// before Connect() has confirmed it from Decypharr.
func (h *Handler) SetCompleteDir(dir string) {
	if dir == "" {
		return
	}
	h.mu.Lock()
	if h.completeDir == "" {
		h.completeDir = dir
	}
	h.mu.Unlock()
}

func (h *Handler) fetchConfig(url string) (ConnectResult, error) {
	resp, err := http.Get(url)
	if err != nil {
		return ConnectResult{}, fmt.Errorf("GET %s: %w", url, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 300 {
		return ConnectResult{}, fmt.Errorf("Decypharr returned HTTP %d", resp.StatusCode)
	}

	// Decypharr's config response may be wrapped as {config:{misc:{...}}} (SABnzbd get_config)
	// or directly as {misc:{...}} (mode=config). Handle both.
	var cr struct {
		Config struct {
			Misc struct {
				CompleteDir string `json:"complete_dir"`
				Version     string `json:"version"`
			} `json:"misc"`
		} `json:"config"`
		Misc struct {
			CompleteDir string `json:"complete_dir"`
			Version     string `json:"version"`
		} `json:"misc"`
		// Some implementations put values at top level
		CompleteDir string `json:"complete_dir"`
		Version     string `json:"version"`
	}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return ConnectResult{}, fmt.Errorf("read body: %w", err)
	}
	if err := json.Unmarshal(body, &cr); err != nil {
		return ConnectResult{}, fmt.Errorf("parse config response: %w", err)
	}

	// Prefer config.misc → misc → top-level
	dir := cr.Config.Misc.CompleteDir
	ver := cr.Config.Misc.Version
	if dir == "" {
		dir = cr.Misc.CompleteDir
		ver = cr.Misc.Version
	}
	if dir == "" {
		dir = cr.CompleteDir
		ver = cr.Version
	}
	if dir == "" {
		return ConnectResult{}, fmt.Errorf("Decypharr config missing complete_dir (response: %s)", body)
	}

	return ConnectResult{CompleteDir: dir, Version: ver}, nil
}

// CompleteDir returns the storage base path fetched from Decypharr.
func (h *Handler) CompleteDir() string {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return h.completeDir
}

// IsConnected returns whether we successfully fetched Decypharr config at startup.
func (h *Handler) IsConnected() bool {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return h.connected
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	mode := r.FormValue("mode")
	if mode == "" {
		mode = r.URL.Query().Get("mode")
	}
	key := r.FormValue("apikey")
	if key == "" {
		key = r.URL.Query().Get("apikey")
	}

	// Always log incoming requests so connection issues are diagnosable
	log.Printf("sabnzbd: %s %s mode=%q key_ok=%v host=%s",
		r.Method, r.URL.Path, mode, key == h.apiKey || h.apiKey == "", r.Host)

	if h.apiKey != "" && key != h.apiKey {
		log.Printf("sabnzbd: auth failed — got key %q, expected %q", key, h.apiKey)
		jsonErr(w, "API key invalid", http.StatusUnauthorized)
		return
	}
	switch mode {
	case "addfile", "addurl":
		h.handleAdd(w, r)
	case "queue":
		h.handleQueue(w, r)
	case "history":
		h.handleHistory(w, r)
	case "delete":
		h.handleDelete(w, r)
	case "version":
		// Sonarr expects {"version": "x.x.x"} at the root
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]string{"version": "3.7.2"})
	case "config", "get_config":
		// Sonarr calls mode=get_config during Test; mode=config is the legacy alias.
		// Both must return a categories array or Sonarr null-refs.
		h.handleConfig(w, r)
	default:
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{"status": true, "error": ""})
	}
}

// handleAdd receives an NZB from Sonarr, returns our job ID immediately,
// then processes and forwards to Decypharr asynchronously.
func (h *Handler) handleAdd(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseMultipartForm(32 << 20); err != nil {
		r.ParseForm()
	}
	category := r.FormValue("cat")
	name := r.FormValue("nzbname")

	nzbBytes, filename, err := extractNZB(r)
	if err != nil {
		jsonErr(w, "no NZB: "+err.Error(), http.StatusBadRequest)
		return
	}
	if name == "" {
		name = filename
	}

	id := newID()
	job := &Job{
		ID:       id,
		Name:     name,
		Category: category,
		Status:   statusQueued,
		NZBData:  nzbBytes,
		AddedAt:  time.Now(),
	}

	h.mu.Lock()
	h.jobs[id] = job
	h.mu.Unlock()

	log.Printf("sabnzbd: queued %q (cat=%s id=%s)", name, category, id)
	go h.processJob(job)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"status":  true,
		"nzo_ids": []string{id},
	})
}

func (h *Handler) processJob(job *Job) {
	h.setStatus(job.ID, statusRepairing)

	n, err := nzb.Parse(bytes.NewReader(job.NZBData))
	if err != nil {
		h.failJob(job, "NZB parse error: "+err.Error())
		return
	}

	log.Printf("sabnzbd: [%s] processing %q — %d files, %d par2 files",
		job.ID, job.Name, len(n.Files), len(n.Par2Files()))

	result, err := h.engine.Repair(n)
	if err != nil {
		h.failJob(job, "repair engine error: "+err.Error())
		return
	}

	h.mu.Lock()
	job.BadSegs = result.BadSegments
	job.FixedSegs = result.RepairedCount
	job.Par2Bytes = result.Par2Fetched
	h.mu.Unlock()

	for _, warn := range result.Warnings {
		log.Printf("sabnzbd: [%s] warning: %s", job.ID, warn)
	}

	nzbToForward := job.NZBData
	if result.Repaired && result.RepairedNZB != nil {
		if rewritten, err := nzb.Marshal(result.RepairedNZB); err == nil {
			nzbToForward = rewritten
			h.mu.Lock()
			job.RepairedNZB = rewritten
			h.mu.Unlock()
			log.Printf("sabnzbd: [%s] forwarding REPAIRED NZB (%d bad → %d fixed)",
				job.ID, result.BadSegments, result.RepairedCount)
		} else {
			log.Printf("sabnzbd: [%s] marshal error, forwarding original: %v", job.ID, err)
		}
	} else {
		log.Printf("sabnzbd: [%s] no repair needed, forwarding original", job.ID)
	}

	// Forward to Decypharr and get its job ID
	decypharrID, err := h.forwardToDecypharr(job, nzbToForward)
	if err != nil {
		log.Printf("sabnzbd: [%s] forward failed: %v", job.ID, err)
		h.failJob(job, "forward to Decypharr failed: "+err.Error())
		return
	}

	h.mu.Lock()
	job.DecypharrJobID = decypharrID
	job.Status = statusForwarded
	h.mu.Unlock()

	log.Printf("sabnzbd: [%s] forwarded to Decypharr as %s, polling for completion",
		job.ID, decypharrID)

	// Poll Decypharr until it marks the job done
	h.waitForDecypharr(job, decypharrID)
}

// forwardToDecypharr POSTs the NZB and returns Decypharr's nzo_id.
func (h *Handler) forwardToDecypharr(job *Job, nzbBytes []byte) (string, error) {
	var body bytes.Buffer
	mw := multipart.NewWriter(&body)

	fw, err := mw.CreateFormFile("nzbfile", job.Name+".nzb")
	if err != nil {
		return "", err
	}
	if _, err := fw.Write(nzbBytes); err != nil {
		return "", err
	}
	mw.WriteField("cat", job.Category)
	mw.WriteField("nzbname", job.Name)
	// Decypharr SABnzbd API: username = arr host, password = arr api token
	mw.WriteField("username", h.forwardUser)
	mw.WriteField("apikey", h.forwardPass)
	mw.Close()

	apiURL := strings.TrimRight(h.forwardURL, "/") + "?mode=addfile&output=json"
	req, err := http.NewRequest("POST", apiURL, &body)
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", mw.FormDataContentType())

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("POST to Decypharr: %w", err)
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	if h.verbose {
		log.Printf("sabnzbd: Decypharr addfile response %d: %s", resp.StatusCode, respBody)
	}
	if resp.StatusCode >= 300 {
		return "", fmt.Errorf("Decypharr returned %d: %s", resp.StatusCode, respBody)
	}

	// Parse Decypharr's response to get its job ID
	var addResp struct {
		NzoIDs []string `json:"nzo_ids"`
		Status bool     `json:"status"`
	}
	if err := json.Unmarshal(respBody, &addResp); err != nil || len(addResp.NzoIDs) == 0 {
		// Decypharr may have a different response shape — try fallback
		var alt struct {
			Queue struct {
				NzoIDs []string `json:"nzo_ids"`
			} `json:"queue"`
		}
		if err2 := json.Unmarshal(respBody, &alt); err2 == nil && len(alt.Queue.NzoIDs) > 0 {
			return alt.Queue.NzoIDs[0], nil
		}
		return "", fmt.Errorf("could not parse Decypharr job ID from response: %s", respBody)
	}
	return addResp.NzoIDs[0], nil
}

// waitForDecypharr polls Decypharr's queue then history until the job completes,
// then mirrors the final status (and storage path) back onto our job.
func (h *Handler) waitForDecypharr(job *Job, decypharrID string) {
	const (
		pollInterval = 5 * time.Second
		maxWait      = 4 * time.Hour
	)
	deadline := time.Now().Add(maxWait)

	for time.Now().Before(deadline) {
		time.Sleep(pollInterval)

		// Check Decypharr's queue first
		if inQueue, pct := h.decypharrQueueStatus(decypharrID); inQueue {
			h.mu.Lock()
			job.Status = statusForwarded
			_ = pct // could surface this in the UI later
			h.mu.Unlock()
			continue
		}

		// Check Decypharr's history
		if done, success, storage := h.decypharrHistoryStatus(decypharrID); done {
			h.mu.Lock()
			job.DoneAt = time.Now()
			if success {
				job.Status = statusCompleted
				job.StoragePath = storage
			} else {
				job.Status = statusFailed
				job.ErrMsg = "Decypharr reported failure"
			}
			h.mu.Unlock()

			log.Printf("sabnzbd: [%s] Decypharr job %s %s (storage: %s)",
				job.ID, decypharrID, job.Status, storage)
			return
		}

		// Still not in queue or history — Decypharr may still be processing
		if h.verbose {
			log.Printf("sabnzbd: [%s] Decypharr job %s not yet in history, continuing to poll",
				job.ID, decypharrID)
		}
	}

	// Timeout — mark as failed
	h.mu.Lock()
	job.Status = statusFailed
	job.ErrMsg = "timed out waiting for Decypharr"
	job.DoneAt = time.Now()
	h.mu.Unlock()
	log.Printf("sabnzbd: [%s] timed out waiting for Decypharr job %s", job.ID, decypharrID)
}

// decypharrQueueStatus checks if the job is still in Decypharr's active queue.
// Returns (inQueue, percentDone).
func (h *Handler) decypharrQueueStatus(decypharrID string) (bool, int) {
	url := strings.TrimRight(h.forwardURL, "/") +
		fmt.Sprintf("?mode=queue&output=json&apikey=%s", h.forwardPass)
	resp, err := http.Get(url)
	if err != nil {
		return false, 0
	}
	defer resp.Body.Close()

	var qr struct {
		Queue struct {
			Slots []struct {
				NzoID      string `json:"nzo_id"`
				Percentage string `json:"percentage"`
			} `json:"slots"`
		} `json:"queue"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&qr); err != nil {
		return false, 0
	}
	for _, slot := range qr.Queue.Slots {
		if slot.NzoID == decypharrID {
			var pct int
			fmt.Sscanf(slot.Percentage, "%d", &pct)
			return true, pct
		}
	}
	return false, 0
}

// decypharrHistoryStatus checks Decypharr's history for the job.
// Returns (found, success, storagePath).
func (h *Handler) decypharrHistoryStatus(decypharrID string) (bool, bool, string) {
	url := strings.TrimRight(h.forwardURL, "/") +
		fmt.Sprintf("?mode=history&output=json&apikey=%s", h.forwardPass)
	resp, err := http.Get(url)
	if err != nil {
		return false, false, ""
	}
	defer resp.Body.Close()

	var hr struct {
		History struct {
			Slots []struct {
				NzoID   string `json:"nzo_id"`
				Status  string `json:"status"`
				Storage string `json:"storage"`
			} `json:"slots"`
		} `json:"history"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&hr); err != nil {
		return false, false, ""
	}
	for _, slot := range hr.History.Slots {
		if slot.NzoID == decypharrID {
			success := slot.Status == "Completed"
			return true, success, slot.Storage
		}
	}
	return false, false, ""
}

// handleQueue returns our queue to Sonarr.
// Jobs that have been forwarded to Decypharr stay in "Downloading" state
// (SABnzbd's active-queue status) until Decypharr completes them.
func (h *Handler) handleQueue(w http.ResponseWriter, r *http.Request) {
	h.mu.RLock()
	defer h.mu.RUnlock()

	type slotEntry struct {
		ID       string    `json:"nzo_id"`
		Filename string    `json:"filename"`
		Cat      string    `json:"cat"`
		Status   jobStatus `json:"status"`
		MBLeft   float64   `json:"mb_left"`
		MB       float64   `json:"mb"`
		Timeleft string    `json:"timeleft"`
	}

	var slots []slotEntry
	for _, job := range h.jobs {
		// Only active (non-terminal) jobs appear in the queue
		if job.Status == statusCompleted || job.Status == statusFailed {
			continue
		}
		slots = append(slots, slotEntry{
			ID:       job.ID,
			Filename: job.Name,
			Cat:      job.Category,
			Status:   job.Status,
			MBLeft:   1,
			MB:       1,
			Timeleft: "0:00:30",
		})
	}
	if slots == nil {
		slots = []slotEntry{}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"queue": map[string]interface{}{
			"status":        "Idle",
			"speed":         "0",
			"speedlimit":    "",
			"speedlimit_abs": "",
			"paused":        false,
			"noofslots_total": len(slots),
			"noofslots":     len(slots),
			"limit":         20,
			"start":         0,
			"slots":         slots,
			"version":       "3.7.2",
		},
	})
}

// handleHistory returns completed jobs to Sonarr.
// The storage path comes from Decypharr's own history response,
// so Sonarr knows exactly where to find the files.
func (h *Handler) handleHistory(w http.ResponseWriter, r *http.Request) {
	h.mu.RLock()
	defer h.mu.RUnlock()

	type histEntry struct {
		ID         string    `json:"nzo_id"`
		Name       string    `json:"name"`
		Cat        string    `json:"category"`
		Status     jobStatus `json:"status"`
		Completed  int64     `json:"completed"`
		Storage    string    `json:"storage"`
		ActionLine string    `json:"action_line"`
		FailMsg    string    `json:"fail_message"`
	}

	var slots []histEntry
	for _, job := range h.jobs {
		if job.Status != statusCompleted && job.Status != statusFailed {
			continue
		}
		storagePath := job.StoragePath
		if storagePath == "" {
			// Fallback: base path fetched from Decypharr at startup + category subdir
			h.mu.RUnlock()
			h.mu.RLock()
			base := h.completeDir
			if base == "" {
				base = "/mnt/decypharr"
			}
			storagePath = strings.TrimRight(base, "/") + "/" + job.Category
		}
		actionLine := fmt.Sprintf("par2proxy: %d bad segments, %d repaired",
			job.BadSegs, job.FixedSegs)
		slots = append(slots, histEntry{
			ID:         job.ID,
			Name:       job.Name,
			Cat:        job.Category,
			Status:     job.Status,
			Completed:  job.DoneAt.Unix(),
			Storage:    storagePath,
			ActionLine: actionLine,
			FailMsg:    job.ErrMsg,
		})
	}
	if slots == nil {
		slots = []histEntry{}
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"history": map[string]interface{}{
			"slots":     slots,
			"noofslots": len(slots),
		},
	})
}

func (h *Handler) handleDelete(w http.ResponseWriter, r *http.Request) {
	id := r.FormValue("value")
	if id == "" {
		id = r.URL.Query().Get("value")
	}
	h.mu.Lock()
	// Also tell Decypharr to delete if we forwarded it
	if job, ok := h.jobs[id]; ok && job.DecypharrJobID != "" {
		go h.deleteFromDecypharr(job.DecypharrJobID)
	}
	delete(h.jobs, id)
	h.mu.Unlock()
	json.NewEncoder(w).Encode(map[string]bool{"status": true})
}

func (h *Handler) deleteFromDecypharr(decypharrID string) {
	url := strings.TrimRight(h.forwardURL, "/") +
		fmt.Sprintf("?mode=delete&value=%s&apikey=%s", decypharrID, h.forwardPass)
	http.Get(url)
}

func (h *Handler) handleConfig(w http.ResponseWriter, r *http.Request) {
	h.mu.RLock()
	dir := h.completeDir
	h.mu.RUnlock()
	if dir == "" {
		dir = "/mnt/decypharr"
	}
	base := strings.TrimRight(dir, "/")

	// Sonarr calls mode=get_config and reads:
	//   config.misc.complete_dir  — base download dir
	//   config.categories[]       — array of {name, complete_dir, ...}
	// If categories is null or missing, Sonarr throws a NullReferenceException.
	// We return the four standard arr categories so whichever one Sonarr was
	// configured with will pass validation.
	categories := []map[string]interface{}{
		{"name": "Default", "complete_dir": base, "pp": "", "script": "None", "newzbin": "", "priority": -100},
		{"name": "sonarr", "complete_dir": base + "/sonarr", "pp": "", "script": "None", "newzbin": "", "priority": -100},
		{"name": "radarr", "complete_dir": base + "/radarr", "pp": "", "script": "None", "newzbin": "", "priority": -100},
		{"name": "lidarr", "complete_dir": base + "/lidarr", "pp": "", "script": "None", "newzbin": "", "priority": -100},
		{"name": "readarr", "complete_dir": base + "/readarr", "pp": "", "script": "None", "newzbin": "", "priority": -100},
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"config": map[string]interface{}{
			"misc": map[string]interface{}{
				"complete_dir":    base,
				"download_dir":    base,
				"nzb_backup_dir":  "",
				"version":         "3.7.2",
				"disable_api_key": false,
			},
			"categories": categories,
		},
	})
}

func (h *Handler) setStatus(id string, s jobStatus) {
	h.mu.Lock()
	if job, ok := h.jobs[id]; ok {
		job.Status = s
	}
	h.mu.Unlock()
}

func (h *Handler) failJob(job *Job, msg string) {
	log.Printf("sabnzbd: [%s] FAILED: %s", job.ID, msg)
	h.mu.Lock()
	job.Status = statusFailed
	job.ErrMsg = msg
	job.DoneAt = time.Now()
	h.mu.Unlock()
}

// StatusSnapshot returns current job state for the web UI.
func (h *Handler) StatusSnapshot() (queue, history []*Job, par2Total int64) {
	h.mu.RLock()
	defer h.mu.RUnlock()
	for _, j := range h.jobs {
		jCopy := *j
		switch j.Status {
		case statusCompleted, statusFailed:
			history = append(history, &jCopy)
		default:
			queue = append(queue, &jCopy)
		}
		par2Total += j.Par2Bytes
	}
	return
}

// --- helpers ---

func extractNZB(r *http.Request) ([]byte, string, error) {
	ct := r.Header.Get("Content-Type")
	mt, _, _ := mime.ParseMediaType(ct)
	if strings.HasPrefix(mt, "multipart/") {
		for _, key := range []string{"nzbfile", "nzb", "file"} {
			f, fh, err := r.FormFile(key)
			if err == nil {
				defer f.Close()
				data, err := io.ReadAll(f)
				return data, fh.Filename, err
			}
		}
	}
	nzbURL := r.FormValue("nzburl")
	if nzbURL == "" {
		nzbURL = r.URL.Query().Get("nzburl")
	}
	if nzbURL != "" {
		resp, err := http.Get(nzbURL)
		if err != nil {
			return nil, "", err
		}
		defer resp.Body.Close()
		data, err := io.ReadAll(resp.Body)
		return data, "remote.nzb", err
	}
	return nil, "", fmt.Errorf("no nzb file or url in request")
}

func newID() string {
	return fmt.Sprintf("par2proxy-%d", time.Now().UnixNano())
}

func jsonErr(w http.ResponseWriter, msg string, code int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]interface{}{"status": false, "error": msg})
}
