// Package sabnzbd implements a SABnzbd-compatible HTTP API.
// Sonarr/Radarr POST NZBs here; we repair them and forward to Decypharr.
// Status is proxied FROM Decypharr back to Sonarr so completion is accurate.
package sabnzbd

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"mime"
	"mime/multipart"
	"net/http"
	"path/filepath"
	"regexp"
	"strings"
	"sync"
	"time"

	"github.com/par2proxy/internal/config"
	"github.com/par2proxy/internal/nzb"
	"github.com/par2proxy/internal/repair"
)

type jobStatus string

const (
	statusQueued      jobStatus = "Queued"
	statusRepairing   jobStatus = "Repairing"
	statusForwarded   jobStatus = "Downloading" // SABnzbd name Sonarr understands
	statusCompleted   jobStatus = "Completed"
	statusFailed      jobStatus = "Failed"
)

// Job tracks one NZB submission through its full lifecycle.
type Job struct {
	ID            string
	Name          string
	Category      string
	Status        jobStatus
	Phase         string
	Pct           int
	NZBData       []byte
	RepairedNZB   []byte
	AddedAt       time.Time
	DoneAt        time.Time
	ErrMsg        string
	Par2Bytes     int64
	BadSegs       int
	FixedSegs     int
	DecypharrJobID string
	StoragePath    string

	// cancel stops the processJob goroutine when the job is deleted
	cancel context.CancelFunc
}

// Handler is the SABnzbd API handler.
type Handler struct {
	apiKey     string
	engine     *repair.Engine
	forwardURL string
	verbose    bool

	// cfg is kept for per-category arr credential lookup.
	// Access under cfgMu.
	cfgMu sync.RWMutex
	cfg   *config.Config

	mu  sync.RWMutex
	jobs map[string]*Job

	// Fetched from Decypharr at Connect() time.
	completeDir string
	connected   bool
}

// ConnectResult holds what we learned from Decypharr at startup.
type ConnectResult struct {
	CompleteDir string
	Version     string
	Err         error
}

func New(apiKey, forwardURL string, cfg *config.Config, engine *repair.Engine, verbose bool) *Handler {
	h := &Handler{
		apiKey:     apiKey,
		engine:     engine,
		forwardURL: forwardURL,
		cfg:        cfg,
		verbose:    verbose,
		jobs:       make(map[string]*Job),
	}
	go h.pruneLoop()
	return h
}

// UpdateConfig replaces the live config (called when settings are saved).
func (h *Handler) UpdateConfig(cfg *config.Config) {
	h.cfgMu.Lock()
	h.cfg = cfg
	h.cfgMu.Unlock()
}

// arrFor returns the credentials for the arr that owns this category.
func (h *Handler) arrFor(category string) (url, apiKey string) {
	h.cfgMu.RLock()
	arr := h.cfg.ArrForCategory(category)
	h.cfgMu.RUnlock()
	return arr.URL, arr.APIKey
}

// sabAPIKey returns the API key to use for Decypharr SABnzbd auth polling.
// Uses the first arr's API key (all arrs share the same Decypharr instance).
func (h *Handler) sabAPIKey() string {
	h.cfgMu.RLock()
	defer h.cfgMu.RUnlock()
	if len(h.cfg.Arrs) > 0 {
		return h.cfg.Arrs[0].APIKey
	}
	return ""
}


// extractMissingMIDs parses message-IDs from a Decypharr ARTICLE_NOT_FOUND error string.
// Decypharr error format: "failed to stat segment <filename> <mid@host>: NNTP ARTICLE_NOT_FOUND"
// Message-IDs appear between < > angle brackets, which may be JSON-escaped as \u003c \u003e.
func extractMissingMIDs(errStr string) []string {
	// Unescape JSON unicode escapes so \u003c → < and \u003e → >
	errStr = strings.ReplaceAll(errStr, `\u003c`, "<")
	errStr = strings.ReplaceAll(errStr, `\u003e`, ">")
	errStr = strings.ReplaceAll(errStr, `\u0026`, "&")

	var mids []string
	seen := make(map[string]bool)
	remaining := errStr
	for {
		start := strings.Index(remaining, "<")
		if start < 0 {
			break
		}
		end := strings.Index(remaining[start:], ">")
		if end < 0 {
			break
		}
		candidate := remaining[start+1 : start+end]
		remaining = remaining[start+end+1:]
		// Message-IDs contain @ and are not file paths
		if strings.Contains(candidate, "@") && !strings.Contains(candidate, "/") && !seen[candidate] {
			mids = append(mids, candidate)
			seen[candidate] = true
		}
	}
	return mids
}

func (h *Handler) pruneLoop() {
	for {
		time.Sleep(15 * time.Minute)
		cutoff := time.Now().Add(-2 * time.Hour)
		h.mu.Lock()
		pruned := 0
		for id, job := range h.jobs {
			if (job.Status == statusCompleted || job.Status == statusFailed) &&
				!job.DoneAt.IsZero() && job.DoneAt.Before(cutoff) {
				delete(h.jobs, id)
				pruned++
			}
		}
		h.mu.Unlock()
		if pruned > 0 {
			log.Printf("sabnzbd: pruned %d completed/failed jobs older than 2h", pruned)
		}
	}
}

// Connect fetches Decypharr's config (complete_dir, version) so we have the
// real storage path before any jobs are processed.
// It retries up to maxAttempts times with retryDelay between each.
func (h *Handler) Connect(maxAttempts int, retryDelay time.Duration) ConnectResult {
	if maxAttempts <= 0 {
		maxAttempts = 1
	}
	// Try both mode variants
	h.cfgMu.RLock()
	var sabAPIKey string
	if len(h.cfg.Arrs) > 0 {
		sabAPIKey = h.cfg.Arrs[0].APIKey
	}
	h.cfgMu.RUnlock()

	urls := []string{
		strings.TrimRight(h.forwardURL, "/") + "?mode=get_config&output=json&apikey=" + sabAPIKey,
		strings.TrimRight(h.forwardURL, "/") + "?mode=config&output=json&apikey=" + sabAPIKey,
	}

	var lastErr error
	for attempt := 1; attempt <= maxAttempts; attempt++ {
		for _, url := range urls {
			result, err := h.fetchConfig(url)
			if err == nil {
				h.mu.Lock()
				h.completeDir = result.CompleteDir
				h.connected = true
				h.mu.Unlock()
				return result
			}
			lastErr = err
		}
		if attempt < maxAttempts && retryDelay > 0 {
			log.Printf("sabnzbd: connect attempt %d/%d failed: %v", attempt, maxAttempts, lastErr)
			time.Sleep(retryDelay)
		}
	}
	return ConnectResult{Err: lastErr}
}

// SetCompleteDir pre-seeds the complete_dir so the UI can show it
// before Connect() has confirmed it from Decypharr.
func (h *Handler) SetCompleteDir(dir string) {
	if dir == "" {
		return
	}
	h.mu.Lock()
	if h.completeDir == "" {
		h.completeDir = dir
	}
	h.mu.Unlock()
}

func (h *Handler) fetchConfig(url string) (ConnectResult, error) {
	resp, err := http.Get(url)
	if err != nil {
		return ConnectResult{}, fmt.Errorf("GET %s: %w", url, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 300 {
		return ConnectResult{}, fmt.Errorf("Decypharr returned HTTP %d", resp.StatusCode)
	}

	// Decypharr's config response may be wrapped as {config:{misc:{...}}} (SABnzbd get_config)
	// or directly as {misc:{...}} (mode=config). Handle both.
	var cr struct {
		Config struct {
			Misc struct {
				CompleteDir string `json:"complete_dir"`
				Version     string `json:"version"`
			} `json:"misc"`
		} `json:"config"`
		Misc struct {
			CompleteDir string `json:"complete_dir"`
			Version     string `json:"version"`
		} `json:"misc"`
		// Some implementations put values at top level
		CompleteDir string `json:"complete_dir"`
		Version     string `json:"version"`
	}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return ConnectResult{}, fmt.Errorf("read body: %w", err)
	}
	if err := json.Unmarshal(body, &cr); err != nil {
		return ConnectResult{}, fmt.Errorf("parse config response: %w", err)
	}

	// Prefer config.misc → misc → top-level
	dir := cr.Config.Misc.CompleteDir
	ver := cr.Config.Misc.Version
	if dir == "" {
		dir = cr.Misc.CompleteDir
		ver = cr.Misc.Version
	}
	if dir == "" {
		dir = cr.CompleteDir
		ver = cr.Version
	}
	if dir == "" {
		return ConnectResult{}, fmt.Errorf("Decypharr config missing complete_dir (response: %s)", body)
	}

	return ConnectResult{CompleteDir: dir, Version: ver}, nil
}

// CompleteDir returns the storage base path fetched from Decypharr.
func (h *Handler) CompleteDir() string {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return h.completeDir
}

// IsConnected returns whether we successfully fetched Decypharr config at startup.
func (h *Handler) IsConnected() bool {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return h.connected
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	mode := r.FormValue("mode")
	if mode == "" {
		mode = r.URL.Query().Get("mode")
	}
	key := r.FormValue("apikey")
	if key == "" {
		key = r.URL.Query().Get("apikey")
	}

	// Always log incoming requests so connection issues are diagnosable
	log.Printf("sabnzbd: %s %s mode=%q key_ok=%v host=%s",
		r.Method, r.URL.Path, mode, key == h.apiKey || h.apiKey == "", r.Host)

	if h.apiKey != "" && key != h.apiKey {
		log.Printf("sabnzbd: auth failed — got key %q, expected %q", key, h.apiKey)
		jsonErr(w, "API key invalid", http.StatusUnauthorized)
		return
	}
	switch mode {
	case "addfile", "addurl":
		h.handleAdd(w, r)
	case "queue":
		h.handleQueue(w, r)
	case "history":
		h.handleHistory(w, r)
	case "delete":
		h.handleDelete(w, r)
	case "purge":
		h.handlePurge(w, r)
	case "version":
		// Sonarr expects {"version": "x.x.x"} at the root
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]string{"version": "3.7.2"})
	case "config", "get_config":
		// Sonarr calls mode=get_config during Test; mode=config is the legacy alias.
		// Both must return a categories array or Sonarr null-refs.
		h.handleConfig(w, r)
	default:
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{"status": true, "error": ""})
	}
}

// handleAdd receives an NZB from Sonarr, returns our job ID immediately,
// then processes and forwards to Decypharr asynchronously.
func (h *Handler) handleAdd(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseMultipartForm(64 << 20); err != nil {
		r.ParseForm()
	}

	log.Printf("sabnzbd: addfile Content-Type=%q", r.Header.Get("Content-Type"))

	category := r.FormValue("cat")
	// Sonarr sends the name in "nzbname" or "title"
	name := r.FormValue("nzbname")
	if name == "" {
		name = r.FormValue("title")
	}

	nzbBytes, filename, err := extractNZB(r)
	if err != nil {
		jsonErr(w, "no NZB: "+err.Error(), http.StatusBadRequest)
		return
	}
	if name == "" {
		name = filename
	}

	// Reject season packs — they cause multi-episode import issues with Decypharr.
	// Sonarr should search for individual episode releases instead.
	if isSeasonPack(name) {
		log.Printf("sabnzbd: REJECTED season pack %q — blacklisting so Sonarr searches episode releases", name)
		id := newID()
		job := &Job{
			ID:       id,
			Name:     name,
			Category: category,
			Status:   statusFailed,
			NZBData:  nzbBytes,
			AddedAt:  time.Now(),
			DoneAt:   time.Now(),
			ErrMsg:   "Season packs not supported — searching for individual episodes",
		}
		h.mu.Lock()
		h.jobs[id] = job
		h.mu.Unlock()

		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{
			"status":  true,
			"nzo_ids": []string{id},
		})
		return
	}

	id := newID()
	ctx, cancel := context.WithCancel(context.Background())
	job := &Job{
		ID:       id,
		Name:     name,
		Category: category,
		Status:   statusQueued,
		NZBData:  nzbBytes,
		AddedAt:  time.Now(),
		cancel:   cancel,
	}

	h.mu.Lock()
	h.jobs[id] = job
	h.mu.Unlock()

	log.Printf("sabnzbd: queued %q (cat=%s id=%s, size=%d bytes)", name, category, id, len(nzbBytes))
	go h.processJob(ctx, job)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"status":  true,
		"nzo_ids": []string{id},
	})
}

// isSeasonPack returns true if the NZB name looks like a full season pack
// rather than an individual episode. Season packs cause import issues with
// Decypharr because it serves files with hash names, and Sonarr can't match them.
func isSeasonPack(name string) bool {
	upper := strings.ToUpper(name)

	// Has SxxExx format → individual episode, not a season pack
	seasonEpisode := regexp.MustCompile(`S\d{1,2}E\d{1,2}`)
	if seasonEpisode.MatchString(upper) {
		return false
	}

	// Has Sxx format without episode → season pack
	seasonOnly := regexp.MustCompile(`[\.\s\-_]S\d{1,2}[\.\s\-_\[]`)
	if seasonOnly.MatchString(upper) {
		return true
	}

	// Explicit keywords
	for _, kw := range []string{"COMPLETE.SERIES", "COMPLETE.SEASON", "THE.COMPLETE", "SEASON.COMPLETE"} {
		if strings.Contains(upper, kw) {
			return true
		}
	}

	return false
}

func (h *Handler) processJob(ctx context.Context, job *Job) {
	h.mu.Lock()
	job.Status = statusRepairing
	job.Phase = "Checking par2…"
	h.mu.Unlock()

	n, err := nzb.Parse(bytes.NewReader(job.NZBData))
	if err != nil {
		h.failJob(job, "NZB parse error: "+err.Error())
		return
	}

	if ctx.Err() != nil {
		log.Printf("sabnzbd: [%s] job cancelled before repair", job.ID)
		return
	}

	log.Printf("sabnzbd: [%s] processing %q — %d files, %d par2 files",
		job.ID, job.Name, len(n.Files), len(n.Par2Files()))

	result, err := h.engine.Repair(ctx, n)
	if err != nil {
		if ctx.Err() != nil {
			log.Printf("sabnzbd: [%s] job cancelled", job.ID)
			return
		}
		h.failJob(job, "repair engine error: "+err.Error())
		return
	}

	h.mu.Lock()
	job.BadSegs = result.BadSegments
	job.FixedSegs = result.RepairedCount
	job.Par2Bytes = result.Par2Fetched
	job.Phase = "Forwarding to Decypharr…"
	h.mu.Unlock()

	if ctx.Err() != nil {
		log.Printf("sabnzbd: [%s] job cancelled after repair", job.ID)
		return
	}

	for _, warn := range result.Warnings {
		log.Printf("sabnzbd: [%s] warning: %s", job.ID, warn)
	}

	nzbToForward := job.NZBData
	if result.Repaired && result.RepairedNZB != nil {
		if rewritten, err := nzb.Marshal(result.RepairedNZB); err == nil {
			nzbToForward = rewritten
			h.mu.Lock()
			job.RepairedNZB = rewritten
			h.mu.Unlock()
			log.Printf("sabnzbd: [%s] forwarding REPAIRED NZB (%d bad → %d fixed)",
				job.ID, result.BadSegments, result.RepairedCount)
		} else {
			log.Printf("sabnzbd: [%s] marshal error, forwarding original: %v", job.ID, err)
		}
	} else {
		log.Printf("sabnzbd: [%s] no repair needed, forwarding original", job.ID)
	}

	// par2Available tracks whether we have par2 data to attempt repairs with
	par2Available := result.Par2Set != nil

	// Forward to Decypharr — if par2 is available, retry repair loop
	// (Decypharr reports one missing segment at a time per 500 error)
	// If par2 is unavailable, forward once and fail immediately on 500
	maxRetries := 5
	if !par2Available {
		maxRetries = 0
	}
	nzbToSend := nzbToForward
	var decypharrID string
	for attempt := 0; attempt <= maxRetries; attempt++ {
		decypharrID, err = h.forwardToDecypharr(job, nzbToSend)
		if err == nil {
			break // success
		}

		errStr := err.Error()
		isMissingSegment := strings.Contains(errStr, "ARTICLE_NOT_FOUND") || strings.Contains(errStr, "No Such Article")

		if !isMissingSegment || !par2Available || attempt == maxRetries {
			break
		}

		missingMIDs := extractMissingMIDs(errStr)
		log.Printf("sabnzbd: [%s] attempt %d: Decypharr found %d missing segment(s) — repairing", job.ID, attempt+1, len(missingMIDs))

		h.mu.Lock()
		job.Phase = fmt.Sprintf("Repairing missing segments… (attempt %d)", attempt+1)
		h.mu.Unlock()

		result2, err2 := h.engine.RepairWithMissing(n, missingMIDs)
		if err2 != nil || !result2.Repaired || result2.RepairedNZB == nil {
			if result2 != nil {
				for _, w := range result2.Warnings {
					log.Printf("sabnzbd: [%s] repair warning: %s", job.ID, w)
				}
			}
			log.Printf("sabnzbd: [%s] cannot repair missing segments (par2 data unavailable — release may have expired)", job.ID)
			break
		}

		rewritten, err3 := nzb.Marshal(result2.RepairedNZB)
		if err3 != nil {
			break
		}
		log.Printf("sabnzbd: [%s] repair attempt %d: fixed %d/%d segments, re-forwarding", job.ID, attempt+1, result2.RepairedCount, result2.BadSegments)
		h.mu.Lock()
		job.BadSegs = result2.BadSegments
		job.FixedSegs += result2.RepairedCount
		job.Par2Bytes += result2.Par2Fetched
		h.mu.Unlock()
		nzbToSend = rewritten
	}

	if err != nil {
		errStr := err.Error()
		if strings.Contains(errStr, "ARTICLE_NOT_FOUND") || strings.Contains(errStr, "No Such Article") {
			msg := "Missing segments on Usenet"
			if par2Available {
				msg = "Missing segments — par2 repair unsuccessful"
			} else {
				msg = "Missing segments — par2 data also unavailable (release expired)"
			}
			log.Printf("sabnzbd: [%s] %s — blacklisting release so Sonarr searches for a new one", job.ID, msg)
			h.failJob(job, msg)
		} else {
			log.Printf("sabnzbd: [%s] forward failed: %v", job.ID, err)
			h.failJob(job, "forward to Decypharr failed: "+err.Error())
		}
		return
	}

	h.mu.Lock()
	job.DecypharrJobID = decypharrID
	job.Status = statusForwarded
	h.mu.Unlock()

	log.Printf("sabnzbd: [%s] forwarded to Decypharr as %s, polling for completion",
		job.ID, decypharrID)

	// Poll Decypharr until it marks the job done
	h.waitForDecypharr(job, decypharrID)
}

// forwardToDecypharr POSTs the NZB and returns Decypharr's nzo_id.
func (h *Handler) forwardToDecypharr(job *Job, nzbBytes []byte) (string, error) {
	// Look up which arr owns this category for correct credentials
	arrURL, arrAPIKey := h.arrFor(job.Category)

	// Inject category into NZB meta tags — Decypharr reads this for folder routing
	if job.Category != "" {
		if n, err := nzb.Parse(bytes.NewReader(nzbBytes)); err == nil {
			found := false
			for i, m := range n.Meta {
				if strings.EqualFold(m.Type, "category") {
					n.Meta[i].Value = job.Category
					found = true
					break
				}
			}
			if !found {
				n.Meta = append(n.Meta, struct {
					Type  string `xml:"type,attr"`
					Value string `xml:",chardata"`
				}{Type: "category", Value: job.Category})
			}
			if rewritten, err := nzb.Marshal(n); err == nil {
				nzbBytes = rewritten
			}
		}
	}

	var body bytes.Buffer
	mw := multipart.NewWriter(&body)

	fw, err := mw.CreateFormFile("name", job.Name+".nzb")
	if err != nil {
		return "", err
	}
	if _, err := fw.Write(nzbBytes); err != nil {
		return "", err
	}
	mw.WriteField("nzbname", job.Name)
	mw.WriteField("cat", job.Category)
	mw.WriteField("mode", "addfile")
	mw.WriteField("output", "json")
	// Decypharr SABnzbd auth: username = arr host URL, apikey = arr API token
	if arrURL != "" {
		mw.WriteField("username", arrURL)
	}
	if arrAPIKey != "" {
		mw.WriteField("apikey", arrAPIKey)
	}
	mw.Close()

	apiURL := strings.TrimRight(h.forwardURL, "/") + "?mode=addfile&output=json"
	if arrAPIKey != "" {
		apiURL += "&apikey=" + arrAPIKey
	}
	if job.Category != "" {
		apiURL += "&cat=" + job.Category
	}
	req, err := http.NewRequest("POST", apiURL, &body)
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", mw.FormDataContentType())

	log.Printf("sabnzbd: [%s] forwarding to Decypharr: URL=%s cat=%q arrURL=%q nzbSize=%d",
		job.ID, apiURL, job.Category, arrURL, len(nzbBytes))

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("POST to Decypharr: %w", err)
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	log.Printf("sabnzbd: [%s] Decypharr response %d: %s", job.ID, resp.StatusCode, string(respBody))

	if resp.StatusCode >= 300 {
		bodyStr := string(respBody)
		// Decypharr 500 with ARTICLE_NOT_FOUND means it accepted the NZB but found
		// missing segments during streaming. The error includes an nzo_id sometimes —
		// either way, propagate so the retry logic in processJob can attempt repair.
		return "", fmt.Errorf("Decypharr returned %d: %s", resp.StatusCode, bodyStr)
	}

	// Parse Decypharr's response to get its job ID
	var addResp struct {
		NzoIDs []string `json:"nzo_ids"`
		Status bool     `json:"status"`
	}
	if err := json.Unmarshal(respBody, &addResp); err != nil || len(addResp.NzoIDs) == 0 {
		var alt struct {
			Queue struct {
				NzoIDs []string `json:"nzo_ids"`
			} `json:"queue"`
		}
		if err2 := json.Unmarshal(respBody, &alt); err2 == nil && len(alt.Queue.NzoIDs) > 0 {
			return alt.Queue.NzoIDs[0], nil
		}
		return "", fmt.Errorf("could not parse Decypharr job ID from response: %s", respBody)
	}
	return addResp.NzoIDs[0], nil
}

// waitForDecypharr polls Decypharr's queue then history until the job completes,
// then mirrors the final status (and storage path) back onto our job.
func (h *Handler) waitForDecypharr(job *Job, decypharrID string) {
	const (
		pollInterval  = 5 * time.Second
		maxWait       = 2 * time.Hour // fail faster so Sonarr can search for new release
		noProgressMax = 5 * time.Minute // give up if stuck at same % for 5 min
	)
	deadline := time.Now().Add(maxWait)
	lastPct := -1
	lastPctChange := time.Now()

	for time.Now().Before(deadline) {
		time.Sleep(pollInterval)

		// Check context — job may have been cancelled/deleted
		h.mu.RLock()
		cancelled := job.cancel != nil
		h.mu.RUnlock()
		_ = cancelled

		// Check Decypharr's queue first
		if inQueue, pct := h.decypharrQueueStatus(decypharrID); inQueue {
			h.mu.Lock()
			job.Status = statusForwarded
			job.Pct = pct
			job.Phase = fmt.Sprintf("Downloading… %d%%", pct)
			h.mu.Unlock()

			if pct != lastPct {
				lastPct = pct
				lastPctChange = time.Now()
			} else if time.Since(lastPctChange) > noProgressMax {
				// Stuck — give up and let Sonarr find a new release
				log.Printf("sabnzbd: [%s] stuck at %d%% for %v — failing job", job.ID, pct, noProgressMax)
				go h.deleteFromDecypharr(decypharrID)
				h.failJob(job, "download stalled — no progress for 5 minutes")
				return
			}
			continue
		}

		// Check Decypharr's history
		if done, success, storage := h.decypharrHistoryStatus(decypharrID); done {
			h.mu.Lock()
			job.DoneAt = time.Now()
			if success {
				// Verify files actually have no missing segments before telling Sonarr
				if healthy, reason := h.checkDecypharrHealth(decypharrID, storage); !healthy {
					log.Printf("sabnzbd: [%s] Decypharr completed but files unhealthy: %s — failing", job.ID, reason)
					job.Status = statusFailed
					job.ErrMsg = "Files have missing segments — Sonarr will search for a new release"
				} else {
					job.Status = statusCompleted
					job.StoragePath = storage
				}
			} else {
				job.Status = statusFailed
				job.ErrMsg = "Missing segments on Usenet — Sonarr will search for a new release"
			}
			h.mu.Unlock()

			log.Printf("sabnzbd: [%s] Decypharr job %s %s (storage: %s)",
				job.ID, decypharrID, job.Status, storage)

			if job.Status == statusCompleted {
				go h.deleteWhenSonarrDone(job, decypharrID)
			} else {
				go h.deleteFromDecypharr(decypharrID)
			}
			return
		}
	}

	// Timeout
	h.mu.Lock()
	job.Status = statusFailed
	job.ErrMsg = "timed out waiting for Decypharr"
	job.DoneAt = time.Now()
	h.mu.Unlock()
	log.Printf("sabnzbd: [%s] timed out waiting for Decypharr job %s", job.ID, decypharrID)
	go h.deleteFromDecypharr(decypharrID)
}

// decypharrQueueStatus checks if the job is still in Decypharr's active queue.
// Returns (inQueue, percentDone).
func (h *Handler) decypharrQueueStatus(decypharrID string) (bool, int) {
	url := strings.TrimRight(h.forwardURL, "/") +
		fmt.Sprintf("?mode=queue&output=json&apikey=%s", h.sabAPIKey())
	resp, err := http.Get(url)
	if err != nil {
		return false, 0
	}
	defer resp.Body.Close()

	var qr struct {
		Queue struct {
			Slots []struct {
				NzoID      string `json:"nzo_id"`
				Percentage string `json:"percentage"`
			} `json:"slots"`
		} `json:"queue"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&qr); err != nil {
		return false, 0
	}
	for _, slot := range qr.Queue.Slots {
		if slot.NzoID == decypharrID {
			var pct int
			fmt.Sscanf(slot.Percentage, "%d", &pct)
			return true, pct
		}
	}
	return false, 0
}

// decypharrHistoryStatus checks Decypharr's history for the job.
// Returns (found, success, storagePath).
func (h *Handler) decypharrHistoryStatus(decypharrID string) (bool, bool, string) {
	url := strings.TrimRight(h.forwardURL, "/") +
		fmt.Sprintf("?mode=history&output=json&apikey=%s", h.sabAPIKey())
	resp, err := http.Get(url)
	if err != nil {
		return false, false, ""
	}
	defer resp.Body.Close()

	body, _ := io.ReadAll(resp.Body)

	var hr struct {
		History struct {
			Slots []struct {
				NzoID   string `json:"nzo_id"`
				Status  string `json:"status"`
				Storage string `json:"storage"`
			} `json:"slots"`
		} `json:"history"`
	}
	if err := json.Unmarshal(body, &hr); err != nil {
		return false, false, ""
	}
	for _, slot := range hr.History.Slots {
		if slot.NzoID == decypharrID {
			success := slot.Status == "Completed"
			return true, success, slot.Storage
		}
	}
	// Log what IDs we do have when we can't find ours
	if len(hr.History.Slots) > 0 {
		var ids []string
		for _, s := range hr.History.Slots {
			ids = append(ids, s.NzoID)
		}
		log.Printf("sabnzbd: looking for %s in Decypharr history, found: %v", decypharrID, ids)
	}
	return false, false, ""
}

// handleQueue returns our queue to Sonarr.
// Jobs that have been forwarded to Decypharr stay in "Downloading" state
// (SABnzbd's active-queue status) until Decypharr completes them.
func (h *Handler) handleQueue(w http.ResponseWriter, r *http.Request) {
	h.mu.RLock()
	defer h.mu.RUnlock()

	type slotEntry struct {
		ID       string    `json:"nzo_id"`
		Filename string    `json:"filename"`
		Title    string    `json:"title"`
		Cat      string    `json:"cat"`
		Status   jobStatus `json:"status"`
		MBLeft   float64   `json:"mb_left"`
		MB       float64   `json:"mb"`
		Timeleft string    `json:"timeleft"`
	}

	var slots []slotEntry
	for _, job := range h.jobs {
		// Only active (non-terminal) jobs appear in the queue
		if job.Status == statusCompleted || job.Status == statusFailed {
			continue
		}
		slots = append(slots, slotEntry{
			ID:       job.ID,
			Filename: job.Name,
			Title:    strings.TrimSuffix(job.Name, ".nzb"),
			Cat:      job.Category,
			Status:   job.Status,
			MBLeft:   1,
			MB:       1,
			Timeleft: "0:00:30",
		})
	}
	if slots == nil {
		slots = []slotEntry{}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"queue": map[string]interface{}{
			"status":        "Idle",
			"speed":         "0",
			"speedlimit":    "",
			"speedlimit_abs": "",
			"paused":        false,
			"noofslots_total": len(slots),
			"noofslots":     len(slots),
			"limit":         20,
			"start":         0,
			"slots":         slots,
			"version":       "3.7.2",
		},
	})
}

// handleHistory returns completed jobs to Sonarr.
// The storage path comes from Decypharr's own history response,
// so Sonarr knows exactly where to find the files.
func (h *Handler) handleHistory(w http.ResponseWriter, r *http.Request) {
	h.mu.RLock()
	defer h.mu.RUnlock()

	type histEntry struct {
		ID         string    `json:"nzo_id"`
		Name       string    `json:"name"`
		Title      string    `json:"title"`
		Cat        string    `json:"category"`
		Status     jobStatus `json:"status"`
		Completed  int64     `json:"completed"`
		Storage    string    `json:"storage"`
		ActionLine string    `json:"action_line"`
		FailMsg    string    `json:"fail_message"`
	}

	var slots []histEntry
	for _, job := range h.jobs {
		if job.Status != statusCompleted && job.Status != statusFailed {
			continue
		}

		h.mu.RUnlock()
		h.mu.RLock()
		base := h.completeDir
		if base == "" {
			base = "/mnt/decypharr"
		}
		h.mu.RUnlock()
		h.mu.RLock()

		var storagePath string
		if job.StoragePath != "" {
			// Decypharr returns the full file path e.g.
			// /mnt/downloads/sonarr/ShowName.S01.nzb/ShowName.S01E01.mkv
			// Sonarr needs the parent directory (the NZB-named folder)
			storagePath = filepath.Dir(job.StoragePath)
		} else {
			// No storage path yet — use NZB name as subfolder
			folderName := strings.TrimSuffix(job.Name, ".nzb")
			storagePath = strings.TrimRight(base, "/") + "/" + job.Category + "/" + folderName
		}

		actionLine := fmt.Sprintf("par2proxy: %d bad segments, %d repaired",
			job.BadSegs, job.FixedSegs)
		slots = append(slots, histEntry{
			ID:         job.ID,
			Name:       job.Name,
			Title:      strings.TrimSuffix(job.Name, ".nzb"),
			Cat:        job.Category,
			Status:     job.Status,
			Completed:  job.DoneAt.Unix(),
			Storage:    storagePath,
			ActionLine: actionLine,
			FailMsg:    job.ErrMsg,
		})
	}
	if slots == nil {
		slots = []histEntry{}
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"history": map[string]interface{}{
			"slots":     slots,
			"noofslots": len(slots),
		},
	})
}

func (h *Handler) handleDelete(w http.ResponseWriter, r *http.Request) {
	id := r.FormValue("value")
	if id == "" {
		id = r.URL.Query().Get("value")
	}

	h.mu.Lock()
	job, ok := h.jobs[id]
	if ok {
		delete(h.jobs, id)
		if job.cancel != nil {
			job.cancel() // stop processJob goroutine
		}
	}
	h.mu.Unlock()

	if ok && job != nil && job.DecypharrJobID != "" {
		decypharrID := job.DecypharrJobID
		go func() {
			log.Printf("sabnzbd: job %s deleted by Sonarr — removing from Decypharr in 90s", id)
			time.Sleep(90 * time.Second)
			h.deleteFromDecypharr(decypharrID)
		}()
	}

	log.Printf("sabnzbd: deleted job %s", id)
	json.NewEncoder(w).Encode(map[string]bool{"status": true})
}

func (h *Handler) handlePurge(w http.ResponseWriter, r *http.Request) {
	// Delete all jobs, optionally filtered by queue/history
	which := r.FormValue("value") // "queue", "history", or empty = all
	if which == "" {
		which = r.URL.Query().Get("value")
	}
	h.mu.Lock()
	count := 0
	for id, job := range h.jobs {
		switch which {
		case "queue":
			if job.Status == statusCompleted || job.Status == statusFailed {
				continue
			}
		case "history":
			if job.Status != statusCompleted && job.Status != statusFailed {
				continue
			}
		}
		if job.DecypharrJobID != "" {
			go h.deleteFromDecypharr(job.DecypharrJobID)
		}
		if job.cancel != nil {
			job.cancel()
		}
		delete(h.jobs, id)
		count++
	}
	h.mu.Unlock()
	log.Printf("sabnzbd: purged %d jobs (filter=%q)", count, which)
	json.NewEncoder(w).Encode(map[string]bool{"status": true})
}

// deleteWhenSonarrDone waits for Sonarr to finish importing then deletes from Decypharr.
// checkDecypharrHealth checks if the completed job's files are actually healthy.
// Returns (healthy, reason). If Decypharr's health API can't be reached, assumes healthy.
func (h *Handler) checkDecypharrHealth(decypharrID, storagePath string) (bool, string) {
	h.cfgMu.RLock()
	baseURL := strings.TrimRight(h.cfg.DecypharrURL, "/")
	apiKey := h.cfg.DecypharrAPIKey
	h.cfgMu.RUnlock()

	if baseURL == "" || apiKey == "" {
		return true, "" // can't check, assume healthy
	}

	// Check Decypharr's repair health endpoint for broken files
	url := baseURL + "/api/repair/health?status=broken"
	req, _ := http.NewRequest("GET", url, nil)
	req.Header.Set("Authorization", "Bearer "+apiKey)

	client := &http.Client{Timeout: 10 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		log.Printf("sabnzbd: health check failed: %v — assuming healthy", err)
		return true, ""
	}
	defer resp.Body.Close()

	if resp.StatusCode != 200 {
		return true, "" // endpoint not available, assume healthy
	}

	var result []struct {
		NzbID  string `json:"nzb_id"`
		Name   string `json:"name"`
		Status string `json:"status"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return true, ""
	}

	for _, item := range result {
		if item.NzbID == decypharrID {
			return false, fmt.Sprintf("Decypharr reports broken: %s", item.Status)
		}
		// Also match by storage path fragment
		if storagePath != "" && strings.Contains(storagePath, item.Name) {
			return false, fmt.Sprintf("Decypharr reports broken: %s", item.Status)
		}
	}

	return true, ""
}

func (h *Handler) deleteWhenSonarrDone(job *Job, decypharrID string) {
	// Wait 2 minutes — enough time for Sonarr to detect, import, and hardlink the file.
	log.Printf("sabnzbd: [%s] will delete from Decypharr in 2 minutes", job.ID)
	time.Sleep(2 * time.Minute)
	log.Printf("sabnzbd: [%s] deleting from Decypharr now", job.ID)
	h.deleteFromDecypharr(decypharrID)
}

func (h *Handler) deleteFromDecypharr(decypharrID string) {
	log.Printf("sabnzbd: deleteFromDecypharr called for %s", decypharrID)
	h.cfgMu.RLock()
	baseURL := strings.TrimRight(h.cfg.DecypharrURL, "/")
	sabAPIKey := h.sabAPIKey()
	restAPIKey := h.cfg.DecypharrAPIKey
	h.cfgMu.RUnlock()

	if baseURL == "" {
		log.Printf("sabnzbd: no Decypharr URL, cannot delete job %s", decypharrID)
		return
	}

	client := &http.Client{Timeout: 10 * time.Second}
	sabBase := baseURL + "/sabnzbd/api"

	// Correct SABnzbd API: queue delete = mode=queue&name=delete, history delete = mode=history&name=delete
	endpoints := []string{
		fmt.Sprintf("%s?mode=queue&name=delete&value=%s&del_files=1&apikey=%s&output=json", sabBase, decypharrID, sabAPIKey),
		fmt.Sprintf("%s?mode=history&name=delete&value=%s&del_files=1&apikey=%s&output=json", sabBase, decypharrID, sabAPIKey),
	}

	// Also try REST API if Bearer token is configured
	if restAPIKey != "" {
		for _, path := range []string{"/api/queue/" + decypharrID, "/api/history/" + decypharrID} {
			req, _ := http.NewRequest("DELETE", baseURL+path, nil)
			req.Header.Set("Authorization", "Bearer "+restAPIKey)
			if resp, err := client.Do(req); err == nil {
				body, _ := io.ReadAll(resp.Body)
				resp.Body.Close()
				log.Printf("sabnzbd: DELETE %s → %d: %s", path, resp.StatusCode, strings.TrimSpace(string(body)))
			}
		}
	}

	for _, u := range endpoints {
		resp, err := http.Get(u)
		if err != nil {
			log.Printf("sabnzbd: delete failed: %v", err)
			continue
		}
		body, _ := io.ReadAll(resp.Body)
		resp.Body.Close()
		log.Printf("sabnzbd: DELETE %s → %d: %s", u[len(sabBase):], resp.StatusCode, strings.TrimSpace(string(body)))
	}
}

func (h *Handler) handleConfig(w http.ResponseWriter, r *http.Request) {
	h.mu.RLock()
	dir := h.completeDir
	h.mu.RUnlock()
	if dir == "" {
		dir = "/mnt/decypharr"
	}
	base := strings.TrimRight(dir, "/")

	// Build categories from configured arrs + always include "*" default
	h.cfgMu.RLock()
	arrs := h.cfg.Arrs
	h.cfgMu.RUnlock()

	categories := []map[string]interface{}{
		{"name": "*", "dir": "", "complete_dir": base, "pp": "3", "script": "None", "newzbin": "", "priority": -100, "enable_tv_sorting": false, "enable_movie_sorting": false, "enable_date_sorting": false},
	}
	seen := map[string]bool{"*": true}
	for _, a := range arrs {
		if a.Category == "" || seen[a.Category] {
			continue
		}
		seen[a.Category] = true
		categories = append(categories, map[string]interface{}{
			"name": a.Category, "dir": a.Category, "complete_dir": base + "/" + a.Category,
			"pp": "3", "script": "None", "newzbin": "", "priority": -100,
			"enable_tv_sorting": false, "enable_movie_sorting": false, "enable_date_sorting": false,
		})
	}
	// Always include common categories as fallback
	for _, cat := range []string{"sonarr", "radarr", "lidarr", "readarr"} {
		if !seen[cat] {
			categories = append(categories, map[string]interface{}{
				"name": cat, "dir": cat, "complete_dir": base + "/" + cat,
				"pp": "3", "script": "None", "newzbin": "", "priority": -100,
				"enable_tv_sorting": false, "enable_movie_sorting": false, "enable_date_sorting": false,
			})
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"config": map[string]interface{}{
			"misc": map[string]interface{}{
				"complete_dir":             base,
				"download_dir":             base,
				"nzb_backup_dir":           "",
				"version":                  "3.7.2",
				"disable_api_key":          false,
				"pre_check":                false,
				"enable_tv_sorting":        false,
				"enable_movie_sorting":     false,
				"enable_date_sorting":      false,
				"tv_categories":            []string{},
				"movie_categories":         []string{},
				"date_categories":          []string{},
				"history_retention":        "0",
				"history_retention_option": "all",
				"history_retention_number": 0,
				"host_whitelist":           "",
				"api_key":                  h.apiKey,
			},
			"categories": categories,
			"sorters":    []interface{}{},
		},
	})
}

func (h *Handler) setStatus(id string, s jobStatus) {
	h.mu.Lock()
	if job, ok := h.jobs[id]; ok {
		job.Status = s
	}
	h.mu.Unlock()
}

func (h *Handler) failJob(job *Job, msg string) {
	log.Printf("sabnzbd: [%s] FAILED: %s", job.ID, msg)
	h.mu.Lock()
	job.Status = statusFailed
	job.ErrMsg = msg
	job.DoneAt = time.Now()
	decypharrID := job.DecypharrJobID
	h.mu.Unlock()

	// Delete from Decypharr immediately so failed downloads don't pile up
	if decypharrID != "" {
		h.deleteFromDecypharr(decypharrID)
	}
}

// StatusSnapshot returns current job state for the web UI.
func (h *Handler) StatusSnapshot() (queue, history []*Job, par2Total int64) {
	h.mu.RLock()
	defer h.mu.RUnlock()
	for _, j := range h.jobs {
		jCopy := *j
		switch j.Status {
		case statusCompleted, statusFailed:
			history = append(history, &jCopy)
		default:
			queue = append(queue, &jCopy)
		}
		par2Total += j.Par2Bytes
	}
	return
}

// --- helpers ---

func extractNZB(r *http.Request) ([]byte, string, error) {
	ct := r.Header.Get("Content-Type")
	mt, _, _ := mime.ParseMediaType(ct)
	if strings.HasPrefix(mt, "multipart/") {
		// Log all available form fields for debugging
		if r.MultipartForm != nil {
			var keys []string
			for k := range r.MultipartForm.File {
				keys = append(keys, k)
			}
			log.Printf("sabnzbd: multipart file fields: %v", keys)
		}
		// SABnzbd API docs: file data in field "name" or "nzbfile"
		for _, key := range []string{"name", "nzbfile", "nzb", "file", "nzbFile"} {
			f, fh, err := r.FormFile(key)
			if err == nil {
				defer f.Close()
				data, err := io.ReadAll(f)
				log.Printf("sabnzbd: got NZB from field %q, filename=%q, size=%d", key, fh.Filename, len(data))
				return data, fh.Filename, err
			}
		}
	}
	nzbURL := r.FormValue("nzburl")
	if nzbURL == "" {
		nzbURL = r.URL.Query().Get("nzburl")
	}
	if nzbURL != "" {
		resp, err := http.Get(nzbURL)
		if err != nil {
			return nil, "", err
		}
		defer resp.Body.Close()
		data, err := io.ReadAll(resp.Body)
		return data, "remote.nzb", err
	}

	// Log what we actually received for diagnosis
	log.Printf("sabnzbd: could not find NZB in request. Content-Type=%q", ct)
	if r.MultipartForm != nil {
		for k := range r.MultipartForm.File {
			log.Printf("sabnzbd:   file field: %q", k)
		}
		for k := range r.MultipartForm.Value {
			log.Printf("sabnzbd:   value field: %q", k)
		}
	}
	return nil, "", fmt.Errorf("no nzb file or url in request")
}

func newID() string {
	return fmt.Sprintf("par2proxy-%d", time.Now().UnixNano())
}

func jsonErr(w http.ResponseWriter, msg string, code int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]interface{}{"status": false, "error": msg})
}
