// Package sabnzbd implements a SABnzbd-compatible HTTP API.
// Sonarr/Radarr POST NZBs here; we repair them and forward to Decypharr.
// Status is proxied FROM Decypharr back to Sonarr so completion is accurate.
package sabnzbd

import (
	"bytes"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"mime"
	"mime/multipart"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/par2proxy/internal/config"
	"github.com/par2proxy/internal/nzb"
	"github.com/par2proxy/internal/repair"
)

type jobStatus string

const (
	statusQueued      jobStatus = "Queued"
	statusRepairing   jobStatus = "Repairing"
	statusForwarded   jobStatus = "Downloading" // SABnzbd name Sonarr understands
	statusCompleted   jobStatus = "Completed"
	statusFailed      jobStatus = "Failed"
)

// Job tracks one NZB submission through its full lifecycle.
type Job struct {
	ID            string
	Name          string
	Category      string
	Status        jobStatus
	Phase         string // human-readable current phase shown in the UI
	Pct           int    // 0-100, updated from Decypharr's queue percentage
	NZBData       []byte
	RepairedNZB   []byte
	AddedAt       time.Time
	DoneAt        time.Time
	ErrMsg        string
	Par2Bytes     int64
	BadSegs       int
	FixedSegs     int

	// DecypharrJobID is the nzo_id Decypharr assigned when we forwarded the NZB.
	DecypharrJobID string

	// StoragePath is the final directory Decypharr reports in its history.
	StoragePath string
}

// Handler is the SABnzbd API handler.
type Handler struct {
	apiKey     string
	engine     *repair.Engine
	forwardURL string
	verbose    bool

	// cfg is kept for per-category arr credential lookup.
	// Access under cfgMu.
	cfgMu sync.RWMutex
	cfg   *config.Config

	mu  sync.RWMutex
	jobs map[string]*Job

	// Fetched from Decypharr at Connect() time.
	completeDir string
	connected   bool
}

// ConnectResult holds what we learned from Decypharr at startup.
type ConnectResult struct {
	CompleteDir string
	Version     string
	Err         error
}

func New(apiKey, forwardURL string, cfg *config.Config, engine *repair.Engine, verbose bool) *Handler {
	h := &Handler{
		apiKey:     apiKey,
		engine:     engine,
		forwardURL: forwardURL,
		cfg:        cfg,
		verbose:    verbose,
		jobs:       make(map[string]*Job),
	}
	go h.pruneLoop()
	return h
}

// UpdateConfig replaces the live config (called when settings are saved).
func (h *Handler) UpdateConfig(cfg *config.Config) {
	h.cfgMu.Lock()
	h.cfg = cfg
	h.cfgMu.Unlock()
}

// arrFor returns the credentials for the arr that owns this category.
func (h *Handler) arrFor(category string) (url, apiKey string) {
	h.cfgMu.RLock()
	arr := h.cfg.ArrForCategory(category)
	h.cfgMu.RUnlock()
	return arr.URL, arr.APIKey
}

// sabAPIKey returns the API key to use for Decypharr SABnzbd auth polling.
// Uses the first arr's API key (all arrs share the same Decypharr instance).
func (h *Handler) sabAPIKey() string {
	h.cfgMu.RLock()
	defer h.cfgMu.RUnlock()
	if len(h.cfg.Arrs) > 0 {
		return h.cfg.Arrs[0].APIKey
	}
	return ""
}


// extractMissingMIDs parses message-IDs from a Decypharr ARTICLE_NOT_FOUND error string.
// Decypharr error format: "failed to stat segment <filename> <mid@host>: NNTP ARTICLE_NOT_FOUND"
// Message-IDs appear between < > angle brackets, which may be JSON-escaped as \u003c \u003e.
func extractMissingMIDs(errStr string) []string {
	// Unescape JSON unicode escapes so \u003c → < and \u003e → >
	errStr = strings.ReplaceAll(errStr, `\u003c`, "<")
	errStr = strings.ReplaceAll(errStr, `\u003e`, ">")
	errStr = strings.ReplaceAll(errStr, `\u0026`, "&")

	var mids []string
	seen := make(map[string]bool)
	remaining := errStr
	for {
		start := strings.Index(remaining, "<")
		if start < 0 {
			break
		}
		end := strings.Index(remaining[start:], ">")
		if end < 0 {
			break
		}
		candidate := remaining[start+1 : start+end]
		remaining = remaining[start+end+1:]
		// Message-IDs contain @ and are not file paths
		if strings.Contains(candidate, "@") && !strings.Contains(candidate, "/") && !seen[candidate] {
			mids = append(mids, candidate)
			seen[candidate] = true
		}
	}
	return mids
}

func (h *Handler) pruneLoop() {
	for {
		time.Sleep(15 * time.Minute)
		cutoff := time.Now().Add(-2 * time.Hour)
		h.mu.Lock()
		pruned := 0
		for id, job := range h.jobs {
			if (job.Status == statusCompleted || job.Status == statusFailed) &&
				!job.DoneAt.IsZero() && job.DoneAt.Before(cutoff) {
				delete(h.jobs, id)
				pruned++
			}
		}
		h.mu.Unlock()
		if pruned > 0 {
			log.Printf("sabnzbd: pruned %d completed/failed jobs older than 2h", pruned)
		}
	}
}

// Connect fetches Decypharr's config (complete_dir, version) so we have the
// real storage path before any jobs are processed.
// It retries up to maxAttempts times with retryDelay between each.
func (h *Handler) Connect(maxAttempts int, retryDelay time.Duration) ConnectResult {
	if maxAttempts <= 0 {
		maxAttempts = 1
	}
	// Try both mode variants
	h.cfgMu.RLock()
	var sabAPIKey string
	if len(h.cfg.Arrs) > 0 {
		sabAPIKey = h.cfg.Arrs[0].APIKey
	}
	h.cfgMu.RUnlock()

	urls := []string{
		strings.TrimRight(h.forwardURL, "/") + "?mode=get_config&output=json&apikey=" + sabAPIKey,
		strings.TrimRight(h.forwardURL, "/") + "?mode=config&output=json&apikey=" + sabAPIKey,
	}

	var lastErr error
	for attempt := 1; attempt <= maxAttempts; attempt++ {
		for _, url := range urls {
			result, err := h.fetchConfig(url)
			if err == nil {
				h.mu.Lock()
				h.completeDir = result.CompleteDir
				h.connected = true
				h.mu.Unlock()
				return result
			}
			lastErr = err
		}
		if attempt < maxAttempts && retryDelay > 0 {
			log.Printf("sabnzbd: connect attempt %d/%d failed: %v", attempt, maxAttempts, lastErr)
			time.Sleep(retryDelay)
		}
	}
	return ConnectResult{Err: lastErr}
}

// SetCompleteDir pre-seeds the complete_dir so the UI can show it
// before Connect() has confirmed it from Decypharr.
func (h *Handler) SetCompleteDir(dir string) {
	if dir == "" {
		return
	}
	h.mu.Lock()
	if h.completeDir == "" {
		h.completeDir = dir
	}
	h.mu.Unlock()
}

func (h *Handler) fetchConfig(url string) (ConnectResult, error) {
	resp, err := http.Get(url)
	if err != nil {
		return ConnectResult{}, fmt.Errorf("GET %s: %w", url, err)
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 300 {
		return ConnectResult{}, fmt.Errorf("Decypharr returned HTTP %d", resp.StatusCode)
	}

	// Decypharr's config response may be wrapped as {config:{misc:{...}}} (SABnzbd get_config)
	// or directly as {misc:{...}} (mode=config). Handle both.
	var cr struct {
		Config struct {
			Misc struct {
				CompleteDir string `json:"complete_dir"`
				Version     string `json:"version"`
			} `json:"misc"`
		} `json:"config"`
		Misc struct {
			CompleteDir string `json:"complete_dir"`
			Version     string `json:"version"`
		} `json:"misc"`
		// Some implementations put values at top level
		CompleteDir string `json:"complete_dir"`
		Version     string `json:"version"`
	}
	body, err := io.ReadAll(resp.Body)
	if err != nil {
		return ConnectResult{}, fmt.Errorf("read body: %w", err)
	}
	if err := json.Unmarshal(body, &cr); err != nil {
		return ConnectResult{}, fmt.Errorf("parse config response: %w", err)
	}

	// Prefer config.misc → misc → top-level
	dir := cr.Config.Misc.CompleteDir
	ver := cr.Config.Misc.Version
	if dir == "" {
		dir = cr.Misc.CompleteDir
		ver = cr.Misc.Version
	}
	if dir == "" {
		dir = cr.CompleteDir
		ver = cr.Version
	}
	if dir == "" {
		return ConnectResult{}, fmt.Errorf("Decypharr config missing complete_dir (response: %s)", body)
	}

	return ConnectResult{CompleteDir: dir, Version: ver}, nil
}

// CompleteDir returns the storage base path fetched from Decypharr.
func (h *Handler) CompleteDir() string {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return h.completeDir
}

// IsConnected returns whether we successfully fetched Decypharr config at startup.
func (h *Handler) IsConnected() bool {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return h.connected
}

func (h *Handler) ServeHTTP(w http.ResponseWriter, r *http.Request) {
	mode := r.FormValue("mode")
	if mode == "" {
		mode = r.URL.Query().Get("mode")
	}
	key := r.FormValue("apikey")
	if key == "" {
		key = r.URL.Query().Get("apikey")
	}

	// Always log incoming requests so connection issues are diagnosable
	log.Printf("sabnzbd: %s %s mode=%q key_ok=%v host=%s",
		r.Method, r.URL.Path, mode, key == h.apiKey || h.apiKey == "", r.Host)

	if h.apiKey != "" && key != h.apiKey {
		log.Printf("sabnzbd: auth failed — got key %q, expected %q", key, h.apiKey)
		jsonErr(w, "API key invalid", http.StatusUnauthorized)
		return
	}
	switch mode {
	case "addfile", "addurl":
		h.handleAdd(w, r)
	case "queue":
		h.handleQueue(w, r)
	case "history":
		h.handleHistory(w, r)
	case "delete":
		h.handleDelete(w, r)
	case "purge":
		h.handlePurge(w, r)
	case "version":
		// Sonarr expects {"version": "x.x.x"} at the root
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]string{"version": "3.7.2"})
	case "config", "get_config":
		// Sonarr calls mode=get_config during Test; mode=config is the legacy alias.
		// Both must return a categories array or Sonarr null-refs.
		h.handleConfig(w, r)
	default:
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]interface{}{"status": true, "error": ""})
	}
}

// handleAdd receives an NZB from Sonarr, returns our job ID immediately,
// then processes and forwards to Decypharr asynchronously.
func (h *Handler) handleAdd(w http.ResponseWriter, r *http.Request) {
	if err := r.ParseMultipartForm(64 << 20); err != nil {
		r.ParseForm()
	}

	log.Printf("sabnzbd: addfile Content-Type=%q", r.Header.Get("Content-Type"))

	category := r.FormValue("cat")
	// Sonarr sends the name in "nzbname" or "title"
	name := r.FormValue("nzbname")
	if name == "" {
		name = r.FormValue("title")
	}

	nzbBytes, filename, err := extractNZB(r)
	if err != nil {
		jsonErr(w, "no NZB: "+err.Error(), http.StatusBadRequest)
		return
	}
	if name == "" {
		name = filename
	}

	id := newID()
	job := &Job{
		ID:       id,
		Name:     name,
		Category: category,
		Status:   statusQueued,
		NZBData:  nzbBytes,
		AddedAt:  time.Now(),
	}

	h.mu.Lock()
	h.jobs[id] = job
	h.mu.Unlock()

	log.Printf("sabnzbd: queued %q (cat=%s id=%s, size=%d bytes)", name, category, id, len(nzbBytes))
	go h.processJob(job)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"status":  true,
		"nzo_ids": []string{id},
	})
}

func (h *Handler) processJob(job *Job) {
	h.mu.Lock()
	job.Status = statusRepairing
	job.Phase = "Checking par2…"
	h.mu.Unlock()

	n, err := nzb.Parse(bytes.NewReader(job.NZBData))
	if err != nil {
		h.failJob(job, "NZB parse error: "+err.Error())
		return
	}

	log.Printf("sabnzbd: [%s] processing %q — %d files, %d par2 files",
		job.ID, job.Name, len(n.Files), len(n.Par2Files()))

	result, err := h.engine.Repair(n)
	if err != nil {
		h.failJob(job, "repair engine error: "+err.Error())
		return
	}

	h.mu.Lock()
	job.BadSegs = result.BadSegments
	job.FixedSegs = result.RepairedCount
	job.Par2Bytes = result.Par2Fetched
	job.Phase = "Forwarding to Decypharr…"
	h.mu.Unlock()

	for _, warn := range result.Warnings {
		log.Printf("sabnzbd: [%s] warning: %s", job.ID, warn)
	}

	nzbToForward := job.NZBData
	if result.Repaired && result.RepairedNZB != nil {
		if rewritten, err := nzb.Marshal(result.RepairedNZB); err == nil {
			nzbToForward = rewritten
			h.mu.Lock()
			job.RepairedNZB = rewritten
			h.mu.Unlock()
			log.Printf("sabnzbd: [%s] forwarding REPAIRED NZB (%d bad → %d fixed)",
				job.ID, result.BadSegments, result.RepairedCount)
		} else {
			log.Printf("sabnzbd: [%s] marshal error, forwarding original: %v", job.ID, err)
		}
	} else {
		log.Printf("sabnzbd: [%s] no repair needed, forwarding original", job.ID)
	}

	// Forward to Decypharr and get its job ID
	decypharrID, err := h.forwardToDecypharr(job, nzbToForward)
	if err != nil {
		errStr := err.Error()
		// Decypharr found missing segments — extract the missing message-IDs
		// and do a targeted repair using par2 recovery blocks.
		if strings.Contains(errStr, "ARTICLE_NOT_FOUND") || strings.Contains(errStr, "No Such Article") {
			missingMIDs := extractMissingMIDs(errStr)
			log.Printf("sabnzbd: [%s] Decypharr found missing segments — running targeted repair (MIDs: %v)", job.ID, missingMIDs)

			h.mu.Lock()
			job.Phase = "Repairing missing segments…"
			h.mu.Unlock()

			result2, err2 := h.engine.RepairWithMissing(n, missingMIDs)
			if err2 == nil && result2.Repaired && result2.RepairedNZB != nil {
				if rewritten, err3 := nzb.Marshal(result2.RepairedNZB); err3 == nil {
					log.Printf("sabnzbd: [%s] repair succeeded (%d/%d fixed), re-forwarding", job.ID, result2.RepairedCount, result2.BadSegments)
					h.mu.Lock()
					job.BadSegs = result2.BadSegments
					job.FixedSegs = result2.RepairedCount
					job.Par2Bytes += result2.Par2Fetched
					h.mu.Unlock()
					decypharrID, err = h.forwardToDecypharr(job, rewritten)
				}
			} else {
				log.Printf("sabnzbd: [%s] targeted repair could not fix all segments: %v", job.ID, err2)
			}
		}
		if err != nil {
			log.Printf("sabnzbd: [%s] forward failed: %v", job.ID, err)
			h.failJob(job, "forward to Decypharr failed: "+err.Error())
			return
		}
	}

	h.mu.Lock()
	job.DecypharrJobID = decypharrID
	job.Status = statusForwarded
	h.mu.Unlock()

	log.Printf("sabnzbd: [%s] forwarded to Decypharr as %s, polling for completion",
		job.ID, decypharrID)

	// Poll Decypharr until it marks the job done
	h.waitForDecypharr(job, decypharrID)
}

// forwardToDecypharr POSTs the NZB and returns Decypharr's nzo_id.
func (h *Handler) forwardToDecypharr(job *Job, nzbBytes []byte) (string, error) {
	// Look up which arr owns this category for correct credentials
	arrURL, arrAPIKey := h.arrFor(job.Category)

	// Inject category into NZB meta tags — Decypharr reads this for folder routing
	if job.Category != "" {
		if n, err := nzb.Parse(bytes.NewReader(nzbBytes)); err == nil {
			found := false
			for i, m := range n.Meta {
				if strings.EqualFold(m.Type, "category") {
					n.Meta[i].Value = job.Category
					found = true
					break
				}
			}
			if !found {
				n.Meta = append(n.Meta, struct {
					Type  string `xml:"type,attr"`
					Value string `xml:",chardata"`
				}{Type: "category", Value: job.Category})
			}
			if rewritten, err := nzb.Marshal(n); err == nil {
				nzbBytes = rewritten
			}
		}
	}

	var body bytes.Buffer
	mw := multipart.NewWriter(&body)

	fw, err := mw.CreateFormFile("name", job.Name+".nzb")
	if err != nil {
		return "", err
	}
	if _, err := fw.Write(nzbBytes); err != nil {
		return "", err
	}
	mw.WriteField("nzbname", job.Name)
	mw.WriteField("cat", job.Category)
	mw.WriteField("mode", "addfile")
	mw.WriteField("output", "json")
	// Decypharr SABnzbd auth: username = arr host URL, apikey = arr API token
	if arrURL != "" {
		mw.WriteField("username", arrURL)
	}
	if arrAPIKey != "" {
		mw.WriteField("apikey", arrAPIKey)
	}
	mw.Close()

	apiURL := strings.TrimRight(h.forwardURL, "/") + "?mode=addfile&output=json"
	if arrAPIKey != "" {
		apiURL += "&apikey=" + arrAPIKey
	}
	if job.Category != "" {
		apiURL += "&cat=" + job.Category
	}
	req, err := http.NewRequest("POST", apiURL, &body)
	if err != nil {
		return "", err
	}
	req.Header.Set("Content-Type", mw.FormDataContentType())

	log.Printf("sabnzbd: [%s] forwarding to Decypharr: URL=%s cat=%q arrURL=%q nzbSize=%d",
		job.ID, apiURL, job.Category, arrURL, len(nzbBytes))

	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		return "", fmt.Errorf("POST to Decypharr: %w", err)
	}
	defer resp.Body.Close()

	respBody, _ := io.ReadAll(resp.Body)
	log.Printf("sabnzbd: [%s] Decypharr response %d: %s", job.ID, resp.StatusCode, string(respBody))

	if resp.StatusCode >= 300 {
		bodyStr := string(respBody)
		// Decypharr 500 with ARTICLE_NOT_FOUND means it accepted the NZB but found
		// missing segments during streaming. The error includes an nzo_id sometimes —
		// either way, propagate so the retry logic in processJob can attempt repair.
		return "", fmt.Errorf("Decypharr returned %d: %s", resp.StatusCode, bodyStr)
	}

	// Parse Decypharr's response to get its job ID
	var addResp struct {
		NzoIDs []string `json:"nzo_ids"`
		Status bool     `json:"status"`
	}
	if err := json.Unmarshal(respBody, &addResp); err != nil || len(addResp.NzoIDs) == 0 {
		var alt struct {
			Queue struct {
				NzoIDs []string `json:"nzo_ids"`
			} `json:"queue"`
		}
		if err2 := json.Unmarshal(respBody, &alt); err2 == nil && len(alt.Queue.NzoIDs) > 0 {
			return alt.Queue.NzoIDs[0], nil
		}
		return "", fmt.Errorf("could not parse Decypharr job ID from response: %s", respBody)
	}
	return addResp.NzoIDs[0], nil
}

// waitForDecypharr polls Decypharr's queue then history until the job completes,
// then mirrors the final status (and storage path) back onto our job.
func (h *Handler) waitForDecypharr(job *Job, decypharrID string) {
	const (
		pollInterval = 5 * time.Second
		maxWait      = 4 * time.Hour
	)
	deadline := time.Now().Add(maxWait)

	for time.Now().Before(deadline) {
		time.Sleep(pollInterval)

		// Check Decypharr's queue first
		if inQueue, pct := h.decypharrQueueStatus(decypharrID); inQueue {
			h.mu.Lock()
			job.Status = statusForwarded
			job.Pct = pct
			job.Phase = fmt.Sprintf("Downloading… %d%%", pct)
			h.mu.Unlock()
			continue
		}

		// Check Decypharr's history
		if done, success, storage := h.decypharrHistoryStatus(decypharrID); done {
			h.mu.Lock()
			job.DoneAt = time.Now()
			if success {
				job.Status = statusCompleted
				job.StoragePath = storage
			} else {
				job.Status = statusFailed
				job.ErrMsg = "Decypharr reported failure"
			}
			h.mu.Unlock()

			log.Printf("sabnzbd: [%s] Decypharr job %s %s (storage: %s)",
				job.ID, decypharrID, job.Status, storage)
			// Do NOT delete from Decypharr here — Sonarr still needs to
			// scan and import the files. Decypharr manages its own history.
			return
		}

		// Still not in queue or history — Decypharr may still be processing
		if h.verbose {
			log.Printf("sabnzbd: [%s] Decypharr job %s not yet in history, continuing to poll",
				job.ID, decypharrID)
		}
	}

	// Timeout — mark as failed
	h.mu.Lock()
	job.Status = statusFailed
	job.ErrMsg = "timed out waiting for Decypharr"
	job.DoneAt = time.Now()
	h.mu.Unlock()
	log.Printf("sabnzbd: [%s] timed out waiting for Decypharr job %s", job.ID, decypharrID)
}

// decypharrQueueStatus checks if the job is still in Decypharr's active queue.
// Returns (inQueue, percentDone).
func (h *Handler) decypharrQueueStatus(decypharrID string) (bool, int) {
	url := strings.TrimRight(h.forwardURL, "/") +
		fmt.Sprintf("?mode=queue&output=json&apikey=%s", h.sabAPIKey())
	resp, err := http.Get(url)
	if err != nil {
		return false, 0
	}
	defer resp.Body.Close()

	var qr struct {
		Queue struct {
			Slots []struct {
				NzoID      string `json:"nzo_id"`
				Percentage string `json:"percentage"`
			} `json:"slots"`
		} `json:"queue"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&qr); err != nil {
		return false, 0
	}
	for _, slot := range qr.Queue.Slots {
		if slot.NzoID == decypharrID {
			var pct int
			fmt.Sscanf(slot.Percentage, "%d", &pct)
			return true, pct
		}
	}
	return false, 0
}

// decypharrHistoryStatus checks Decypharr's history for the job.
// Returns (found, success, storagePath).
func (h *Handler) decypharrHistoryStatus(decypharrID string) (bool, bool, string) {
	url := strings.TrimRight(h.forwardURL, "/") +
		fmt.Sprintf("?mode=history&output=json&apikey=%s", h.sabAPIKey())
	resp, err := http.Get(url)
	if err != nil {
		return false, false, ""
	}
	defer resp.Body.Close()

	var hr struct {
		History struct {
			Slots []struct {
				NzoID   string `json:"nzo_id"`
				Status  string `json:"status"`
				Storage string `json:"storage"`
			} `json:"slots"`
		} `json:"history"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&hr); err != nil {
		return false, false, ""
	}
	for _, slot := range hr.History.Slots {
		if slot.NzoID == decypharrID {
			success := slot.Status == "Completed"
			return true, success, slot.Storage
		}
	}
	return false, false, ""
}

// handleQueue returns our queue to Sonarr.
// Jobs that have been forwarded to Decypharr stay in "Downloading" state
// (SABnzbd's active-queue status) until Decypharr completes them.
func (h *Handler) handleQueue(w http.ResponseWriter, r *http.Request) {
	h.mu.RLock()
	defer h.mu.RUnlock()

	type slotEntry struct {
		ID       string    `json:"nzo_id"`
		Filename string    `json:"filename"`
		Cat      string    `json:"cat"`
		Status   jobStatus `json:"status"`
		MBLeft   float64   `json:"mb_left"`
		MB       float64   `json:"mb"`
		Timeleft string    `json:"timeleft"`
	}

	var slots []slotEntry
	for _, job := range h.jobs {
		// Only active (non-terminal) jobs appear in the queue
		if job.Status == statusCompleted || job.Status == statusFailed {
			continue
		}
		slots = append(slots, slotEntry{
			ID:       job.ID,
			Filename: job.Name,
			Cat:      job.Category,
			Status:   job.Status,
			MBLeft:   1,
			MB:       1,
			Timeleft: "0:00:30",
		})
	}
	if slots == nil {
		slots = []slotEntry{}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"queue": map[string]interface{}{
			"status":        "Idle",
			"speed":         "0",
			"speedlimit":    "",
			"speedlimit_abs": "",
			"paused":        false,
			"noofslots_total": len(slots),
			"noofslots":     len(slots),
			"limit":         20,
			"start":         0,
			"slots":         slots,
			"version":       "3.7.2",
		},
	})
}

// handleHistory returns completed jobs to Sonarr.
// The storage path comes from Decypharr's own history response,
// so Sonarr knows exactly where to find the files.
func (h *Handler) handleHistory(w http.ResponseWriter, r *http.Request) {
	h.mu.RLock()
	defer h.mu.RUnlock()

	type histEntry struct {
		ID         string    `json:"nzo_id"`
		Name       string    `json:"name"`
		Cat        string    `json:"category"`
		Status     jobStatus `json:"status"`
		Completed  int64     `json:"completed"`
		Storage    string    `json:"storage"`
		ActionLine string    `json:"action_line"`
		FailMsg    string    `json:"fail_message"`
	}

	var slots []histEntry
	for _, job := range h.jobs {
		if job.Status != statusCompleted && job.Status != statusFailed {
			continue
		}
		storagePath := job.StoragePath
		if storagePath == "" {
			// Fallback: base path fetched from Decypharr at startup + category subdir
			h.mu.RUnlock()
			h.mu.RLock()
			base := h.completeDir
			if base == "" {
				base = "/mnt/decypharr"
			}
			storagePath = strings.TrimRight(base, "/") + "/" + job.Category
		}
		actionLine := fmt.Sprintf("par2proxy: %d bad segments, %d repaired",
			job.BadSegs, job.FixedSegs)
		slots = append(slots, histEntry{
			ID:         job.ID,
			Name:       job.Name,
			Cat:        job.Category,
			Status:     job.Status,
			Completed:  job.DoneAt.Unix(),
			Storage:    storagePath,
			ActionLine: actionLine,
			FailMsg:    job.ErrMsg,
		})
	}
	if slots == nil {
		slots = []histEntry{}
	}

	json.NewEncoder(w).Encode(map[string]interface{}{
		"history": map[string]interface{}{
			"slots":     slots,
			"noofslots": len(slots),
		},
	})
}

func (h *Handler) handleDelete(w http.ResponseWriter, r *http.Request) {
	id := r.FormValue("value")
	if id == "" {
		id = r.URL.Query().Get("value")
	}

	h.mu.Lock()
	job, ok := h.jobs[id]
	if ok {
		delete(h.jobs, id)
	}
	h.mu.Unlock()

	if ok && job != nil && job.DecypharrJobID != "" {
		// Don't delete immediately — wait for Sonarr to confirm import first.
		// Sonarr calls mode=delete after import but files must still be accessible
		// until the import finishes copying/hardlinking.
		go h.deleteAfterImport(job)
	}

	log.Printf("sabnzbd: deleted job %s", id)
	json.NewEncoder(w).Encode(map[string]bool{"status": true})
}

// deleteAfterImport waits until Sonarr confirms it has imported the episode,
// then removes the job from Decypharr. Gives up after 5 minutes and deletes anyway.
func (h *Handler) deleteAfterImport(job *Job) {
	const (
		checkInterval = 10 * time.Second
		maxWait       = 5 * time.Minute
	)

	h.cfgMu.RLock()
	arr := h.cfg.ArrForCategory(job.Category)
	h.cfgMu.RUnlock()

	// If we can't check Sonarr, wait a safe delay then delete
	if arr.URL == "" || arr.APIKey == "" {
		log.Printf("sabnzbd: [%s] no arr configured for category %q — waiting 60s before Decypharr delete", job.ID, job.Category)
		time.Sleep(60 * time.Second)
		h.deleteFromDecypharr(job.DecypharrJobID)
		return
	}

	deadline := time.Now().Add(maxWait)
	nzbName := strings.TrimSuffix(job.Name, ".nzb")

	for time.Now().Before(deadline) {
		if h.sonarrImported(arr.URL, arr.APIKey, nzbName) {
			log.Printf("sabnzbd: [%s] Sonarr confirmed import of %q — deleting from Decypharr", job.ID, nzbName)
			h.deleteFromDecypharr(job.DecypharrJobID)
			return
		}
		time.Sleep(checkInterval)
	}

	log.Printf("sabnzbd: [%s] import confirmation timeout — deleting from Decypharr anyway", job.ID)
	h.deleteFromDecypharr(job.DecypharrJobID)
}

// sonarrImported checks Sonarr's history for a completed import of the given title.
func (h *Handler) sonarrImported(arrURL, arrAPIKey, nzbName string) bool {
	url := strings.TrimRight(arrURL, "/") + "/api/v3/history?pageSize=20&sortKey=date&sortDirection=descending"
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return false
	}
	req.Header.Set("X-Api-Key", arrAPIKey)
	client := &http.Client{Timeout: 8 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return false
	}

	var result struct {
		Records []struct {
			EventType    string `json:"eventType"`
			SourceTitle  string `json:"sourceTitle"`
		} `json:"records"`
	}
	if err := json.NewDecoder(resp.Body).Decode(&result); err != nil {
		return false
	}

	// Look for a downloadFolderImported or episodeFileImported event matching our title
	nameLower := strings.ToLower(nzbName)
	for _, rec := range result.Records {
		if rec.EventType == "downloadFolderImported" || rec.EventType == "episodeFileImported" {
			if strings.Contains(strings.ToLower(rec.SourceTitle), nameLower[:min(len(nameLower), 30)]) {
				return true
			}
		}
	}
	return false
}

func min(a, b int) int {
	if a < b {
		return a
	}
	return b
}

func (h *Handler) handlePurge(w http.ResponseWriter, r *http.Request) {
	// Delete all jobs, optionally filtered by queue/history
	which := r.FormValue("value") // "queue", "history", or empty = all
	if which == "" {
		which = r.URL.Query().Get("value")
	}
	h.mu.Lock()
	count := 0
	for id, job := range h.jobs {
		switch which {
		case "queue":
			if job.Status == statusCompleted || job.Status == statusFailed {
				continue
			}
		case "history":
			if job.Status != statusCompleted && job.Status != statusFailed {
				continue
			}
		}
		if job.DecypharrJobID != "" {
			go h.deleteFromDecypharr(job.DecypharrJobID)
		}
		delete(h.jobs, id)
		count++
	}
	h.mu.Unlock()
	log.Printf("sabnzbd: purged %d jobs (filter=%q)", count, which)
	json.NewEncoder(w).Encode(map[string]bool{"status": true})
}

func (h *Handler) deleteFromDecypharr(decypharrID string) {
	base := strings.TrimRight(h.forwardURL, "/")
	apiKey := h.sabAPIKey()
	// Delete from active queue
	http.Get(base + fmt.Sprintf("?mode=delete&value=%s&apikey=%s", decypharrID, apiKey))
	// Delete from history (SABnzbd uses mode=history&name=delete&value=<id>)
	http.Get(base + fmt.Sprintf("?mode=history&name=delete&value=%s&apikey=%s", decypharrID, apiKey))
	log.Printf("sabnzbd: deleted Decypharr job %s from queue and history", decypharrID)
}

func (h *Handler) handleConfig(w http.ResponseWriter, r *http.Request) {
	h.mu.RLock()
	dir := h.completeDir
	h.mu.RUnlock()
	if dir == "" {
		dir = "/mnt/decypharr"
	}
	base := strings.TrimRight(dir, "/")

	// Build categories from configured arrs + always include "*" default
	h.cfgMu.RLock()
	arrs := h.cfg.Arrs
	h.cfgMu.RUnlock()

	categories := []map[string]interface{}{
		{"name": "*", "dir": "", "complete_dir": base, "pp": "3", "script": "None", "newzbin": "", "priority": -100, "enable_tv_sorting": false, "enable_movie_sorting": false, "enable_date_sorting": false},
	}
	seen := map[string]bool{"*": true}
	for _, a := range arrs {
		if a.Category == "" || seen[a.Category] {
			continue
		}
		seen[a.Category] = true
		categories = append(categories, map[string]interface{}{
			"name": a.Category, "dir": a.Category, "complete_dir": base + "/" + a.Category,
			"pp": "3", "script": "None", "newzbin": "", "priority": -100,
			"enable_tv_sorting": false, "enable_movie_sorting": false, "enable_date_sorting": false,
		})
	}
	// Always include common categories as fallback
	for _, cat := range []string{"sonarr", "radarr", "lidarr", "readarr"} {
		if !seen[cat] {
			categories = append(categories, map[string]interface{}{
				"name": cat, "dir": cat, "complete_dir": base + "/" + cat,
				"pp": "3", "script": "None", "newzbin": "", "priority": -100,
				"enable_tv_sorting": false, "enable_movie_sorting": false, "enable_date_sorting": false,
			})
		}
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]interface{}{
		"config": map[string]interface{}{
			"misc": map[string]interface{}{
				"complete_dir":             base,
				"download_dir":             base,
				"nzb_backup_dir":           "",
				"version":                  "3.7.2",
				"disable_api_key":          false,
				"pre_check":                false,
				"enable_tv_sorting":        false,
				"enable_movie_sorting":     false,
				"enable_date_sorting":      false,
				"tv_categories":            []string{},
				"movie_categories":         []string{},
				"date_categories":          []string{},
				"history_retention":        "0",
				"history_retention_option": "all",
				"history_retention_number": 0,
				"host_whitelist":           "",
				"api_key":                  h.apiKey,
			},
			"categories": categories,
			"sorters":    []interface{}{},
		},
	})
}

func (h *Handler) setStatus(id string, s jobStatus) {
	h.mu.Lock()
	if job, ok := h.jobs[id]; ok {
		job.Status = s
	}
	h.mu.Unlock()
}

func (h *Handler) failJob(job *Job, msg string) {
	log.Printf("sabnzbd: [%s] FAILED: %s", job.ID, msg)
	h.mu.Lock()
	job.Status = statusFailed
	job.ErrMsg = msg
	job.DoneAt = time.Now()
	h.mu.Unlock()
}

// StatusSnapshot returns current job state for the web UI.
func (h *Handler) StatusSnapshot() (queue, history []*Job, par2Total int64) {
	h.mu.RLock()
	defer h.mu.RUnlock()
	for _, j := range h.jobs {
		jCopy := *j
		switch j.Status {
		case statusCompleted, statusFailed:
			history = append(history, &jCopy)
		default:
			queue = append(queue, &jCopy)
		}
		par2Total += j.Par2Bytes
	}
	return
}

// --- helpers ---

func extractNZB(r *http.Request) ([]byte, string, error) {
	ct := r.Header.Get("Content-Type")
	mt, _, _ := mime.ParseMediaType(ct)
	if strings.HasPrefix(mt, "multipart/") {
		// Log all available form fields for debugging
		if r.MultipartForm != nil {
			var keys []string
			for k := range r.MultipartForm.File {
				keys = append(keys, k)
			}
			log.Printf("sabnzbd: multipart file fields: %v", keys)
		}
		// SABnzbd API docs: file data in field "name" or "nzbfile"
		for _, key := range []string{"name", "nzbfile", "nzb", "file", "nzbFile"} {
			f, fh, err := r.FormFile(key)
			if err == nil {
				defer f.Close()
				data, err := io.ReadAll(f)
				log.Printf("sabnzbd: got NZB from field %q, filename=%q, size=%d", key, fh.Filename, len(data))
				return data, fh.Filename, err
			}
		}
	}
	nzbURL := r.FormValue("nzburl")
	if nzbURL == "" {
		nzbURL = r.URL.Query().Get("nzburl")
	}
	if nzbURL != "" {
		resp, err := http.Get(nzbURL)
		if err != nil {
			return nil, "", err
		}
		defer resp.Body.Close()
		data, err := io.ReadAll(resp.Body)
		return data, "remote.nzb", err
	}

	// Log what we actually received for diagnosis
	log.Printf("sabnzbd: could not find NZB in request. Content-Type=%q", ct)
	if r.MultipartForm != nil {
		for k := range r.MultipartForm.File {
			log.Printf("sabnzbd:   file field: %q", k)
		}
		for k := range r.MultipartForm.Value {
			log.Printf("sabnzbd:   value field: %q", k)
		}
	}
	return nil, "", fmt.Errorf("no nzb file or url in request")
}

func newID() string {
	return fmt.Sprintf("par2proxy-%d", time.Now().UnixNano())
}

func jsonErr(w http.ResponseWriter, msg string, code int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]interface{}{"status": false, "error": msg})
}
