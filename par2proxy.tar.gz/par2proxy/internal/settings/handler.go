// Package settings provides HTTP endpoints for reading, writing, and
// testing the par2proxy configuration from the web UI.
package settings

import (
	"bytes"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/par2proxy/internal/config"
)

// Handler serves the settings API.
type Handler struct {
	mu         sync.RWMutex
	cfg        *config.Config
	configPath string // where to persist; empty = in-memory only

	// onSave is called after a successful save so the app can re-apply config
	onSave func(*config.Config)
}

// New creates a settings Handler.
// configPath is the JSON file to read/write; pass "" to disable persistence.
func New(cfg *config.Config, configPath string, onSave func(*config.Config)) *Handler {
	return &Handler{
		cfg:        cfg,
		configPath: configPath,
		onSave:     onSave,
	}
}

// Register mounts the settings routes on mux.
func (h *Handler) Register(mux *http.ServeMux) {
	mux.HandleFunc("/api/settings", h.handleSettings)
	mux.HandleFunc("/api/settings/test/decypharr", h.testDecypharr)
	mux.HandleFunc("/api/settings/test/nntp", h.testNNTP)
	mux.HandleFunc("/api/settings/test/arr", h.testArr)
}

// --- GET/POST /api/settings ---

func (h *Handler) handleSettings(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		h.getSettings(w, r)
	case http.MethodPost, http.MethodPut:
		h.postSettings(w, r)
	default:
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
	}
}

// SettingsResponse is the public shape of the config (passwords masked for GET).
type SettingsResponse struct {
	ListenAddr        string                `json:"listen_addr"`
	APIKey            string                `json:"api_key"`
	DecypharrURL      string                `json:"decypharr_url"`
	DecypharrAPIKey   string                `json:"decypharr_api_key"`
	DecypharrUsername string                `json:"decypharr_username"`
	DecypharrPassword string                `json:"decypharr_password"`
	NNTPProviders     []NNTPProviderRequest `json:"nntp_providers"`
	MaxPar2MB         int                   `json:"max_par2_mb"`
	Verbose           bool                  `json:"verbose"`
}

type NNTPProviderRequest struct {
	Host           string `json:"host"`
	Port           int    `json:"port"`
	Username       string `json:"username"`
	Password       string `json:"password"`
	TLS            bool   `json:"tls"`
	MaxConnections int    `json:"max_connections"`
}

func (h *Handler) getSettings(w http.ResponseWriter, _ *http.Request) {
	h.mu.RLock()
	cfg := h.cfg
	h.mu.RUnlock()

	providers := make([]NNTPProviderRequest, len(cfg.NNTPProviders))
	for i, p := range cfg.NNTPProviders {
		providers[i] = NNTPProviderRequest{
			Host:           p.Host,
			Port:           p.Port,
			Username:       p.Username,
			Password:       p.Password,
			TLS:            p.TLS,
			MaxConnections: p.MaxConnections,
		}
	}

	resp := SettingsResponse{
		ListenAddr:        cfg.ListenAddr,
		APIKey:            cfg.APIKey,
		DecypharrURL:      cfg.DecypharrURL,
		DecypharrAPIKey:   cfg.DecypharrAPIKey,
		DecypharrUsername: cfg.DecypharrUsername,
		DecypharrPassword: cfg.DecypharrPassword,
		NNTPProviders:     providers,
		MaxPar2MB:         cfg.MaxPar2MB,
		Verbose:           cfg.Verbose,
	}
	jsonOK(w, resp)
}

func (h *Handler) postSettings(w http.ResponseWriter, r *http.Request) {
	var req SettingsResponse
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonErr(w, "invalid JSON: "+err.Error(), http.StatusBadRequest)
		return
	}

	providers := make([]config.NNTPProvider, len(req.NNTPProviders))
	for i, p := range req.NNTPProviders {
		port := p.Port
		if port == 0 {
			if p.TLS {
				port = 563
			} else {
				port = 119
			}
		}
		conns := p.MaxConnections
		if conns == 0 {
			conns = 8
		}
		providers[i] = config.NNTPProvider{
			Host:           p.Host,
			Port:           port,
			Username:       p.Username,
			Password:       p.Password,
			TLS:            p.TLS,
			MaxConnections: conns,
		}
	}

	newCfg := &config.Config{
		ListenAddr:        req.ListenAddr,
		APIKey:            req.APIKey,
		DecypharrURL:      req.DecypharrURL,
		DecypharrAPIKey:   req.DecypharrAPIKey,
		DecypharrUsername: req.DecypharrUsername,
		DecypharrPassword: req.DecypharrPassword,
		NNTPProviders:     providers,
		MaxPar2MB:         req.MaxPar2MB,
		Verbose:           req.Verbose,
	}
	if newCfg.MaxPar2MB == 0 {
		newCfg.MaxPar2MB = 100
	}

	// Persist to disk
	if h.configPath != "" {
		if err := h.save(newCfg); err != nil {
			jsonErr(w, "save failed: "+err.Error(), http.StatusInternalServerError)
			return
		}
	}

	h.mu.Lock()
	h.cfg = newCfg
	h.mu.Unlock()

	if h.onSave != nil {
		go h.onSave(newCfg)
	}

	log.Printf("settings: configuration saved to %s", h.configPath)
	jsonOK(w, map[string]interface{}{"saved": true, "path": h.configPath})
}

func (h *Handler) save(cfg *config.Config) error {
	if h.configPath == "" {
		return nil
	}
	if err := os.MkdirAll(filepath.Dir(h.configPath), 0755); err != nil {
		return err
	}
	data, err := json.MarshalIndent(cfg, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(h.configPath, data, 0644)
}

// Current returns the live config (safe to read from multiple goroutines).
func (h *Handler) Current() *config.Config {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return h.cfg
}

// --- POST /api/settings/test/decypharr ---

type TestResult struct {
	OK      bool   `json:"ok"`
	Message string `json:"message"`
	Detail  string `json:"detail,omitempty"`
}

func (h *Handler) testDecypharr(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}

	// Accept inline payload or fall back to current config
	var req struct {
		URL      string `json:"url"`
		APIKey   string `json:"api_key"`
		Username string `json:"username"`
		Password string `json:"password"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.URL == "" {
		h.mu.RLock()
		req.URL = h.cfg.DecypharrURL
		req.APIKey = h.cfg.DecypharrAPIKey
		req.Username = h.cfg.DecypharrUsername
		req.Password = h.cfg.DecypharrPassword
		h.mu.RUnlock()
	}

	result := testDecypharrConn(req.URL, req.APIKey, req.Username, req.Password)
	jsonOK(w, result)
}

func testDecypharrConn(baseURL, apiKey, sabnzbdUser, sabnzbdPass string) TestResult {
	baseURL = strings.TrimRight(baseURL, "/")

	// 1. Test SABnzbd endpoint (mode=version)
	sabURL := baseURL + "/sabnzbd/api?mode=version&output=json"
	if sabnzbdPass != "" {
		sabURL += "&apikey=" + sabnzbdPass
	}
	resp, err := httpGet(sabURL)
	if err != nil {
		return TestResult{OK: false, Message: "Cannot reach Decypharr", Detail: err.Error()}
	}
	var ver struct {
		Version string `json:"version"`
	}
	json.Unmarshal(resp, &ver)

	// 2. Test REST API (Bearer token)
	restURL := baseURL + "/api/config"
	restReq, _ := http.NewRequest("GET", restURL, nil)
	if apiKey != "" {
		restReq.Header.Set("Authorization", "Bearer "+apiKey)
	}
	client := &http.Client{Timeout: 8 * time.Second}
	restResp, err := client.Do(restReq)
	restOK := err == nil && restResp != nil && restResp.StatusCode < 300
	if restResp != nil {
		restResp.Body.Close()
	}

	// 3. Test get_config (SABnzbd API) — needed for complete_dir
	configURL := baseURL + "/sabnzbd/api?mode=get_config&output=json"
	if sabnzbdPass != "" {
		configURL += "&apikey=" + sabnzbdPass
	}
	configResp, configErr := httpGet(configURL)
	configHasDir := configErr == nil && bytes.Contains(configResp, []byte("complete_dir"))

	msg := fmt.Sprintf("Decypharr %s reachable", ver.Version)
	detail := ""
	if !restOK {
		detail += "⚠ REST API (Bearer token) not reachable — check DECYPHARR_API_KEY. "
	} else {
		detail += "✓ REST API OK. "
	}
	if !configHasDir {
		detail += "⚠ SABnzbd get_config missing complete_dir — check DECYPHARR_USERNAME/PASSWORD."
	} else {
		detail += "✓ SABnzbd API OK."
	}

	return TestResult{OK: true, Message: msg, Detail: strings.TrimSpace(detail)}
}

// --- POST /api/settings/test/nntp ---

func (h *Handler) testNNTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}

	var req struct {
		Index    *int   `json:"index"`    // nil = test all
		Host     string `json:"host"`
		Port     int    `json:"port"`
		Username string `json:"username"`
		Password string `json:"password"`
		TLS      bool   `json:"tls"`
	}
	req.TLS = true // default
	json.NewDecoder(r.Body).Decode(&req)

	// If inline host provided, test just that one
	if req.Host != "" {
		port := req.Port
		if port == 0 {
			if req.TLS {
				port = 563
			} else {
				port = 119
			}
		}
		result := testNNTPConn(req.Host, port, req.Username, req.Password, req.TLS)
		jsonOK(w, result)
		return
	}

	// Test all configured providers
	h.mu.RLock()
	providers := h.cfg.NNTPProviders
	h.mu.RUnlock()

	if req.Index != nil && *req.Index < len(providers) {
		p := providers[*req.Index]
		result := testNNTPConn(p.Host, p.Port, p.Username, p.Password, p.TLS)
		jsonOK(w, result)
		return
	}

	// Test all
	type indexed struct {
		Index  int        `json:"index"`
		Host   string     `json:"host"`
		Result TestResult `json:"result"`
	}
	var results []indexed
	for i, p := range providers {
		results = append(results, indexed{
			Index:  i,
			Host:   p.Host,
			Result: testNNTPConn(p.Host, p.Port, p.Username, p.Password, p.TLS),
		})
	}
	jsonOK(w, results)
}

func testNNTPConn(host string, port int, username, password string, useTLS bool) TestResult {
	addr := host + ":" + strconv.Itoa(port)
	var conn net.Conn
	var err error

	dialer := &net.Dialer{Timeout: 10 * time.Second}
	if useTLS {
		conn, err = tls.DialWithDialer(dialer, "tcp", addr, &tls.Config{ServerName: host})
	} else {
		conn, err = dialer.Dial("tcp", addr)
	}
	if err != nil {
		return TestResult{OK: false, Message: "Cannot connect to " + addr, Detail: err.Error()}
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(10 * time.Second))

	// Read greeting
	buf := make([]byte, 256)
	n, err := conn.Read(buf)
	if err != nil {
		return TestResult{OK: false, Message: "No greeting from " + host, Detail: err.Error()}
	}
	greeting := strings.TrimSpace(string(buf[:n]))
	if !strings.HasPrefix(greeting, "2") {
		return TestResult{OK: false, Message: "Bad greeting from " + host, Detail: greeting}
	}

	// Auth
	if username != "" {
		fmt.Fprintf(conn, "AUTHINFO USER %s\r\n", username)
		n, _ = conn.Read(buf)
		authResp := strings.TrimSpace(string(buf[:n]))
		if strings.HasPrefix(authResp, "381") && password != "" {
			fmt.Fprintf(conn, "AUTHINFO PASS %s\r\n", password)
			n, _ = conn.Read(buf)
			authResp = strings.TrimSpace(string(buf[:n]))
		}
		if !strings.HasPrefix(authResp, "281") && !strings.HasPrefix(authResp, "250") {
			return TestResult{
				OK:      false,
				Message: "Authentication failed for " + host,
				Detail:  authResp,
			}
		}
	}

	fmt.Fprintf(conn, "QUIT\r\n")
	return TestResult{
		OK:      true,
		Message: fmt.Sprintf("Connected to %s (port %d, TLS=%v)", host, port, useTLS),
		Detail:  "Auth OK · " + greeting,
	}
}

// --- POST /api/settings/test/arr ---
// Tests Sonarr/Radarr connectivity (their API, not us).

func (h *Handler) testArr(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		URL    string `json:"url"`
		APIKey string `json:"api_key"`
		Name   string `json:"name"` // "Sonarr", "Radarr", etc.
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.URL == "" {
		jsonErr(w, "url and api_key required", http.StatusBadRequest)
		return
	}

	result := testArrConn(req.URL, req.APIKey, req.Name)
	jsonOK(w, result)
}

func testArrConn(baseURL, apiKey, name string) TestResult {
	baseURL = strings.TrimRight(baseURL, "/")
	url := baseURL + "/api/v3/system/status"

	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return TestResult{OK: false, Message: "Invalid URL", Detail: err.Error()}
	}
	req.Header.Set("X-Api-Key", apiKey)

	client := &http.Client{Timeout: 8 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return TestResult{OK: false, Message: "Cannot reach " + name, Detail: err.Error()}
	}
	defer resp.Body.Close()

	if resp.StatusCode == 401 {
		return TestResult{OK: false, Message: "Invalid API key for " + name, Detail: "HTTP 401"}
	}
	if resp.StatusCode >= 300 {
		return TestResult{OK: false, Message: name + " returned error", Detail: fmt.Sprintf("HTTP %d", resp.StatusCode)}
	}

	var status struct {
		AppName string `json:"appName"`
		Version string `json:"version"`
	}
	json.NewDecoder(resp.Body).Decode(&status)
	label := name
	if status.AppName != "" {
		label = status.AppName
	}
	return TestResult{
		OK:      true,
		Message: fmt.Sprintf("%s v%s connected", label, status.Version),
		Detail:  url,
	}
}

// --- helpers ---

func httpGet(url string) ([]byte, error) {
	client := &http.Client{Timeout: 8 * time.Second}
	resp, err := client.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode >= 300 {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	return io.ReadAll(resp.Body)
}

func jsonOK(w http.ResponseWriter, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}

func jsonErr(w http.ResponseWriter, msg string, code int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]interface{}{"error": msg})
}
