package settings

import (
	"bytes"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"

	"github.com/par2proxy/internal/config"
)

type Handler struct {
	mu         sync.RWMutex
	cfg        *config.Config
	configPath string
	onSave     func(*config.Config)
}

func New(cfg *config.Config, configPath string, onSave func(*config.Config)) *Handler {
	return &Handler{cfg: cfg, configPath: configPath, onSave: onSave}
}

func (h *Handler) Register(mux *http.ServeMux) {
	mux.HandleFunc("/api/settings", h.handleSettings)
	mux.HandleFunc("/api/settings/test/decypharr", h.testDecypharr)
	mux.HandleFunc("/api/settings/test/nntp", h.testNNTP)
	mux.HandleFunc("/api/settings/test/arr", h.testArr)
}

// ── GET/POST /api/settings ────────────────────────────────────────────────────

type ArrRequest struct {
	Name     string `json:"name"`
	URL      string `json:"url"`
	APIKey   string `json:"api_key"`
	Category string `json:"category"`
}

type SettingsRequest struct {
	ListenAddr      string                `json:"listen_addr"`
	APIKey          string                `json:"api_key"`
	DecypharrURL    string                `json:"decypharr_url"`
	DecypharrAPIKey string                `json:"decypharr_api_key"`
	Arrs            []ArrRequest          `json:"arrs"`
	NNTPProviders   []NNTPProviderRequest `json:"nntp_providers"`
	MaxPar2MB       int                   `json:"max_par2_mb"`
	Verbose         bool                  `json:"verbose"`
}

type NNTPProviderRequest struct {
	Host           string `json:"host"`
	Port           int    `json:"port"`
	Username       string `json:"username"`
	Password       string `json:"password"`
	TLS            bool   `json:"tls"`
	MaxConnections int    `json:"max_connections"`
}

func (h *Handler) handleSettings(w http.ResponseWriter, r *http.Request) {
	switch r.Method {
	case http.MethodGet:
		h.getSettings(w, r)
	case http.MethodPost, http.MethodPut:
		h.postSettings(w, r)
	default:
		http.Error(w, "method not allowed", http.StatusMethodNotAllowed)
	}
}

func (h *Handler) getSettings(w http.ResponseWriter, _ *http.Request) {
	h.mu.RLock()
	cfg := h.cfg
	h.mu.RUnlock()

	arrs := make([]ArrRequest, len(cfg.Arrs))
	for i, a := range cfg.Arrs {
		arrs[i] = ArrRequest{Name: a.Name, URL: a.URL, APIKey: a.APIKey, Category: a.Category}
	}

	providers := make([]NNTPProviderRequest, len(cfg.NNTPProviders))
	for i, p := range cfg.NNTPProviders {
		providers[i] = NNTPProviderRequest{
			Host: p.Host, Port: p.Port, Username: p.Username,
			Password: p.Password, TLS: p.TLS, MaxConnections: p.MaxConnections,
		}
	}

	jsonOK(w, SettingsRequest{
		ListenAddr:      cfg.ListenAddr,
		APIKey:          cfg.APIKey,
		DecypharrURL:    cfg.DecypharrURL,
		DecypharrAPIKey: cfg.DecypharrAPIKey,
		Arrs:            arrs,
		NNTPProviders:   providers,
		MaxPar2MB:       cfg.MaxPar2MB,
		Verbose:         cfg.Verbose,
	})
}

func (h *Handler) postSettings(w http.ResponseWriter, r *http.Request) {
	var req SettingsRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		jsonErr(w, "invalid JSON: "+err.Error(), http.StatusBadRequest)
		return
	}

	h.mu.RLock()
	existing := h.cfg
	h.mu.RUnlock()

	listenAddr := req.ListenAddr
	if listenAddr == "" {
		listenAddr = existing.ListenAddr
	}
	if listenAddr == "" {
		listenAddr = ":8383"
	}

	arrs := make([]config.ArrConfig, len(req.Arrs))
	for i, a := range req.Arrs {
		arrs[i] = config.ArrConfig{Name: a.Name, URL: a.URL, APIKey: a.APIKey, Category: a.Category}
	}

	providers := make([]config.NNTPProvider, len(req.NNTPProviders))
	for i, p := range req.NNTPProviders {
		port := p.Port
		if port == 0 {
			if p.TLS { port = 563 } else { port = 119 }
		}
		conns := p.MaxConnections
		if conns == 0 { conns = 8 }
		providers[i] = config.NNTPProvider{
			Host: p.Host, Port: port, Username: p.Username,
			Password: p.Password, TLS: p.TLS, MaxConnections: conns,
		}
	}

	newCfg := &config.Config{
		ListenAddr:      listenAddr,
		APIKey:          req.APIKey,
		DecypharrURL:    req.DecypharrURL,
		DecypharrAPIKey: req.DecypharrAPIKey,
		Arrs:            arrs,
		NNTPProviders:   providers,
		MaxPar2MB:       req.MaxPar2MB,
		Verbose:         req.Verbose,
	}
	if newCfg.MaxPar2MB == 0 { newCfg.MaxPar2MB = 100 }
	if newCfg.APIKey == "" { newCfg.APIKey = "par2proxy" }

	savedPath := h.configPath
	if err := h.save(newCfg); err != nil {
		// Try default path
		if err2 := os.MkdirAll("/config", 0755); err2 == nil {
			fallback := "/config/config.json"
			if data, jerr := json.MarshalIndent(newCfg, "", "  "); jerr == nil {
				if werr := os.WriteFile(fallback, data, 0644); werr == nil {
					h.mu.Lock()
					h.configPath = fallback
					h.mu.Unlock()
					savedPath = fallback
				}
			}
		}
		if savedPath == "" {
			jsonErr(w, "save failed: "+err.Error(), http.StatusInternalServerError)
			return
		}
	}

	h.mu.Lock()
	h.cfg = newCfg
	h.mu.Unlock()

	if h.onSave != nil {
		go h.onSave(newCfg)
	}

	log.Printf("settings: saved to %s (%d arrs)", savedPath, len(arrs))
	jsonOK(w, map[string]interface{}{"saved": true, "path": savedPath})
}

func (h *Handler) save(cfg *config.Config) error {
	if h.configPath == "" {
		return fmt.Errorf("no config path")
	}
	if err := os.MkdirAll(filepath.Dir(h.configPath), 0755); err != nil {
		return err
	}
	data, _ := json.MarshalIndent(cfg, "", "  ")
	return os.WriteFile(h.configPath, data, 0644)
}

func (h *Handler) Current() *config.Config {
	h.mu.RLock()
	defer h.mu.RUnlock()
	return h.cfg
}

// ── Test endpoints ─────────────────────────────────────────────────────────────

type TestResult struct {
	OK      bool   `json:"ok"`
	Message string `json:"message"`
	Detail  string `json:"detail,omitempty"`
}

func (h *Handler) testDecypharr(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		URL     string `json:"url"`
		APIKey  string `json:"api_key"`
		ArrURL  string `json:"arr_url"`
		ArrKey  string `json:"arr_api_key"`
	}
	json.NewDecoder(r.Body).Decode(&req)
	if req.URL == "" {
		h.mu.RLock()
		req.URL = h.cfg.DecypharrURL
		req.APIKey = h.cfg.DecypharrAPIKey
		if len(h.cfg.Arrs) > 0 {
			req.ArrURL = h.cfg.Arrs[0].URL
			req.ArrKey = h.cfg.Arrs[0].APIKey
		}
		h.mu.RUnlock()
	}
	jsonOK(w, testDecypharrConn(req.URL, req.APIKey, req.ArrURL, req.ArrKey))
}

func testDecypharrConn(baseURL, apiKey, sabnzbdUser, sabnzbdPass string) TestResult {
	baseURL = strings.TrimRight(baseURL, "/")
	sabURL := baseURL + "/sabnzbd/api?mode=version&output=json"
	if sabnzbdPass != "" {
		sabURL += "&apikey=" + sabnzbdPass
	}
	resp, err := httpGet(sabURL)
	if err != nil {
		return TestResult{OK: false, Message: "Cannot reach Decypharr", Detail: err.Error()}
	}
	var ver struct{ Version string `json:"version"` }
	json.Unmarshal(resp, &ver)

	restURL := baseURL + "/api/config"
	restReq, _ := http.NewRequest("GET", restURL, nil)
	if apiKey != "" {
		restReq.Header.Set("Authorization", "Bearer "+apiKey)
	}
	client := &http.Client{Timeout: 8 * time.Second}
	restResp, err := client.Do(restReq)
	restOK := err == nil && restResp != nil && restResp.StatusCode < 300
	if restResp != nil { restResp.Body.Close() }

	configURL := baseURL + "/sabnzbd/api?mode=get_config&output=json"
	if sabnzbdPass != "" { configURL += "&apikey=" + sabnzbdPass }
	configResp, configErr := httpGet(configURL)
	configHasDir := configErr == nil && bytes.Contains(configResp, []byte("complete_dir"))

	msg := fmt.Sprintf("Decypharr %s reachable", ver.Version)
	var parts []string
	if restOK { parts = append(parts, "✓ REST API OK") } else { parts = append(parts, "⚠ REST API failed — check API key") }
	if configHasDir { parts = append(parts, "✓ SABnzbd API OK") } else { parts = append(parts, "⚠ SABnzbd config missing complete_dir") }
	return TestResult{OK: true, Message: msg, Detail: strings.Join(parts, " · ")}
}

func (h *Handler) testNNTP(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		Host     string `json:"host"`
		Port     int    `json:"port"`
		Username string `json:"username"`
		Password string `json:"password"`
		TLS      bool   `json:"tls"`
		Index    *int   `json:"index"`
	}
	req.TLS = true
	json.NewDecoder(r.Body).Decode(&req)

	if req.Host != "" {
		port := req.Port
		if port == 0 { if req.TLS { port = 563 } else { port = 119 } }
		jsonOK(w, testNNTPConn(req.Host, port, req.Username, req.Password, req.TLS))
		return
	}

	h.mu.RLock()
	providers := h.cfg.NNTPProviders
	h.mu.RUnlock()

	if req.Index != nil && *req.Index < len(providers) {
		p := providers[*req.Index]
		jsonOK(w, testNNTPConn(p.Host, p.Port, p.Username, p.Password, p.TLS))
		return
	}
	type indexed struct {
		Index  int        `json:"index"`
		Host   string     `json:"host"`
		Result TestResult `json:"result"`
	}
	var results []indexed
	for i, p := range providers {
		results = append(results, indexed{i, p.Host, testNNTPConn(p.Host, p.Port, p.Username, p.Password, p.TLS)})
	}
	jsonOK(w, results)
}

func testNNTPConn(host string, port int, username, password string, useTLS bool) TestResult {
	addr := host + ":" + strconv.Itoa(port)
	dialer := &net.Dialer{Timeout: 10 * time.Second}
	var conn net.Conn
	var err error
	if useTLS {
		conn, err = tls.DialWithDialer(dialer, "tcp", addr, &tls.Config{ServerName: host})
	} else {
		conn, err = dialer.Dial("tcp", addr)
	}
	if err != nil {
		return TestResult{OK: false, Message: "Cannot connect to " + addr, Detail: err.Error()}
	}
	defer conn.Close()
	conn.SetDeadline(time.Now().Add(10 * time.Second))

	buf := make([]byte, 256)
	n, err := conn.Read(buf)
	if err != nil {
		return TestResult{OK: false, Message: "No greeting from " + host, Detail: err.Error()}
	}
	greeting := strings.TrimSpace(string(buf[:n]))
	if !strings.HasPrefix(greeting, "2") {
		return TestResult{OK: false, Message: "Bad greeting from " + host, Detail: greeting}
	}
	if username != "" {
		fmt.Fprintf(conn, "AUTHINFO USER %s\r\n", username)
		n, _ = conn.Read(buf)
		authResp := strings.TrimSpace(string(buf[:n]))
		if strings.HasPrefix(authResp, "381") && password != "" {
			fmt.Fprintf(conn, "AUTHINFO PASS %s\r\n", password)
			n, _ = conn.Read(buf)
			authResp = strings.TrimSpace(string(buf[:n]))
		}
		if !strings.HasPrefix(authResp, "281") && !strings.HasPrefix(authResp, "250") {
			return TestResult{OK: false, Message: "Authentication failed for " + host, Detail: authResp}
		}
	}
	fmt.Fprintf(conn, "QUIT\r\n")
	return TestResult{OK: true, Message: fmt.Sprintf("Connected to %s (port %d, TLS=%v)", host, port, useTLS), Detail: "Auth OK · " + greeting}
}

func (h *Handler) testArr(w http.ResponseWriter, r *http.Request) {
	if r.Method != http.MethodPost {
		http.Error(w, "POST required", http.StatusMethodNotAllowed)
		return
	}
	var req struct {
		URL    string `json:"url"`
		APIKey string `json:"api_key"`
		Name   string `json:"name"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil || req.URL == "" {
		jsonErr(w, "url and api_key required", http.StatusBadRequest)
		return
	}
	jsonOK(w, testArrConn(req.URL, req.APIKey, req.Name))
}

func testArrConn(baseURL, apiKey, name string) TestResult {
	baseURL = strings.TrimRight(baseURL, "/")
	url := baseURL + "/api/v3/system/status"
	req, err := http.NewRequest("GET", url, nil)
	if err != nil {
		return TestResult{OK: false, Message: "Invalid URL", Detail: err.Error()}
	}
	req.Header.Set("X-Api-Key", apiKey)
	client := &http.Client{Timeout: 8 * time.Second}
	resp, err := client.Do(req)
	if err != nil {
		return TestResult{OK: false, Message: "Cannot reach " + name, Detail: err.Error()}
	}
	defer resp.Body.Close()
	if resp.StatusCode == 401 {
		return TestResult{OK: false, Message: "Invalid API key for " + name, Detail: "HTTP 401"}
	}
	if resp.StatusCode >= 300 {
		return TestResult{OK: false, Message: name + " returned error", Detail: fmt.Sprintf("HTTP %d", resp.StatusCode)}
	}
	var status struct {
		AppName string `json:"appName"`
		Version string `json:"version"`
	}
	json.NewDecoder(resp.Body).Decode(&status)
	label := name
	if status.AppName != "" { label = status.AppName }
	return TestResult{OK: true, Message: fmt.Sprintf("%s v%s connected", label, status.Version), Detail: url}
}

func httpGet(url string) ([]byte, error) {
	client := &http.Client{Timeout: 8 * time.Second}
	resp, err := client.Get(url)
	if err != nil { return nil, err }
	defer resp.Body.Close()
	if resp.StatusCode >= 300 { return nil, fmt.Errorf("HTTP %d", resp.StatusCode) }
	return io.ReadAll(resp.Body)
}

func jsonOK(w http.ResponseWriter, v interface{}) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}

func jsonErr(w http.ResponseWriter, msg string, code int) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(code)
	json.NewEncoder(w).Encode(map[string]interface{}{"error": msg})
}
