package nzb

import (
	"encoding/xml"
	"fmt"
	"io"
	"sort"
	"strings"
)

// Segment is one Usenet article within a file.
type Segment struct {
	Number    int    `xml:"number,attr"`
	Bytes     int64  `xml:"bytes,attr"`
	MessageID string `xml:",chardata"` // without angle brackets in NZB
}

// MID returns the message-ID with angle brackets stripped.
func (s Segment) MID() string {
	return strings.Trim(s.MessageID, " <>")
}

// File is one logical file inside an NZB.
type File struct {
	Subject  string    `xml:"subject,attr"`
	Poster   string    `xml:"poster,attr"`
	Date     int64     `xml:"date,attr"`
	Groups   []string  `xml:"groups>group"`
	Segments []Segment `xml:"segments>segment"`
}

// SortedSegments returns segments in order by number.
func (f *File) SortedSegments() []Segment {
	sorted := make([]Segment, len(f.Segments))
	copy(sorted, f.Segments)
	sort.Slice(sorted, func(i, j int) bool {
		return sorted[i].Number < sorted[j].Number
	})
	return sorted
}

// TotalBytes is the sum of all segment bytes.
func (f *File) TotalBytes() int64 {
	var n int64
	for _, s := range f.Segments {
		n += s.Bytes
	}
	return n
}

// IsPar2 returns true if this file is any kind of par2 file.
func (f *File) IsPar2() bool {
	return containsCI(f.Subject, ".par2")
}

// Ispar2Index returns true if this is the index .par2 (no "vol" keyword).
func (f *File) IsPar2Index() bool {
	sub := strings.ToLower(f.Subject)
	return strings.Contains(sub, ".par2") && !strings.Contains(sub, ".vol")
}

// NZB is the top-level document.
type NZB struct {
	XMLName xml.Name `xml:"nzb"`
	Meta    []struct {
		Type  string `xml:"type,attr"`
		Value string `xml:",chardata"`
	} `xml:"head>meta"`
	Files []*File `xml:"file"`
}

// MediaFiles returns non-par2 files.
func (n *NZB) MediaFiles() []*File {
	var out []*File
	for _, f := range n.Files {
		if !f.IsPar2() {
			out = append(out, f)
		}
	}
	return out
}

// Par2Files returns par2 files: index first, then volumes sorted by subject.
func (n *NZB) Par2Files() []*File {
	var idx, vols []*File
	for _, f := range n.Files {
		if !f.IsPar2() {
			continue
		}
		if f.IsPar2Index() {
			idx = append(idx, f)
		} else {
			vols = append(vols, f)
		}
	}
	// Sort volumes by subject so smallest (.vol0+1) come first
	sort.Slice(vols, func(i, j int) bool {
		return vols[i].Subject < vols[j].Subject
	})
	return append(idx, vols...)
}

// Par2TotalBytes returns byte count for all par2 files.
func (n *NZB) Par2TotalBytes() int64 {
	var total int64
	for _, f := range n.Par2Files() {
		total += f.TotalBytes()
	}
	return total
}

// Parse decodes an NZB from a reader.
func Parse(r io.Reader) (*NZB, error) {
	var n NZB
	dec := xml.NewDecoder(r)
	dec.Strict = false
	if err := dec.Decode(&n); err != nil {
		return nil, fmt.Errorf("nzb parse: %w", err)
	}
	return &n, nil
}

// Marshal serialises an NZB back to XML bytes.
func Marshal(n *NZB) ([]byte, error) {
	// xml.MarshalIndent doesn't add the xmlns attribute, so we add it manually
	type nzbOut struct {
		XMLName xml.Name `xml:"nzb"`
		XMLNS   string   `xml:"xmlns,attr"`
		Meta    []struct {
			Type  string `xml:"type,attr"`
			Value string `xml:",chardata"`
		} `xml:"head>meta"`
		Files []*File `xml:"file"`
	}
	out := nzbOut{
		XMLNS: "http://www.newzbin.com/DTD/2003/nzb",
		Meta:  n.Meta,
		Files: n.Files,
	}
	data, err := xml.MarshalIndent(out, "", "  ")
	if err != nil {
		return nil, err
	}
	header := []byte(`<?xml version="1.0" encoding="UTF-8"?>` + "\n" +
		`<!DOCTYPE nzb PUBLIC "-//newzBin//DTD NZB 1.1//EN" "http://www.newzbin.com/DTD/nzb/nzb-1.1.dtd">` + "\n")
	return append(header, data...), nil
}

// ReplaceSegment swaps the MessageID of a specific segment (by file subject + segment number).
// Returns true if the replacement was made.
func (n *NZB) ReplaceSegment(fileSubject string, segNum int, newMessageID string) bool {
	for _, f := range n.Files {
		if f.Subject != fileSubject {
			continue
		}
		for i := range f.Segments {
			if f.Segments[i].Number == segNum {
				f.Segments[i].MessageID = newMessageID
				return true
			}
		}
	}
	return false
}

func containsCI(s, sub string) bool {
	return strings.Contains(strings.ToLower(s), strings.ToLower(sub))
}
