// Package par2 parses PAR2 files and provides segment verification.
// We only need the verification side (reading IFSC checksums per slice)
// and the recovery packet inventory — we never do GF math here because
// we are rewriting the NZB to point Decypharr at recovery slices directly.
package par2

import (
	"bytes"
	"crypto/md5"
	"encoding/binary"
	"fmt"
	"io"
	"strings"
)

// magic is the 8-byte PAR2 packet header start.
var magic = []byte("PAR2\x00PKT")

// PacketType constants (16 bytes, null-padded).
const (
	TypeMain     = "PAR 2.0\x00Main\x00\x00\x00\x00"
	TypeFileDesc = "PAR 2.0\x00FileDesc"
	TypeIFSC     = "PAR 2.0\x00IFSC\x00\x00\x00\x00"
	TypeRecovery = "PAR 2.0\x00RecvSlic"
	TypeCreator  = "PAR 2.0\x00Creator\x00"
)

// Packet is one PAR2 packet.
type Packet struct {
	TypeStr string // 16-byte type field as string
	SetID   [16]byte
	Payload []byte
}

// FileDesc describes one source file.
type FileDesc struct {
	FileID  [16]byte
	MD5     [16]byte // full file MD5
	MD5_16k [16]byte // MD5 of first 16kB
	Length  uint64
	Name    string
}

// SliceChecksum holds the MD5 and CRC32 for one slice of a file.
type SliceChecksum struct {
	MD5   [16]byte
	CRC32 uint32
}

// IFSC maps a FileID to its per-slice checksums.
type IFSC struct {
	FileID  [16]byte
	Slices  []SliceChecksum
}

// RecoveryBlock is one par2 recovery packet.
type RecoveryBlock struct {
	Exponent uint32
	Data     []byte
}

// Set is a fully-parsed PAR2 set (from index + any vol files you hand it).
type Set struct {
	SliceSize uint64
	FileDescs []FileDesc
	IFSCs     []IFSC
	Recovery  []RecoveryBlock

	// SliceChecksums is a flat map: fileID hex -> slice index -> checksum
	SliceChecksums map[string][]SliceChecksum
}

// ParseAll parses one or more raw PAR2 blobs (index .par2 + .vol*.par2).
func ParseAll(blobs [][]byte) (*Set, error) {
	s := &Set{SliceChecksums: make(map[string][]SliceChecksum)}
	for _, blob := range blobs {
		if err := s.parseBlob(blob); err != nil {
			// Non-fatal: some vol files may be partial
			continue
		}
	}
	// Build the checksum map
	for _, ifsc := range s.IFSCs {
		key := fmt.Sprintf("%x", ifsc.FileID)
		s.SliceChecksums[key] = ifsc.Slices
	}
	return s, nil
}

func (s *Set) parseBlob(data []byte) error {
	r := bytes.NewReader(data)
	for {
		pkt, err := readPacket(r)
		if err == io.EOF {
			return nil
		}
		if err != nil {
			return err
		}
		typeKey := strings.TrimRight(pkt.TypeStr, "\x00")
		switch typeKey {
		case strings.TrimRight(TypeMain, "\x00"):
			s.parseMain(pkt.Payload)
		case strings.TrimRight(TypeFileDesc, "\x00"):
			s.parseFileDesc(pkt.Payload)
		case strings.TrimRight(TypeIFSC, "\x00"):
			s.parseIFSC(pkt.Payload)
		case strings.TrimRight(TypeRecovery, "\x00"):
			s.parseRecovery(pkt.Payload)
		}
	}
}

func readPacket(r *bytes.Reader) (*Packet, error) {
	// Scan for magic bytes
	buf := make([]byte, 1)
	matched := 0
	for {
		if _, err := r.Read(buf); err != nil {
			return nil, io.EOF
		}
		if buf[0] == magic[matched] {
			matched++
			if matched == len(magic) {
				break
			}
		} else {
			matched = 0
			if buf[0] == magic[0] {
				matched = 1
			}
		}
	}

	// Header after magic: length(8) md5(16) setid(16) type(16) = 56 bytes
	var hdr struct {
		Length uint64
		MD5    [16]byte
		SetID  [16]byte
		Type   [16]byte
	}
	if err := binary.Read(r, binary.LittleEndian, &hdr); err != nil {
		return nil, fmt.Errorf("packet header: %w", err)
	}
	if hdr.Length < 64 || hdr.Length > 50*1024*1024 {
		return nil, fmt.Errorf("implausible packet length %d", hdr.Length)
	}
	payLen := hdr.Length - 64
	payload := make([]byte, payLen)
	if _, err := io.ReadFull(r, payload); err != nil {
		return nil, fmt.Errorf("packet payload: %w", err)
	}

	// Verify MD5 of (setid + type + payload)
	h := md5.New()
	h.Write(hdr.SetID[:])
	h.Write(hdr.Type[:])
	h.Write(payload)
	sum := h.Sum(nil)
	var sumArr [16]byte
	copy(sumArr[:], sum)
	if sumArr != hdr.MD5 {
		return nil, fmt.Errorf("packet MD5 mismatch")
	}

	return &Packet{
		TypeStr: string(hdr.Type[:]),
		SetID:   hdr.SetID,
		Payload: payload,
	}, nil
}

func (s *Set) parseMain(p []byte) {
	if len(p) < 12 {
		return
	}
	s.SliceSize = binary.LittleEndian.Uint64(p[0:8])
}

func (s *Set) parseFileDesc(p []byte) {
	if len(p) < 56 {
		return
	}
	fd := FileDesc{}
	copy(fd.FileID[:], p[0:16])
	copy(fd.MD5[:], p[16:32])
	copy(fd.MD5_16k[:], p[32:48])
	fd.Length = binary.LittleEndian.Uint64(p[48:56])
	if len(p) > 56 {
		name := p[56:]
		if end := bytes.IndexByte(name, 0); end >= 0 {
			name = name[:end]
		}
		fd.Name = string(name)
	}
	s.FileDescs = append(s.FileDescs, fd)
}

func (s *Set) parseIFSC(p []byte) {
	if len(p) < 16 {
		return
	}
	ifsc := IFSC{}
	copy(ifsc.FileID[:], p[0:16])
	rest := p[16:]
	// Each entry: md5(16) + crc32(4) = 20 bytes
	for len(rest) >= 20 {
		var sc SliceChecksum
		copy(sc.MD5[:], rest[0:16])
		sc.CRC32 = binary.LittleEndian.Uint32(rest[16:20])
		ifsc.Slices = append(ifsc.Slices, sc)
		rest = rest[20:]
	}
	s.IFSCs = append(s.IFSCs, ifsc)
}

func (s *Set) parseRecovery(p []byte) {
	if len(p) < 4 {
		return
	}
	rb := RecoveryBlock{
		Exponent: binary.LittleEndian.Uint32(p[0:4]),
	}
	if len(p) > 4 {
		rb.Data = make([]byte, len(p)-4)
		copy(rb.Data, p[4:])
	}
	s.Recovery = append(s.Recovery, rb)
}

// VerifySlice checks slice data against the expected MD5 from IFSC.
func VerifySlice(data []byte, expected SliceChecksum) bool {
	got := md5.Sum(data)
	return got == expected.MD5
}

// HasRecovery returns true if this set has any recovery blocks loaded.
func (s *Set) HasRecovery() bool {
	return len(s.Recovery) > 0
}

// RecoveryCount returns the number of loaded recovery blocks.
func (s *Set) RecoveryCount() int {
	return len(s.Recovery)
}
