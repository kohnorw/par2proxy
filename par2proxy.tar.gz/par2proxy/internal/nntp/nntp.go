package nntp

import (
	"bufio"
	"crypto/tls"
	"fmt"
	"net"
	"strings"
	"sync"
	"time"
)

// Article is a fetched and yEnc-decoded Usenet article body.
type Article []byte

// Conn is one live NNTP connection.
type conn struct {
	c      net.Conn
	r      *bufio.Reader
	mu     sync.Mutex
	bad    bool
}

func (c *conn) cmd(line string) (int, string, error) {
	c.mu.Lock()
	defer c.mu.Unlock()
	if _, err := fmt.Fprintf(c.c, "%s\r\n", line); err != nil {
		c.bad = true
		return 0, "", err
	}
	resp, err := c.r.ReadString('\n')
	if err != nil {
		c.bad = true
		return 0, "", err
	}
	resp = strings.TrimRight(resp, "\r\n")
	var code int
	fmt.Sscanf(resp, "%d", &code)
	msg := ""
	if len(resp) > 4 {
		msg = resp[4:]
	}
	return code, msg, nil
}

// body sends BODY and returns the raw dot-encoded body.
func (c *conn) body(messageID string) ([]byte, error) {
	c.mu.Lock()
	defer c.mu.Unlock()

	mid := "<" + strings.Trim(messageID, "<>") + ">"
	if _, err := fmt.Fprintf(c.c, "BODY %s\r\n", mid); err != nil {
		c.bad = true
		return nil, err
	}

	line, err := c.r.ReadString('\n')
	if err != nil {
		c.bad = true
		return nil, err
	}
	line = strings.TrimRight(line, "\r\n")
	var code int
	fmt.Sscanf(line, "%d", &code)
	if code != 222 {
		return nil, fmt.Errorf("BODY %s: server returned %s", messageID, line)
	}

	// Read dot-encoded body
	var buf []byte
	for {
		l, err := c.r.ReadString('\n')
		if err != nil {
			c.bad = true
			return nil, err
		}
		l = strings.TrimRight(l, "\r\n")
		if l == "." {
			break
		}
		if strings.HasPrefix(l, "..") {
			l = l[1:]
		}
		buf = append(buf, l...)
		buf = append(buf, '\n')
	}
	return buf, nil
}

// Pool manages multiple NNTP connections across multiple providers.
type Pool struct {
	providers []providerPool
}

type providerPool struct {
	host     string
	port     int
	user     string
	pass     string
	tls      bool
	maxConns int

	mu    sync.Mutex
	idle  []*conn
	count int
	sem   chan struct{}
}

// ProviderConfig is the external config type.
type ProviderConfig struct {
	Host           string
	Port           int
	Username       string
	Password       string
	TLS            bool
	MaxConnections int
}

// NewPool creates a connection pool from provider configs.
func NewPool(providers []ProviderConfig) *Pool {
	p := &Pool{}
	for _, pc := range providers {
		maxC := pc.MaxConnections
		if maxC <= 0 {
			maxC = 8
		}
		p.providers = append(p.providers, providerPool{
			host:     pc.Host,
			port:     pc.Port,
			user:     pc.Username,
			pass:     pc.Password,
			tls:      pc.TLS,
			maxConns: maxC,
			sem:      make(chan struct{}, maxC),
		})
	}
	return p
}

func (pp *providerPool) dial() (*conn, error) {
	addr := fmt.Sprintf("%s:%d", pp.host, pp.port)
	var nc net.Conn
	var err error

	d := &net.Dialer{Timeout: 30 * time.Second}
	if pp.tls {
		nc, err = tls.DialWithDialer(d, "tcp", addr, &tls.Config{ServerName: pp.host})
	} else {
		nc, err = d.Dial("tcp", addr)
	}
	if err != nil {
		return nil, fmt.Errorf("dial %s: %w", addr, err)
	}

	c := &conn{c: nc, r: bufio.NewReaderSize(nc, 128*1024)}

	// Read greeting
	greeting, _ := c.r.ReadString('\n')
	greeting = strings.TrimRight(greeting, "\r\n")
	if !strings.HasPrefix(greeting, "2") {
		nc.Close()
		return nil, fmt.Errorf("bad greeting from %s: %s", addr, greeting)
	}

	// Auth
	if pp.user != "" {
		code, _, err := c.cmd("AUTHINFO USER " + pp.user)
		if err != nil {
			nc.Close()
			return nil, fmt.Errorf("auth user: %w", err)
		}
		if code == 381 {
			code, _, err = c.cmd("AUTHINFO PASS " + pp.pass)
			if err != nil || (code != 281 && code != 250) {
				nc.Close()
				return nil, fmt.Errorf("auth pass: code=%d err=%v", code, err)
			}
		}
	}

	return c, nil
}

func (pp *providerPool) acquire() (*conn, error) {
	pp.sem <- struct{}{}
	pp.mu.Lock()
	for len(pp.idle) > 0 {
		c := pp.idle[len(pp.idle)-1]
		pp.idle = pp.idle[:len(pp.idle)-1]
		pp.mu.Unlock()
		if !c.bad {
			return c, nil
		}
		c.c.Close()
		pp.mu.Lock()
	}
	pp.mu.Unlock()

	c, err := pp.dial()
	if err != nil {
		<-pp.sem
		return nil, err
	}
	return c, nil
}

func (pp *providerPool) release(c *conn) {
	if c.bad {
		c.c.Close()
	} else {
		pp.mu.Lock()
		pp.idle = append(pp.idle, c)
		pp.mu.Unlock()
	}
	<-pp.sem
}

// FetchArticle fetches and yEnc-decodes a single article, trying providers in order.
func (p *Pool) FetchArticle(messageID string) (Article, error) {
	var lastErr error
	for i := range p.providers {
		pp := &p.providers[i]
		c, err := pp.acquire()
		if err != nil {
			lastErr = err
			continue
		}
		raw, err := c.body(messageID)
		pp.release(c)
		if err != nil {
			lastErr = err
			continue
		}
		data, err := decodeYEnc(raw)
		if err != nil {
			return nil, fmt.Errorf("yenc %s: %w", messageID, err)
		}
		return data, nil
	}
	return nil, fmt.Errorf("all providers failed for %s: %w", messageID, lastErr)
}

// FetchArticles fetches multiple articles concurrently, returning results and any errors.
func (p *Pool) FetchArticles(messageIDs []string) (map[string]Article, []error) {
	type result struct {
		id   string
		data Article
		err  error
	}
	ch := make(chan result, len(messageIDs))
	for _, mid := range messageIDs {
		mid := mid
		go func() {
			data, err := p.FetchArticle(mid)
			ch <- result{id: mid, data: data, err: err}
		}()
	}
	results := make(map[string]Article, len(messageIDs))
	var errs []error
	for range messageIDs {
		r := <-ch
		if r.err != nil {
			errs = append(errs, r.err)
		} else {
			results[r.id] = r.data
		}
	}
	return results, errs
}

// CheckArticle returns true if the article exists on the server (STAT command).
func (p *Pool) CheckArticle(messageID string) bool {
	for i := range p.providers {
		pp := &p.providers[i]
		c, err := pp.acquire()
		if err != nil {
			continue
		}
		mid := "<" + strings.Trim(messageID, "<>") + ">"
		code, _, err := c.cmd("STAT " + mid)
		pp.release(c)
		if err == nil && code == 223 {
			return true
		}
	}
	return false
}

// --- yEnc decoder ---

func decodeYEnc(raw []byte) ([]byte, error) {
	lines := strings.Split(string(raw), "\n")
	out := make([]byte, 0, len(raw))
	inBody := false

	for _, line := range lines {
		line = strings.TrimRight(line, "\r")
		if strings.HasPrefix(line, "=ybegin") {
			inBody = true
			continue
		}
		if strings.HasPrefix(line, "=ypart") {
			continue
		}
		if strings.HasPrefix(line, "=yend") {
			break
		}
		if !inBody {
			continue
		}
		decoded := decodeYEncLine(line)
		out = append(out, decoded...)
	}
	return out, nil
}

func decodeYEncLine(line string) []byte {
	out := make([]byte, 0, len(line))
	escaped := false
	for i := 0; i < len(line); i++ {
		b := line[i]
		if escaped {
			out = append(out, (b-64-42)&0xFF)
			escaped = false
		} else if b == '=' {
			escaped = true
		} else {
			out = append(out, (b-42)&0xFF)
		}
	}
	return out
}

// Drain closes all idle connections.
func (p *Pool) Drain() {
	for i := range p.providers {
		pp := &p.providers[i]
		pp.mu.Lock()
		for _, c := range pp.idle {
			c.c.Close()
		}
		pp.idle = nil
		pp.mu.Unlock()
	}
}

// Ping tests connectivity to all providers. Returns a map of host→error.
func (p *Pool) Ping() map[string]error {
	out := make(map[string]error)
	for i := range p.providers {
		pp := &p.providers[i]
		c, err := pp.dial()
		if err != nil {
			out[pp.host] = err
			continue
		}
		c.c.Close()
		out[pp.host] = nil
	}
	return out
}
