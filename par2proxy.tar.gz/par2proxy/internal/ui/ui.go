package ui

import (
	_ "embed"
	"encoding/json"
	"net/http"
)

//go:embed dashboard.html
var dashboardHTML []byte

// Handler serves the web UI and a JSON status API consumed by it.
type Handler struct {
	// statusFn returns the current job/provider state as JSON-serialisable data.
	statusFn func() StatusResponse
}

// StatusResponse is the shape of /api/status.
type StatusResponse struct {
	Queue       []JobSummary      `json:"queue"`
	History     []JobSummary      `json:"history"`
	Providers   []ProviderSummary `json:"providers"`
	Stats       Stats             `json:"stats"`
	Connected   bool              `json:"connected"`    // true once Decypharr config was fetched
	CompleteDir string            `json:"complete_dir"` // real path from Decypharr
}

type JobSummary struct {
	ID       string `json:"id"`
	Name     string `json:"name"`
	Category string `json:"category"`
	Status   string `json:"status"`
	Pct      int    `json:"pct"`
	BadSegs  int    `json:"bad_segs"`
	Fixed    int    `json:"fixed"`
	Par2MB   string `json:"par2_mb"`
	Added    int64  `json:"added_unix"`
	Done     int64  `json:"done_unix,omitempty"`
	ErrMsg   string `json:"err_msg,omitempty"`
}

type ProviderSummary struct {
	Host        string `json:"host"`
	Online      bool   `json:"online"`
	ActiveConns int    `json:"active_conns"`
	MaxConns    int    `json:"max_conns"`
	ErrMsg      string `json:"err_msg,omitempty"`
}

type Stats struct {
	Total     int    `json:"total"`
	Repaired  int    `json:"repaired"`
	InQueue   int    `json:"in_queue"`
	Failed    int    `json:"failed"`
	Par2TotalMB string `json:"par2_total_mb"`
}

// New creates a UI Handler. statusFn is called on each /api/status request.
func New(statusFn func() StatusResponse) *Handler {
	return &Handler{statusFn: statusFn}
}

// Register mounts the UI routes on mux.
func (h *Handler) Register(mux *http.ServeMux) {
	mux.HandleFunc("/", h.serveDashboard)
	mux.HandleFunc("/ui", h.serveDashboard)
	mux.HandleFunc("/api/status", h.serveStatus)
}

func (h *Handler) serveDashboard(w http.ResponseWriter, r *http.Request) {
	if r.URL.Path != "/" && r.URL.Path != "/ui" {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.Write(dashboardHTML)
}

func (h *Handler) serveStatus(w http.ResponseWriter, r *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("Access-Control-Allow-Origin", "*")
	json.NewEncoder(w).Encode(h.statusFn())
}
