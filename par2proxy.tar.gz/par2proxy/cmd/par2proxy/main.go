package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/par2proxy/internal/config"
	"github.com/par2proxy/internal/nntp"
	"github.com/par2proxy/internal/repair"
	"github.com/par2proxy/internal/sabnzbd"
	"github.com/par2proxy/internal/settings"
	"github.com/par2proxy/internal/sweeper"
	"github.com/par2proxy/internal/ui"
)

// providerState holds live connection status for one NNTP provider.
type providerState struct {
	Host        string
	MaxConns    int
	Online      bool
	LastChecked time.Time
	Err         string
}

func main() {
	configPath := flag.String("config", "", "path to JSON config file")
	flag.Parse()

	settingsPath := "/config/config.json"
	if *configPath != "" {
		settingsPath = *configPath
	}

	cfg := loadConfig(settingsPath)

	// ── Shared mutable state ──────────────────────────────────────────────────
	var (
		mu             sync.RWMutex
		pool           *nntp.Pool
		eng            *repair.Engine
		sabHandler     *sabnzbd.Handler
		sw             *sweeper.Sweeper
		providerStates []providerState // live NNTP status, updated by background pings
	)

	// pingProviders runs Ping() on the current pool and updates providerStates.
	pingProviders := func(currentPool *nntp.Pool, cfgProviders []config.NNTPProvider) {
		if currentPool == nil || len(cfgProviders) == 0 {
			mu.Lock()
			providerStates = nil
			mu.Unlock()
			return
		}
		results := currentPool.Ping()
		states := make([]providerState, len(cfgProviders))
		for i, p := range cfgProviders {
			err, tested := results[p.Host]
			online := tested && err == nil
			errMsg := ""
			if err != nil {
				errMsg = err.Error()
			}
			states[i] = providerState{
				Host:        p.Host,
				MaxConns:    p.MaxConnections,
				Online:      online,
				LastChecked: time.Now(),
				Err:         errMsg,
			}
			if online {
				log.Printf("nntp: ✓ %s", p.Host)
			} else {
				log.Printf("nntp: ✗ %s: %v", p.Host, err)
			}
		}
		mu.Lock()
		providerStates = states
		mu.Unlock()
	}

	// applyConfig rebuilds all components from a (possibly new) config.
	applyConfig := func(c *config.Config) {
		mu.Lock()

		// Build NNTP pool
		var pcs []nntp.ProviderConfig
		for _, p := range c.NNTPProviders {
			pcs = append(pcs, nntp.ProviderConfig{
				Host:           p.Host,
				Port:           p.Port,
				Username:       p.Username,
				Password:       p.Password,
				TLS:            p.TLS,
				MaxConnections: p.MaxConnections,
			})
		}
		pool = nntp.NewPool(pcs)
		eng = repair.New(pool, c.MaxPar2MB, c.Verbose)

		decypharrAPIURL := strings.TrimRight(c.DecypharrURL, "/") + "/sabnzbd/api"
		sabHandler = sabnzbd.New(
			c.APIKey,
			decypharrAPIURL,
			c.DecypharrUsername,
			c.DecypharrPassword,
			eng,
			c.Verbose,
		)

		selfURL := "http://localhost" + c.ListenAddr + "/sabnzbd/api"
		sw = sweeper.New(c.DecypharrURL, c.DecypharrAPIKey, selfURL, c.APIKey, eng, c.Verbose)

		// Set placeholder states immediately so UI shows providers right away
		states := make([]providerState, len(c.NNTPProviders))
		for i, p := range c.NNTPProviders {
			states[i] = providerState{Host: p.Host, MaxConns: p.MaxConnections}
		}
		providerStates = states

		localPool := pool
		localCfgProviders := c.NNTPProviders
		localSab := sabHandler
		localDcyURL := c.DecypharrURL

		mu.Unlock()

		// Ping NNTP + connect to Decypharr concurrently in background
		go func() {
			var wg sync.WaitGroup

			if len(localCfgProviders) > 0 {
				wg.Add(1)
				go func() {
					defer wg.Done()
					log.Printf("nntp: pinging %d provider(s)...", len(localCfgProviders))
					pingProviders(localPool, localCfgProviders)
				}()
			}

			if localDcyURL != "" {
				wg.Add(1)
				go func() {
					defer wg.Done()
					res := localSab.Connect(1, 0)
					if res.Err != nil {
						log.Printf("decypharr: not reachable yet (%v), will retry", res.Err)
						// Background retry loop
						go func() {
							for {
								time.Sleep(15 * time.Second)
								if r := localSab.Connect(1, 0); r.Err == nil {
									log.Printf("decypharr: connected — complete_dir=%s", r.CompleteDir)
									return
								}
							}
						}()
					} else {
						log.Printf("decypharr: connected — complete_dir=%s", res.CompleteDir)
					}
				}()
			}

			wg.Wait()
		}()
	}

	// Background NNTP re-ping every 60s to keep status fresh
	go func() {
		for {
			time.Sleep(60 * time.Second)
			mu.RLock()
			p := pool
			mu.RUnlock()
			if p == nil {
				continue
			}
			mu.RLock()
			c := cfg
			mu.RUnlock()
			pingProviders(p, c.NNTPProviders)
		}
	}()

	applyConfig(cfg)

	// ── Status function for the UI ────────────────────────────────────────────
	statusFn := func() ui.StatusResponse {
		mu.RLock()
		sab := sabHandler
		states := providerStates
		mu.RUnlock()

		// Build provider summaries from live ping state
		providers := make([]ui.ProviderSummary, len(states))
		for i, s := range states {
			providers[i] = ui.ProviderSummary{
				Host:     s.Host,
				Online:   s.Online,
				MaxConns: s.MaxConns,
				ErrMsg:   s.Err,
			}
		}

		if sab == nil {
			return ui.StatusResponse{
				Queue:     []ui.JobSummary{},
				History:   []ui.JobSummary{},
				Providers: providers,
			}
		}

		queue, history, par2Total := sab.StatusSnapshot()

		toSummary := func(jobs []*sabnzbd.Job) []ui.JobSummary {
			out := []ui.JobSummary{}
			for _, j := range jobs {
				pct := 0
				switch j.Status {
				case "Repairing", "Downloading":
					pct = 50
				case "Completed", "Failed":
					pct = 100
				}
				out = append(out, ui.JobSummary{
					ID:       j.ID,
					Name:     j.Name,
					Category: j.Category,
					Status:   string(j.Status),
					Pct:      pct,
					BadSegs:  j.BadSegs,
					Fixed:    j.FixedSegs,
					Par2MB:   fmt.Sprintf("%.1f MB", float64(j.Par2Bytes)/1024/1024),
					Added:    j.AddedAt.Unix(),
					Done:     j.DoneAt.Unix(),
					ErrMsg:   j.ErrMsg,
				})
			}
			return out
		}

		total := len(queue) + len(history)
		repaired, inQueue, failed := 0, 0, 0
		for _, j := range append(queue, history...) {
			if j.FixedSegs > 0 {
				repaired++
			}
			switch j.Status {
			case "Queued", "Repairing", "Downloading":
				inQueue++
			case "Failed":
				failed++
			}
		}

		return ui.StatusResponse{
			Queue:       toSummary(queue),
			History:     toSummary(history),
			Providers:   providers,
			Connected:   sab.IsConnected(),
			CompleteDir: sab.CompleteDir(),
			Stats: ui.Stats{
				Total:       total,
				Repaired:    repaired,
				InQueue:     inQueue,
				Failed:      failed,
				Par2TotalMB: fmt.Sprintf("%.1f MB", float64(par2Total)/1024/1024),
			},
		}
	}

	// ── HTTP mux ──────────────────────────────────────────────────────────────
	mux := http.NewServeMux()

	settingsHandler := settings.New(cfg, settingsPath, func(newCfg *config.Config) {
		mu.Lock()
		cfg = newCfg
		mu.Unlock()
		applyConfig(newCfg)
		log.Printf("settings: configuration applied")
	})
	settingsHandler.Register(mux)

	ui.New(statusFn).Register(mux)

	sabMux := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		h := sabHandler
		mu.RUnlock()
		if h == nil {
			http.Error(w, `{"error":"not configured — open the web UI to set up par2proxy"}`, http.StatusServiceUnavailable)
			return
		}
		h.ServeHTTP(w, r)
	})
	mux.Handle("/api", sabMux)
	mux.Handle("/sabnzbd/api", sabMux)
	mux.Handle("/sabnzbd/", sabMux)

	mux.HandleFunc("/api/sweep/", func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		s := sw
		mu.RUnlock()
		if s == nil {
			http.Error(w, `{"error":"not configured"}`, http.StatusServiceUnavailable)
			return
		}
		s.RouteHTTP(w, r)
	})

	mux.HandleFunc("/api/nntp/recheck", func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "POST required", http.StatusMethodNotAllowed)
			return
		}
		mu.RLock()
		p := pool
		c := cfg
		mu.RUnlock()
		go pingProviders(p, c.NNTPProviders)
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprintln(w, `{"status":"recheck started"}`)
	})

	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "ok")
	})

	log.Printf("par2proxy listening on %s", cfg.ListenAddr)
	log.Printf("  Open http://localhost%s to configure", cfg.ListenAddr)

	if err := http.ListenAndServe(cfg.ListenAddr, mux); err != nil {
		log.Fatal(err)
	}
}

func loadConfig(settingsPath string) *config.Config {
	if settingsPath != "" {
		if c, err := config.Load(settingsPath); err == nil {
			log.Printf("config: loaded from %s", settingsPath)
			return c
		}
	}
	c := config.FromEnv()
	if len(c.NNTPProviders) > 0 || c.DecypharrURL != "" {
		log.Printf("config: loaded from environment")
	} else {
		log.Printf("config: no configuration found — open the web UI at :8383 to set up")
	}
	return c
}

func init() {
	log.SetFlags(log.Ldate | log.Ltime | log.Lmsgprefix)
	log.SetPrefix("[par2proxy] ")
	if os.Getenv("VERBOSE") == "true" || os.Getenv("VERBOSE") == "1" {
		log.SetOutput(os.Stdout)
	}
}
