package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/par2proxy/internal/config"
	"github.com/par2proxy/internal/nntp"
	"github.com/par2proxy/internal/repair"
	"github.com/par2proxy/internal/sabnzbd"
	"github.com/par2proxy/internal/settings"
	"github.com/par2proxy/internal/sweeper"
	"github.com/par2proxy/internal/ui"
)

func main() {
	configPath := flag.String("config", "", "path to JSON config file")
	flag.Parse()

	// ── Config: load from /config/config.json, then -config flag, then env ──
	settingsPath := "/config/config.json"
	if *configPath != "" {
		settingsPath = *configPath
	}

	cfg := loadConfig(settingsPath)

	// ── App state — all mutable when settings are saved ──────────────────────
	var (
		mu         sync.RWMutex
		pool       *nntp.Pool
		eng        *repair.Engine
		sabHandler *sabnzbd.Handler
		sw         *sweeper.Sweeper
	)

	// applyConfig rebuilds every component from a new config.
	// Called at startup (if config exists) and on every Settings save.
	applyConfig := func(c *config.Config) {
		mu.Lock()
		defer mu.Unlock()

		// NNTP pool
		var pcs []nntp.ProviderConfig
		for _, p := range c.NNTPProviders {
			pcs = append(pcs, nntp.ProviderConfig{
				Host:           p.Host,
				Port:           p.Port,
				Username:       p.Username,
				Password:       p.Password,
				TLS:            p.TLS,
				MaxConnections: p.MaxConnections,
			})
		}
		pool = nntp.NewPool(pcs)

		if len(pcs) > 0 {
			log.Printf("config: testing NNTP connectivity...")
			for host, err := range pool.Ping() {
				if err != nil {
					log.Printf("  ✗ %s: %v", host, err)
				} else {
					log.Printf("  ✓ %s", host)
				}
			}
		} else {
			log.Printf("config: no NNTP providers — configure via the web UI at :8383")
		}

		// Repair engine
		eng = repair.New(pool, c.MaxPar2MB, c.Verbose)

		// SABnzbd handler
		decypharrAPIURL := strings.TrimRight(c.DecypharrURL, "/") + "/sabnzbd/api"
		sabHandler = sabnzbd.New(
			c.APIKey,
			decypharrAPIURL,
			c.DecypharrUsername,
			c.DecypharrPassword,
			eng,
			c.Verbose,
		)

		// Sweeper
		selfURL := "http://localhost" + c.ListenAddr + "/sabnzbd/api"
		sw = sweeper.New(c.DecypharrURL, c.DecypharrAPIKey, selfURL, c.APIKey, eng, c.Verbose)

		// Connect to Decypharr — try quickly now, retry in background
		if c.DecypharrURL != "" {
			go func(h *sabnzbd.Handler, url string) {
				// Try once immediately (2s timeout) so the UI shows status fast
				quick := h.Connect(1, 0)
				if quick.Err != nil {
					log.Printf("config: Decypharr not reachable yet, retrying in background (%v)", quick.Err)
					// Keep retrying every 10s indefinitely in the background
					for {
						time.Sleep(10 * time.Second)
						res := h.Connect(1, 0)
						if res.Err == nil {
							log.Printf("config: Decypharr connected — complete_dir=%s", res.CompleteDir)
							return
						}
					}
				} else {
					log.Printf("config: Decypharr connected — complete_dir=%s", quick.CompleteDir)
				}
			}(sabHandler, c.DecypharrURL)
		}
	}

	// Apply whatever config we have at startup (may be empty defaults)
	applyConfig(cfg)

	// ── UI status function — reads live state safely ──────────────────────────
	statusFn := func() ui.StatusResponse {
		mu.RLock()
		sab := sabHandler
		currentCfg := cfg
		mu.RUnlock()

		if sab == nil {
			return ui.StatusResponse{} // not yet configured
		}

		queue, history, par2Total := sab.StatusSnapshot()

		toSummary := func(jobs []*sabnzbd.Job) []ui.JobSummary {
			var out []ui.JobSummary
			for _, j := range jobs {
				pct := 0
				switch j.Status {
				case "Repairing", "Downloading":
					pct = 50
				case "Completed", "Failed":
					pct = 100
				}
				out = append(out, ui.JobSummary{
					ID:       j.ID,
					Name:     j.Name,
					Category: j.Category,
					Status:   string(j.Status),
					Pct:      pct,
					BadSegs:  j.BadSegs,
					Fixed:    j.FixedSegs,
					Par2MB:   fmt.Sprintf("%.1f MB", float64(j.Par2Bytes)/1024/1024),
					Added:    j.AddedAt.Unix(),
					Done:     j.DoneAt.Unix(),
					ErrMsg:   j.ErrMsg,
				})
			}
			return out
		}

		var providers []ui.ProviderSummary
		for _, p := range currentCfg.NNTPProviders {
			providers = append(providers, ui.ProviderSummary{
				Host:     p.Host,
				Online:   true,
				MaxConns: p.MaxConnections,
			})
		}

		total := len(queue) + len(history)
		repaired, inQueue, failed := 0, 0, 0
		for _, j := range append(queue, history...) {
			if j.FixedSegs > 0 { repaired++ }
			switch j.Status {
			case "Queued", "Repairing", "Downloading": inQueue++
			case "Failed": failed++
			}
		}

		return ui.StatusResponse{
			Queue:       toSummary(queue),
			History:     toSummary(history),
			Providers:   providers,
			Connected:   sab.IsConnected(),
			CompleteDir: sab.CompleteDir(),
			Stats: ui.Stats{
				Total:       total,
				Repaired:    repaired,
				InQueue:     inQueue,
				Failed:      failed,
				Par2TotalMB: fmt.Sprintf("%.1f MB", float64(par2Total)/1024/1024),
			},
		}
	}

	// ── HTTP mux — all handlers use pointers so they pick up new state ────────
	mux := http.NewServeMux()

	// Settings handler — saves config and triggers applyConfig
	settingsHandler := settings.New(cfg, settingsPath, func(newCfg *config.Config) {
		mu.Lock()
		cfg = newCfg
		mu.Unlock()
		applyConfig(newCfg)
		log.Printf("settings: configuration applied")
	})
	settingsHandler.Register(mux)

	// Web UI
	ui.New(statusFn).Register(mux)

	// SABnzbd API — delegate through closure so it always uses latest handler
	sabMux := http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		h := sabHandler
		mu.RUnlock()
		if h == nil {
			http.Error(w, `{"error":"not configured — open the web UI to set up par2proxy"}`, http.StatusServiceUnavailable)
			return
		}
		h.ServeHTTP(w, r)
	})
	mux.Handle("/api", sabMux)
	mux.Handle("/sabnzbd/api", sabMux)
	mux.Handle("/sabnzbd/", sabMux)

	// Sweep API — guard with middleware that checks sw != nil
	mux.HandleFunc("/api/sweep/", func(w http.ResponseWriter, r *http.Request) {
		mu.RLock()
		s := sw
		mu.RUnlock()
		if s == nil {
			http.Error(w, `{"error":"not configured"}`, http.StatusServiceUnavailable)
			return
		}
		s.RouteHTTP(w, r)
	})

	// Health
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "ok")
	})

	log.Printf("par2proxy listening on %s", cfg.ListenAddr)
	log.Printf("  Open http://localhost%s to configure", cfg.ListenAddr)

	if err := http.ListenAndServe(cfg.ListenAddr, mux); err != nil {
		log.Fatal(err)
	}
}

// loadConfig tries settingsPath first, then env vars, then pure defaults.
func loadConfig(settingsPath string) *config.Config {
	if settingsPath != "" {
		if c, err := config.Load(settingsPath); err == nil {
			log.Printf("config: loaded from %s", settingsPath)
			return c
		}
	}
	c := config.FromEnv()
	if len(c.NNTPProviders) > 0 || c.DecypharrURL != "" {
		log.Printf("config: loaded from environment")
	} else {
		log.Printf("config: no configuration found — open the web UI at :8383 to set up")
	}
	return c
}

func init() {
	log.SetFlags(log.Ldate | log.Ltime | log.Lmsgprefix)
	log.SetPrefix("[par2proxy] ")
	if os.Getenv("VERBOSE") == "true" || os.Getenv("VERBOSE") == "1" {
		log.SetOutput(os.Stdout)
	}
}
