package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"os"
	"strings"
	"time"

	"github.com/par2proxy/internal/config"
	"github.com/par2proxy/internal/nntp"
	"github.com/par2proxy/internal/repair"
	"github.com/par2proxy/internal/sabnzbd"
	"github.com/par2proxy/internal/settings"
	"github.com/par2proxy/internal/sweeper"
	"github.com/par2proxy/internal/ui"
)

func main() {
	configPath := flag.String("config", "", "path to JSON config file (optional, env vars take precedence)")
	flag.Parse()

	var cfg *config.Config
	if *configPath != "" {
		var err error
		cfg, err = config.Load(*configPath)
		if err != nil {
			log.Printf("warning: could not load config %s: %v — falling back to env", *configPath, err)
			cfg = config.FromEnv()
		}
	} else {
		cfg = config.FromEnv()
	}

	if len(cfg.NNTPProviders) == 0 {
		log.Fatal("FATAL: no NNTP providers configured. Set NNTP_HOST, NNTP_USER, NNTP_PASS")
	}

	// Build NNTP pool
	var nnCfgs []nntp.ProviderConfig
	for _, p := range cfg.NNTPProviders {
		nnCfgs = append(nnCfgs, nntp.ProviderConfig{
			Host:           p.Host,
			Port:           p.Port,
			Username:       p.Username,
			Password:       p.Password,
			TLS:            p.TLS,
			MaxConnections: p.MaxConnections,
		})
	}
	pool := nntp.NewPool(nnCfgs)

	// Test connectivity
	log.Println("Testing NNTP connectivity...")
	pings := pool.Ping()
	allOK := true
	for host, err := range pings {
		if err != nil {
			log.Printf("  ✗ %s: %v", host, err)
			allOK = false
		} else {
			log.Printf("  ✓ %s", host)
		}
	}
	if !allOK {
		log.Println("Warning: some NNTP providers failed connectivity check")
	}

	// Build repair engine
	eng := repair.New(pool, cfg.MaxPar2MB, cfg.Verbose)

	// Build SABnzbd handler
	decypharrAPIURL := strings.TrimRight(cfg.DecypharrURL, "/") + "/sabnzbd/api"
	sabHandler := sabnzbd.New(
		cfg.APIKey,
		decypharrAPIURL,
		cfg.DecypharrUsername,
		cfg.DecypharrPassword,
		eng,
		cfg.Verbose,
	)

	// Build web UI handler, wired to live job data
	uiHandler := ui.New(func() ui.StatusResponse {
		queue, history, par2Total := sabHandler.StatusSnapshot()
		connected := sabHandler.IsConnected()
		completeDir := sabHandler.CompleteDir()

		toSummary := func(jobs []*sabnzbd.Job) []ui.JobSummary {
			var out []ui.JobSummary
			for _, j := range jobs {
				pct := 0
				switch j.Status {
				case "Repairing":
					pct = 50
				case "Completed", "Failed":
					pct = 100
				}
				par2MB := fmt.Sprintf("%.1f MB", float64(j.Par2Bytes)/1024/1024)
				out = append(out, ui.JobSummary{
					ID:       j.ID,
					Name:     j.Name,
					Category: j.Category,
					Status:   string(j.Status),
					Pct:      pct,
					BadSegs:  j.BadSegs,
					Fixed:    j.FixedSegs,
					Par2MB:   par2MB,
					Added:    j.AddedAt.Unix(),
					Done:     j.DoneAt.Unix(),
					ErrMsg:   j.ErrMsg,
				})
			}
			return out
		}

		var providers []ui.ProviderSummary
		for _, p := range cfg.NNTPProviders {
			providers = append(providers, ui.ProviderSummary{
				Host:        p.Host,
				Online:      true, // real check happens at startup
				ActiveConns: 0,
				MaxConns:    p.MaxConnections,
			})
		}

		total := len(queue) + len(history)
		repaired := 0
		inQueue := 0
		failed := 0
		for _, j := range append(queue, history...) {
			if j.FixedSegs > 0 {
				repaired++
			}
			if j.Status == "Queued" || j.Status == "Repairing" || j.Status == "Downloading" {
				inQueue++
			}
			if j.Status == "Failed" {
				failed++
			}
		}

		return ui.StatusResponse{
			Queue:       toSummary(queue),
			History:     toSummary(history),
			Providers:   providers,
			Connected:   connected,
			CompleteDir: completeDir,
			Stats: ui.Stats{
				Total:       total,
				Repaired:    repaired,
				InQueue:     inQueue,
				Failed:      failed,
				Par2TotalMB: fmt.Sprintf("%.1f MB", float64(par2Total)/1024/1024),
			},
		}
	})

	// Connect to Decypharr and fetch its storage config.
	// Retry 10 times (50s total) to handle startup ordering in Docker Compose.
	log.Printf("Connecting to Decypharr at %s ...", cfg.DecypharrURL)
	result := sabHandler.Connect(10, 5*time.Second)
	if result.Err != nil {
		log.Printf("Warning: could not reach Decypharr (%v) — storage path will use fallback until connection succeeds", result.Err)
	} else {
		log.Printf("  ✓ Decypharr connected (version %s)", result.Version)
		log.Printf("  ✓ complete_dir: %s", result.CompleteDir)
	}
	mux := http.NewServeMux()

	// Settings — read/write config and test connections from the UI
	// Persist to /config/config.json if that directory exists (Docker volume mount)
	settingsPath := ""
	if *configPath != "" {
		settingsPath = *configPath
	} else if _, err := os.Stat("/config"); err == nil {
		settingsPath = "/config/config.json"
	}
	settingsHandler := settings.New(cfg, settingsPath, func(newCfg *config.Config) {
		// Re-connect to Decypharr whenever config is saved
		log.Printf("settings: re-connecting to Decypharr after config change...")
		result := sabHandler.Connect(3, 3*time.Second)
		if result.Err != nil {
			log.Printf("settings: Decypharr reconnect failed: %v", result.Err)
		} else {
			log.Printf("settings: Decypharr reconnected, complete_dir=%s", result.CompleteDir)
		}
	})
	settingsHandler.Register(mux)

	// Sweeper - bulk repair of Decypharr's usenet library
	sabnzbdSelfURL := "http://localhost" + cfg.ListenAddr + "/sabnzbd/api"
	sw := sweeper.New(
		cfg.DecypharrURL,
		cfg.DecypharrAPIKey,
		sabnzbdSelfURL,
		cfg.APIKey,
		eng,
		cfg.Verbose,
	)
	sw.RegisterRoutes(mux)

	// Web UI
	uiHandler.Register(mux)

	// SABnzbd API (Sonarr talks to these)
	mux.Handle("/api", sabHandler)
	mux.Handle("/sabnzbd/api", sabHandler)
	mux.Handle("/sabnzbd/", sabHandler)

	// Health
	mux.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "ok")
	})

	log.Printf("par2proxy listening on %s", cfg.ListenAddr)
	log.Printf("  UI:  http://localhost%s/", cfg.ListenAddr)
	log.Printf("  API: http://localhost%s/sabnzbd/api", cfg.ListenAddr)
	log.Printf("  ↓ forwards repaired NZBs to Decypharr at %s", cfg.DecypharrURL)
	log.Printf("  par2 fetch limit: %d MB per NZB", cfg.MaxPar2MB)

	if err := http.ListenAndServe(cfg.ListenAddr, mux); err != nil {
		log.Fatal(err)
	}
}

func init() {
	log.SetFlags(log.Ldate | log.Ltime | log.Lmsgprefix)
	log.SetPrefix("[par2proxy] ")
	if os.Getenv("VERBOSE") == "true" || os.Getenv("VERBOSE") == "1" {
		log.SetOutput(os.Stdout)
	}
}
